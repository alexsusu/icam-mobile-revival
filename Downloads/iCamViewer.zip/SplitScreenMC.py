import CallToRestart
import common
import Google
import os
import Settings
import Slideshow
import time
import thread
import threading
import UI

#required to set SplitScreen.splitScreen.prepareVideo_* vars before emitting signal - TODO!!!!: try to remove these ops
import ModelController
import SplitScreen



if common.MY_PYSIDE:
    from PySide import QtCore, QtGui
elif common.MY_PYQT:
    from PyQt4 import Qt
    # For Dialog
    from PyQt4 import QtCore, QtGui




splitScreenMC = None


class SplitScreenMC(ModelController.ModelController):
    def __init__(self, *args): #aIndexVideo):
        global splitScreenMC

        common.DebugPrint("Entered SplitScreenMC::__init__(self=%s, args=%s)" % \
                                                            (self, str(args)))
        super(SplitScreenMC, self).__init__() #*args)

        splitScreenMC = self


    def SetSignals(self):
        common.DebugPrint(
            "Entered SplitScreenMC::SetSignals(self=%s)." % str(self))

        QtCore.QObject.connect(self, #splitScreenMC
            QtCore.SIGNAL("SetVideoTitleAndDrawRectangle()"),
            SplitScreen.splitScreen.SetVideoTitleAndDrawRectangle)

        QtCore.QObject.connect(self, #splitScreenMC
            QtCore.SIGNAL("PrepareVideo()"),
            SplitScreen.splitScreen.PrepareVideo)

        QtCore.QObject.connect(self, #splitScreenMC
            QtCore.SIGNAL("ReleaseVideo()"),
            SplitScreen.splitScreen.ReleaseVideo)


    def UpdateHistory(self, aIndexVideo):
        # Check if UI.dateTimeStr didn't get updated for a long time.
        if (len(UI.dateTimeStrHistory[aIndexVideo]) != 0) and \
                (UI.dateTimeStr[aIndexVideo] == UI.dateTimeStrHistory[aIndexVideo][0]):
            UI.dateTimeStrHistory[aIndexVideo].append(UI.dateTimeStr[aIndexVideo])
            # if True:
            if len(UI.dateTimeStrHistory[aIndexVideo]) == \
                                            120 / Settings.myCfg.NUM_VIDEOS:
                # 10):
                """
                alert("Not receiving new data from phone " \
                        "(numValuescaptionHistory = " + numValuescaptionHistory +
                        " objXml.responseText = " + objXml.responseText +
                        " captionHistory[0] = " + captionHistory[0] + ")
                """

                ###################################################################
                ###################################################################
                ################Uncomment here for error dialogs###################
                ###################################################################
                ###################################################################

                """
                UI.errorDialog[aIndexVideo] = QtGui.QDialog()
                UI.errorDialog[aIndexVideo].setWindowTitle(
                    "Error at aIndexVideo = %d - no update for %d steps. " \
                    "Maybe call phone to restart." % \
                    (aIndexVideo, len(UI.dateTimeStrHistory[aIndexVideo])))

                #UI.errorDialog[aIndexVideo].setMinimumSize(200, 100)
                UI.errorDialog[aIndexVideo].setMaximumSize(500, 100)
                myScreen = QtGui.QDesktopWidget().screenGeometry()

                # Inspired from http://nullege.com/codes/search/PyQt4.QtGui.QMainWindow.setGeometry
                UI.errorDialog[aIndexVideo].setGeometry(myScreen.width() - 300,
                        myScreen.height() - 200, myScreen.width(),
                        myScreen.height() - 100)
                threading.Timer(0.1, UI.errorDialog[aIndexVideo].exec_).start()
                """
                pass

                """
                # Non-modal windows are not great - they can simply?? disappear
                #    and then the application doesn't close because there are
                #    these hidden and open windows.

                #UI.errorDialog[aIndexVideo].setWindowModality(QtCore.Qt.NonModal)
                #UI.errorDialog.adjustSize()
                UI.errorDialog[aIndexVideo].show()
                #UI.errorDialog.raise_()
                #UI.errorDialog[aIndexVideo].activateWindow()
                """
                """
                # From http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qmessagebox.html
                QMessageBox msgBox;
                msgBox.setText("The document has been modified.");
                msgBox.exec();
                """
        else:
            UI.dateTimeStrHistory[aIndexVideo] = [UI.dateTimeStr[aIndexVideo]]

        common.DebugPrint("UpdateHistory(): aIndexVideo = %d: " \
                "len(UI.dateTimeStrHistory) = %d" % \
                    (aIndexVideo, len(UI.dateTimeStrHistory[aIndexVideo])))

        # Did it stop working? If yes, call it. With Skype, etc.

        deviceId = Settings.myCfg.deviceId[UI.indexVideo]

        """
        We implement here another Watchdog for the phones checking for the duration:
        
        """
        """
        One option of alarm triggering - Make phone call
            with Skype:
           "C:\Program Files\Skype\Phone\Skype.exe"
                /callto:+40772103340 #+01234567890 #/nosplash
         doesn't work on
        """


    #!!!!TODO: Refactor function - make it smaller
    def PlayNextVideo(self):
        res = 0

        if False:
            if (len(UI.dateTimeStrHistory[aIndexVideo]) != 0) and \
                    (UI.dateTimeStr[aIndexVideo] == UI.dateTimeStrHistory[aIndexVideo][0]):
                UI.dateTimeStrHistory[aIndexVideo].append(UI.dateTimeStr[aIndexVideo])

            #if time of video < X hours:
            CallToRestart.Check(UI.dateTimeStrHistory[UI.indexVideo])


        try:
            common.DebugPrint(
                "Entered SplitScreenMC::PlayNextVideo() at %s." % \
                    common.GetCurrentDateTimeStringWithMillisecondsNice())

            # We don't run in parallel current video play and Slideshow play.
            while Slideshow.slideshowView is not None:
                common.DebugPrint(
                    "SplitScreenMC::PlayNextVideo(): slideshowView != None.")

                #time.sleep(5.0)
                #!!!!
                return -1

            UI.indexVideo += 1

            if UI.indexVideo == Settings.myCfg.NUM_VIDEOS:
                UI.indexVideo = 0

            common.DebugPrint(
                "SplitScreenMC::PlayNextVideo(): " \
                    "indexVideo = %d, " \
                    "myCfg.mediaServer[indexVideo] = %d." % \
                    (UI.indexVideo, Settings.myCfg.mediaServer[UI.indexVideo]))

            # This is for the iCam Viewer watchdog
            common.PetWatchdog()

            if Settings.myCfg.mediaServer[UI.indexVideo] == 0:
                # YouTube
                Google.FindMostRecentYouTubeVideo()
                """
                global ytVideoEntry
                try:
                    if ytVideoEntry is None:
                        UI.dateTimeStr[UI.indexVideo] = "2010: Not available"
                        UI.dateTimeStrMax[UI.indexVideo] = "2010: Not available"
                    else:
                        #ytVideoEntry.media.description.text
                        UI.dateTimeStr[UI.indexVideo] = ytVideoEntry.media.title.text
                        UI.dateTimeStrMax[UI.indexVideo] = ytVideoEntry.media.title.text
                    URL = ""
                    videoFileSize = -1
                except:
                    common.DebugPrintErrorTrace()
                """
                URL = ""
                videoFileSize = -1

                if False:
                    URL = "file:///blabla"
                    videoFileSize = 751066 # !!!!automate
                    UI.videoDescriptionStr[UI.indexVideo] = "blabla" #UI.dateTimeStr[UI.indexVideo]

            elif Settings.myCfg.mediaServer[UI.indexVideo] == 1:
            # else: Picasa
                pass
            elif Settings.myCfg.mediaServer[UI.indexVideo] == 2:
                # iCam Server
                if UI.SHOW_PHOTO:
                    mediaPathFileName2 = UI.imagePathFileName[UI.indexVideo]
                    URL = "http://" + Settings.myCfg.iCamServerAddress + \
                            Settings.WEB_FOLDER + "/" + mediaPathFileName2
                else:
                    mediaPathFileName2 = UI.mediaPathFileName[UI.indexVideo]
                    """
                    URL = "http://alexsusu.110mb.com/iCam/" + \
                            UI.mediaPathFileName[UI.indexVideo]
                    """

                    URL = "http://" + Settings.myCfg.iCamServerAddress + \
                            Settings.WEB_FOLDER + "/" + mediaPathFileName2

                """
                assert common.DownloadFile(URL + ".inf", \
                                            mediaPathFileName2 + ".inf") == 0

                assert common.DownloadFile(URL[: len(URL) - 4] + ".mp4.inf",
                                            mediaPathFileName2 + ".inf") == 0
                """
                assert common.DownloadFile(URL[ : len(URL) - 4] + \
                                    common.PHONE_MEDIA_EXTENSION + ".inf", \
                                    mediaPathFileName2 + ".inf") == 0

                fInput = open(mediaPathFileName2 + ".inf", "rt")
                UI.dateTimeStr[UI.indexVideo] = fInput.read()
                UI.videoDescriptionStr[UI.indexVideo] = \
                                    UI.dateTimeStr[UI.indexVideo]
                fInput.close()

                """
                In case we send media out of order (because of comm errors and
                    retries), we use UI.dateTimeStrMax in order to display only
                    the most recent seen so far.
                """
                videoFileSize = -1

                if UI.dateTimeStrMax[UI.indexVideo] < UI.dateTimeStr[UI.indexVideo][0 : 19]:
                    UI.dateTimeStrMax[UI.indexVideo] = UI.dateTimeStr[UI.indexVideo][0 : 19]

                if UI.dateTimeStr[UI.indexVideo][20 : 21] == "(":
                    sizeStr = UI.dateTimeStr[UI.indexVideo][21 : ]
                    firstIndex = sizeStr.find(" bytes")
                    videoFileSize = int(sizeStr[0 : firstIndex])
            elif Settings.myCfg.mediaServer[UI.indexVideo] == 3:
                # Local
                URL = "file:///blabla"
                videoFileSize = 751066 # TODO!!!!automate
                UI.videoDescriptionStr[UI.indexVideo] = \
                    "2010_06_22_16_05_29_000_668066806680668_1"
                    #UI.dateTimeStr[UI.indexVideo]
                #!!!!Is it OK?
                UI.mediaPathFileName[UI.indexVideo] = \
                    Settings.myCfg.LOCAL_VIDEO_PATH_FILENAME


            # if YouTube:
            if Settings.myCfg.mediaServer[UI.indexVideo] == 0:
                # YouTube
                dateTimeStrAux = UI.dateTimeStr[UI.indexVideo]
            elif Settings.myCfg.mediaServer[UI.indexVideo] == 1:
                # else: Picasa
                pass
            elif Settings.myCfg.mediaServer[UI.indexVideo] == 2:
                # iCam Server
                dateTimeStrAux = UI.dateTimeStr[UI.indexVideo][0 : 19]
            elif Settings.myCfg.mediaServer[UI.indexVideo] == 3:
                # Local
                dateTimeStrAux = "2010_06_22_16_05_29_000_668066806680668_1"
                UI.dateTimeStr[UI.indexVideo] = dateTimeStrAux
                UI.dateTimeStrMax[UI.indexVideo] = dateTimeStrAux


            # This is for the iCam Viewer watchdog
            common.PetWatchdog()

            # Updates also UI.dateTimeStrHistory.
            self.UpdateHistory(UI.indexVideo)

            """
            If we do not receive a recent media/video from phone then we call the
                phone to restart it - the phone should have a process running
                that restarts the phone when it is called (from specific 
                numbers, but MAYBE also from general ones).
            """
            try:
                if len(UI.dateTimeStrHistory[UI.indexVideo]) > 0:
                    CallToRestart.Check(
                        UI.dateTimeStrHistory[UI.indexVideo][-1])
            except:
                common.DebugPrintErrorTrace()

            common.DebugPrint(
                "SplitScreenMC::PlayNextVideo(): indexVideo = %d, " \
                    "len(UI.dateTimeStrHistory[UI.indexVideo]) = %d, " \
                    "videoDescriptionStr[indexVideo] = %s, " \
                    "dateTimeStr[indexVideo] = %s, " \
                    "dateTimeStrMax[indexVideo] = %s, dateTimeStrAux = %s, " \
                    "videoFileSize = %d." % (
                        UI.indexVideo,
                        len(UI.dateTimeStrHistory[UI.indexVideo]),
                        UI.videoDescriptionStr[UI.indexVideo],
                        UI.dateTimeStr[UI.indexVideo],
                        UI.dateTimeStrMax[UI.indexVideo],
                        dateTimeStrAux,
                        videoFileSize))

            """            
            common.DebugPrint(
                "len(UI.dateTimeStrHistory[UI.indexVideo])=%d" %
                (len(UI.dateTimeStrHistory[UI.indexVideo])))
            """            

            if len(UI.dateTimeStrHistory[UI.indexVideo]) < \
                        Settings.myCfg.playHowManyTimesSameVideo + 1: # 2 + 1):
                common.DebugPrint(
                    "UI.dateTimeStrMax[UI.indexVideo=%d] = %s =?= dateTimeStrAux = %s" %
                    (UI.indexVideo, UI.dateTimeStrMax[UI.indexVideo], dateTimeStrAux))

                """
                IMPORTANT: We display the video only if it is the most recent
                    (otherwise, if it is an older video, that was sent out of
                    order, we do NOT display it).
                """
                if UI.dateTimeStrMax[UI.indexVideo] == dateTimeStrAux:
                    if UI.DISPLAY_VIDEO:
                        if UI.player[UI.indexVideo] is not None:
                            self.view.releaseVideo_indexVideo = UI.indexVideo

                            if False:
                            #if True:
                                self.view.ReleaseVideo()
                            else:
                                common.DebugPrint( \
                                    "SplitScreenMC::PlayNextVideo(): calling " \
                                    "QtCore.QObject.emit(ReleaseVideo()...)")

                                QtCore.QObject.emit(self, \
                                                    QtCore.SIGNAL("ReleaseVideo()"))


                    #SplitScreen.splitScreen.InitializeVLCVideoWidget()
                    common.DebugPrint(
                        "SplitScreenMC::PlayNextVideo(): I am now before " \
                        "DownloadAndPlayVideoAndSetTitleWithCallable() " \
                        "at %s, indexVideo = %d." % \
                        (common.GetCurrentDateTimeStringWithMillisecondsNice(),
                           UI.indexVideo))

                    if UI.SHOW_PHOTO:
                        def BurstPhotoModeView():
                            while True:
                                """
                                # Inspired from
                                #  C:\Python27\Lib\site-packages\PyQt4\examples\widgets\imageviewer.pyw

                                fileName = QtGui.QFileDialog.getOpenFileName(
                                                            self, "Open File",
                                                    QtCore.QDir.currentPath())
                                """
                                fileName = mediaPathFileName2
                                assert common.DownloadFile(URL, \
                                                    mediaPathFileName2) == 0

                                if fileName:
                                    myImage = QtGui.QImage(fileName)

                                    if myImage.isNull():
                                        QtGui.QMessageBox.information(self,
                                                "Image Viewer",
                                                "Cannot load %s." % fileName)
                                        return

                                    # See http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qlabel.html#setText
                                    UI.videoTitle[UI.indexVideo].setText(
                                        UI.videoDescriptionStr[UI.indexVideo])

                                    """
                                    # Works
                                    UI.videoTitle[UI.indexVideo].setPixmap(
                                        QtGui.QPixmap.fromImage(myImage))
                                    """

                                    # UI.vlcVideo[UI.indexVideo] is a ...!!
                                    UI.vlcVideo[UI.indexVideo].setPixmap( \
                                            QtGui.QPixmap.fromImage(myImage))

                                    # scaleFactor = 1.0

                                    # self.printAct.setEnabled(True)
                                    # self.fitToWindowAct.setEnabled(True)
                                    # self.updateActions()

                                    """
                                    if not self.fitToWindowAct.isChecked():
                                        self.imageLabel.adjustSize()
                                    """

                        t = threading.Timer(0.1, BurstPhotoModeView)
                        t.start()
                    else:
                        """
                        DownloadAndPlayVideoAndSetTitle3(
                            URL,
                            UI.mediaPathFileName[UI.indexVideo],
                            UI.vlcVideo[UI.indexVideo],
                            UI.videoTitle[UI.indexVideo],
                            UI.dateTimeStr[UI.indexVideo], UI.indexVideo)

                        DownloadAndPlayVideoAndSetTitleWithCallable(
                            URL,
                            UI.mediaPathFileName[UI.indexVideo],
                            videoFileSize,
                            UI.vlcVideo[UI.indexVideo],
                            UI.videoTitle[UI.indexVideo],
                            UI.dateTimeStr[UI.indexVideo], UI.indexVideo,
                            PlayNextVideo)
                        """
                        res2 = self.DownloadAndPlayVideoAndSetTitleWithCallable(
                            URL,
                            UI.mediaPathFileName[UI.indexVideo],
                            videoFileSize,
                            UI.vlcVideo[UI.indexVideo],
                            UI.videoTitle[UI.indexVideo],
                            UI.videoDescriptionStr[UI.indexVideo],
                            UI.indexVideo,
                            None) #self.PlayNextVideo)
                            #!!!!TODO: think if OK: IMPORTANT: now we use None for callable since we do forever loop and call play next here in SplitScreenMC

                        common.DebugPrint(
                            "SplitScreenMC::PlayNextVideo(): " \
                            "DownloadAndPlayVideoAndSetTitleWithCallable() " \
                            "returned %d at %s, indexVideo = %d." % \
                            (res2,
                            common.GetCurrentDateTimeStringWithMillisecondsNice(),
                            UI.indexVideo))

                        """
                        In case playing the video returned an error, we report
                            it higher to continue playing.
                        """
                        if res2 == -1:
                            res = -1

                        """
                        # These output [], maybe because related functions in
                        #    vlc.py are marked with @bug - e.g., see 
                        #    "def vlm_get_media_instance_title"
                        print UI.player[UI.indexVideo].video_get_title_description()
                        print UI.player[UI.indexVideo].video_get_track_description()
                        """
                else:
                    """
                    common.DebugPrint("PlayNextVideo(): ." % \
                            (common.GetCurrentDateTimeStringWithMillisecondsNice(),
                                UI.indexVideo))
                    """
                    res = -1
                    if False:
                        self.MediaFinishedPlayingEventHandlerWithCallable(
                                                self.PlayNextVideo)(None, None)
            else:
                """
                In case we don't play the video again, we don't call
                    MediaFinishedPlayingEventHandlerWithCallable, but return -1
                """
                res = -1
                if False:
                    self.MediaFinishedPlayingEventHandlerWithCallable(
                                                self.PlayNextVideo)(None, None)

            if False:
                #self.DrawRectangle()
                SplitScreen.splitScreen.SetVideoTitleAndDrawRectangle()
            else:
                """
                We call SplitScreen.splitScreen.DrawRectangle(), which is in
                  another thread, through the use of signals.
                  As expected, the signal string name specified has to be the
                    same in emit and connect.

                See specs on architecture about multithreaded Qt apps.
                Inspired from
                    http://stackoverflow.com/questions/2823112/communication-between-threads-in-pyside
                """
                QtCore.QObject.emit(self,
                            QtCore.SIGNAL("SetVideoTitleAndDrawRectangle()"))

                common.DebugPrint("SplitScreenMC::PlayNextVideo(): " \
                        "Signalled SetVideoTitleAndDrawRectangle().")

            #PlayVideoComplete("2010_06_22_16_05_29_1.3gp", UI.vlcVideo[1])
            #print "11111"
            """
            if UI.vlcVideo[1]:
                print "Deleting vlcVideo[1]"
                UI.vlcVideo[1] = None
            """
        except:
            res = -1
            """
            common.DebugPrint("Not able to use socket.setdefaulttimeout() - maybe " \
                        "because running on PyS60 1.4.5.")
            """
            common.DebugPrintErrorTrace()

        return res
