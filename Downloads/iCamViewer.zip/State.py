import common
import struct
import sys
import time
import traceback

# sizeStateMarshalled
statePackFormat00 = "<i"

# Reserved for: media file size, CRC32, etc #IMPORTANT NOTE: b = signed char.
statePackFormat01 = "<bbbbiiiiibbbbbbbb"

# accessPointName, tmpBluetoothServerAddress, cameraId
statePackFormat02 = "<50s20si"

# crtTime.tm_year, crtTime.tm_mon, crtTime.tm_mday, crtTime.tm_hour,
#   crtTime.tm_min, crtTime.tm_sec, numMilliseconds
statePackFormat03 = "<iiiiiii"

# GetBatteryLevelPercentage(), main_drive_free_space, memory_card_free_space,
#   GetFreeRAM(), 0, sysagent.charger_status()
statePackFormat04 = "<iqqiii"

# The 2s is for the signalUnits. signalStrength
statePackFormat05 = "<2si"

# pauseIntervalBetweenGoogleGdataMediaUploads,pauseInterval,burstModeIsStarted,
#   photoResolutionIndex, 0, localPhotoResolutionIndex[0],
#   localPhotoResolutionIndex[1], photoModeIndex[0]
statePackFormat06 = "<iiiiiiii"

# photoModeIndex[1], digitalZoom, 0, photoQuality, 0, exposureIndex[0],
#   exposureIndex[1]
statePackFormat07 = "<iiiiiii"

# whiteBalanceIndex[0], whiteBalanceIndex[1], flashIndex, 0
statePackFormat08 = "<iiii"

# 0, 0, 0, 0, 0, 0, 0, 0. Indices for:
# ExposureCompensation, ISO, contrast, sharpness, color tone, Scene Modes
statePackFormat09 = "<32s32s32s32s"
# Reserved (ex: ShutterSpeed)
# Reserved: indices for localVideoMode (VideoFrameRates, VideoEncoding),
#   Video Stabilization, Audio Recording, etc
# (Note: Camera app on S60 on N82 has presets: TV High Quality,
#   TV Normal Quality, Email High Quality, Email Normal Quality,
#   Sharing Quality)
# Reserved (ex: sent videoResolution)

# videoRecordDuration[0], videoRecordDuration[1], localVideoModeIndex[0],
#   localVideoModeIndex[1], cameraMode[0], cameraMode[1], videoAudioEnabled,
#   0 (maybe videoAudioEnabled camera with id 1),
statePackFormat10 = "<iiiibbbb"

# Reserved (ex: audioType - MP3 or AMR)
statePackFormat11 = "<20s"

# audioRecordDuration, 0, 0, 0, 0, 0, 0 (reserved for other durations)
statePackFormat12 = "<i24s"

# rotateDegreesImage, the rest is reserved
statePackFormat13 = "<i28s"

# mobileCountryCode, mobileNetworkCode, locationAreaCode, cellId
statePackFormat14 = "<iiii"

# Reserved
statePackFormat15 = "<32s"

# storeLocallyMedia. And reserved for "Choose when to send Unsent", plugged
#   and charging or not
statePackFormat16 = "<i28s"

# motionDetectionIsOn, differentPixelsPercentageThreshold[0];
# Reserved for noiseDetectionEnabled, faceDetection,
#   soundDetection (a human talking, a dog barking, a bird singing)
statePackFormat17 = "<if24s"

# Reserved for motion detection params (thresholds, etc)
statePackFormat18 = "<32s32s32s32s"
# Reserved for the result(s) returned by the simple detection algorithm(s).
# Reserved for the result(s) returned by the simple detection algorithm(s).
# Reserved for the result(s) returned by the simple detection algorithm(s).

# Reserved (ex: readGPS)
statePackFormat19 = "<32s"

# GPS data (gpsInfo)
statePackFormat20 = "<dddddddddddddii"

# Reserved for gps related.
statePackFormat21 = "<32s32s"

# logAccelerometerAndRotationSensors, and reserved
statePackFormat22 = "<i28s"

# 14 * 32 bytes (strings) reserved. fileName
# statePackFormat23 = "<32s32s32s32s32s32s32s32s32s32s32s32s32s32s256s"
# 13 * 32 bytes (strings) reserved.
statePackFormat23 = "<32s32s32s32s32s32s32s32s32s32s32s32s32s"

# Reserved dawnTimeVec[0], dawnTimeVec[1], dawnTimeVec[2], 0, duskTimeVec[0],
#   duskTimeVec[1], duskTimeVec[2], 0
statePackFormat24 = "<20sbbbbbbbb"

# statePackFormat25 = "<i256s" #mediaFileSize, fileName.
# mediaFileSize, fileName, PHP_SERVER_NAME
statePackFormat25 = "<i128s128s"

statePackFormat = statePackFormat00 + statePackFormat01[1:] \
    + statePackFormat02[1:] + statePackFormat03[1:] \
    + statePackFormat04[1:]
statePackFormat += statePackFormat05[1:] + statePackFormat06[1:] \
    + statePackFormat07[1:] + statePackFormat08[1:] \
    + statePackFormat09[1:]
statePackFormat += statePackFormat10[1:] + statePackFormat11[1:] \
    + statePackFormat12[1:] + statePackFormat13[1:] \
    + statePackFormat14[1:]
statePackFormat += statePackFormat15[1:] + statePackFormat16[1:] \
    + statePackFormat17[1:] + statePackFormat18[1:] \
    + statePackFormat19[1:]
statePackFormat += statePackFormat20[1:] + statePackFormat21[1:] \
    + statePackFormat22[1:] + statePackFormat23[1:] \
    + statePackFormat24[1:]
statePackFormat += statePackFormat25[1:]





mobileCountryCode = -1
mobileNetworkCode = -1
locationAreaCode = -1
cellId = -1
batteryLevelPercentage = -1
mainDriveFreeSpace = -1
memoryCardFreeSpace = -1
freeRAM = -1
chargerStatus = -1


tm_year = -1
tm_mon = -1
tm_mday = -1
tm_hour = -1
tm_min = -1
tm_sec = -1
numMilliseconds = -1

fileNameStr = None


def GetStateTime():
    stateTime = time.localtime(time.mktime((
                                tm_year, tm_mon, tm_mday,
                                tm_hour, tm_min, tm_sec,
                                -1, -1, -1)))
    return stateTime


def LoadStateFromFile(pathFileName):
    global mobileCountryCode, mobileNetworkCode, locationAreaCode, \
        cellId
    global batteryLevelPercentage, mainDriveFreeSpace, \
        memoryCardFreeSpace, freeRAM, chargerStatus
    global tm_year, tm_mon, tm_mday, tm_hour, tm_min, tm_sec, \
            numMilliseconds
    global fileNameStr

    common.DebugPrint(
        "Entered LoadStateFromFile(pathFileName = %s)." % pathFileName)

    try:
        fInput = open(pathFileName, "rb")
        stateFileData = fInput.read()
        fInput.close()
    except:
        #fileData = fileData.decode("zlib")
        common.DebugPrintErrorTrace()

    localPhotoResolutionIndex = [None, None]
    photoModeIndex = [None, None]
    exposureIndex = [None, None]
    whiteBalanceIndex = [None, None]
    videoRecordDuration = [None, None]
    localVideoModeIndex = [None, None]
    cameraMode = [None, None]
    differentPixelsPercentageThreshold = [None]
    dawnTimeVec = [None, None, None]
    duskTimeVec = [None, None, None]

    #(sizeStateMarshalled,
    (
        # Reserved for: media file size, CRC32, etc
        _, _, _, internetUploadMaxErrors, BATTERY_LEVEL_THRESHOLD, _, _, _,
        uploadHowManyOfLatestBluetoothMessages, modeManagerIsEnabled,
        startAutomatically, saveUnsentPackets, uploadUnsentData,
        MY_DEBUG_STDOUT, MY_DEBUG_STDERR, MY_DEBUG_STDERR_2,
        MY_DEBUG_UPLOAD_MSG,

        accessPointName, bluetoothServerAddress, _, # cameraId,

        tm_year, tm_mon, tm_mday,
        #_, _, _,
        tm_hour, tm_min, tm_sec, numMilliseconds,
        #_, _, _, _,

        # GetBatteryLevelPercentage(), main_drive_free_space,
        #   memory_card_free_space, GetFreeRAM(), 0, charger_status,
        _, _, _, _, _, _,

        # signalUnits, signalStrength,
        _, _,

        pauseIntervalBetweenGoogleGdataMediaUploads, pauseInterval,

        # burstModeIsStarted, photoResolutionIndex, _, ...
        _, photoResolutionIndex, _, localPhotoResolutionIndex[0],
        localPhotoResolutionIndex[1], photoModeIndex[0],

        # First _ is for opticalZoom
        photoModeIndex[1], digitalZoom, _, photoQuality, _,

        exposureIndex[0], exposureIndex[1],
        whiteBalanceIndex[0], whiteBalanceIndex[1], flashIndex,
        startViewfinderBeforeTakingPhoto,

        #"", (0, 0, 0, 0, 0, 0, 0, 0,) - Indices for:
        #   ExposureCompensation, ISO, contrast, sharpness, color tone,
        #   Scene Modes
        _,

        #"", #0, 0, 0, 0, 0, 0, 0, 0, - Reserved (ex: ShutterSpeed)
        _,

        #"", #0, 0, 0, 0, 0, 0, 0, 0, - Indices for
        #   localVideoMode (VideoFrameRates, VideoEncoding),
        #   Video Stabilization, Audio Recording, etc
        #   (Note: Camera app on S60 on N82 has presets: TV High Quality,
        #   TV Normal Quality, Email High Quality, Email Normal Quality,
        #   Sharing Quality)
        _,

        #"", 0, 0, 0, 0, 0, 0, 0, 0, - Reserved (ex: sent videoResolution)
        _,

        videoRecordDuration[0], videoRecordDuration[1],
        localVideoModeIndex[0], localVideoModeIndex[1],
        cameraMode[0], cameraMode[1], videoAudioEnabled, _,

        #"" (0, 0, 0, 0, 0, 0, 0, 0,) - Reserved
        #   (ex: audioType - MP3 or AMR)
        _,

        #"" (0, 0, 0, 0, 0, 0,) - Reserved for other durations
        audioRecordDuration, _,

        # rotateDegreesImage, "" (0, 0, 0, 0, 0, 0, 0,)
        rotateDegreesImage, _,

        # mobileCountryCode, mobileNetworkCode, locationAreaCode, cellId,
        _, _, _, _,

        #"" (0, 0, 0, 0, 0, 0, 0, 0,) - reserved
        _,

        #storeLocallyMedia, "", (0, 0, 0, 0, 0, 0, 0)
        #   Reserved for choose when to send Unsent, plugged and charging
        #   or not
        storeLocallyMedia, _,

        # "" (0, 0, 0, 0, 0, 0, 0,) - Reserved for noiseDetectionEnabled,
        #   faceDetection, soundDetection (a human talking, a dog barking,
        #   a bird singing)
        motionDetectionIsOn, differentPixelsPercentageThreshold[0], _,

        #"" (0, 0, 0, 0, 0, 0, 0, 0,) - Reserved for motion detection
        #   params (thresholds, etc)
        _,

        #"" (0, 0, 0, 0, 0, 0, 0, 0,) - Reserved for the result(s)
        #   returned by the simple detection algorithm(s)
        _,

        #"" (0, 0, 0, 0, 0, 0, 0, 0,) - Reserved for the result(s)
        #   returned by the simple detection algorithm(s)
        _,

        #"" (0, 0, 0, 0, 0, 0, 0, 0,) - Reserved for the result(s)
        #   returned by the simple detection algorithm(s)
        _,

        #"" (0, 0, 0, 0, 0, 0, 0, 0,) - Reserved (ex: readGPS)
        _,

        _, # gpsInfo["position"]["latitude"],
        _, # gpsInfo["position"]["longitude"],
        _, # gpsInfo["position"]["altitude"],
        _, # gpsInfo["position"]["vertical_accuracy"],
        _, # gpsInfo["position"]["horizontal_accuracy"],
        _, # gpsInfo["course"]["speed"],
        _, # gpsInfo["course"]["heading"],
        _, # gpsInfo["course"]["heading_accuracy"],
        _, # gpsInfo["course"]["speed_accuracy"],
        _, # gpsInfo["satellites"]["horizontal_dop"],
        _, # gpsInfo["satellites"]["vertical_dop"],
        _, # gpsInfo["satellites"]["time_dop"],
        _, # gpsInfo["satellites"]["time"],
        _, # gpsInfo["satellites"]["used_satellites"],
        _, # gpsInfo["satellites"]["satellites"],
        _, # 0, 0, 0, 0, 0, 0, 0, 0, - reserved
        _, # 0, 0, 0, 0, 0, 0, 0, 0, - reserved

        # logAccelerometerAndRotationSensors, "" (0, 0, 0, 0, 0, 0, 0,)
        #   reserved (ex: light sensor, temperature, humidity,
        #   body physiology, tap sensor, gyro, etc)
        _, _,

        _, # 0, 0, 0, 0, 0, 0, 0, 0, reserved
        _, # 0, 0, 0, 0, 0, 0, 0, 0, reserved for values of these sensors
        _, # 0, 0, 0, 0, 0, 0, 0, 0, reserved for values of these sensors
        _, # 0, 0, 0, 0, 0, 0, 0, 0, reserved for values of these sensors
        _, # 0, 0, 0, 0, 0, 0, 0, 0, reserved for values of these sensors
        _, # 0, 0, 0, 0, 0, 0, 0, 0, reserved for values of these sensors
        _, # 0, 0, 0, 0, 0, 0, 0, 0, reserved for values of these sensors
        _, # 0, 0, 0, 0, 0, 0, 0, 0, reserved for values of these sensors
        _, # 0, 0, 0, 0, 0, 0, 0, 0, reserved for values of these sensors
        _, # 0, 0, 0, 0, 0, 0, 0, 0, reserved for values of these sensors
        _, # 0, 0, 0, 0, 0, 0, 0, 0, reserved for values of these sensors
        _, # 0, 0, 0, 0, 0, 0, 0, 0, reserved for values of these sensors
        _, # 0, 0, 0, 0, 0, 0, 0, 0, reserved for values of these sensors

        _, dawnTimeVec[0], dawnTimeVec[1], dawnTimeVec[2], _,
        duskTimeVec[0], duskTimeVec[1], duskTimeVec[2], _, #"" (20s), etc

        _, _, PHP_SERVER_NAME #mediaFileSize, fileNameStr, PHP_SERVER_NAME
    ) = struct.unpack(statePackFormat,
        # Length of string given as arg in unpack() must be calcsize(fmt).
        stateFileData[0 : struct.calcsize(statePackFormat)])

    """
    Length of the string given as argument in unpack() must equal
        calcsize(fmt)
    """
    fileNameStr = fileNameStr.rstrip(" ")
    """
    common.DebugPrint(
        "LoadStateFromFile(): tm_year = %d, tm_mon = %d, tm_mday = %d," \
        " tm_hour = %d, tm_min = %d, tm_sec = %d, numMilliseconds = %d." % \
            (tm_year, tm_mon, tm_mday,
                tm_hour, tm_min, tm_sec, numMilliseconds))
    """
    common.DebugPrint(
        "LoadStateFromFile(): At %02d:%02d:%02d.%03d %02d-%02d-%d " \
        "we have:\n" % (
            tm_hour, tm_min, tm_sec,
            numMilliseconds,
            tm_mday, tm_mon, tm_year) + \

        "    batteryLevelPercentage = %d, mainDriveFreeSpace = %d, " \
        "memoryCardFreeSpace = %d, freeRAM = %d, chargerStatus = %d.\n" % \
            (batteryLevelPercentage, mainDriveFreeSpace,
                memoryCardFreeSpace, freeRAM, chargerStatus) + \

        "    mobileCountryCode = %d, mobileNetworkCode = %d, " \
            "locationAreaCode = %d, cellId = %d." % (mobileCountryCode,
                mobileNetworkCode, locationAreaCode, cellId))
    """
    #From GoogleAppEngine application:
    deviceIdTuple = struct.unpack(myFormatDeviceId,
                        stateFileData[0 : struct.calcsize(myFormatDeviceId)])

    self.deviceId = deviceIdTuple[0]

    firstNullCharIndex = self.deviceId.find("\x00")
    self.deviceId = self.deviceId[0 : firstNullCharIndex]

    statePackFormat03_1 = statePackFormat03[1 : ]
    statePackFormatPartial = myFormatDeviceId + statePackFormat00[1 : ] + \
                            statePackFormat01[1 : ] + statePackFormat02[1 : ]

    (tm_year, tm_mon, tm_mday, tm_hour, tm_min, tm_sec, numMilliseconds) = \
        struct.unpack(statePackFormat03_1,
            stateFileData[struct.calcsize(statePackFormatPartial) : \
                            struct.calcsize(statePackFormatPartial) +
                            struct.calcsize(statePackFormat03_1)])

    self.mediaTimeStr = "%02d:%02d:%02d.%03d" % (tm_hour, tm_min, tm_sec,
                                                    numMilliseconds)

    self.mediaDateStr = "%02d-%02d-%04d" % (tm_mday, tm_mon, tm_year)

    statePackFormatPartial = myFormatDeviceId + statePackFormat00[1 : ] + \
                            statePackFormat01[1 : ] + \
                            statePackFormat02[1 : len(statePackFormat02) - 1]

    statePackFormat02_1 = statePackFormat02[len(statePackFormat02) - 1 : ]

    (cameraIdStr, ) = struct.unpack(statePackFormat02_1,
                    stateFileData[struct.calcsize(statePackFormatPartial) : \
                        struct.calcsize(statePackFormatPartial) + \
                        struct.calcsize(statePackFormat02_1)])

    self.cameraId = int(cameraIdStr)

    #accessPointName, tmpBluetoothServerAddress, fileNameStr, cameraId
    #statePackFormat02 = "<50s20si"

    statePackFormatPartial = myFormatDeviceId + statePackFormat[1 : \
                                                    len(statePackFormat) - 8]

    statePackFormat_1 = statePackFormat[len(statePackFormat) - 8 : \
                                                    len(statePackFormat) - 4]

    (self.fileName, ) = struct.unpack(statePackFormat_1,
                    stateFileData[struct.calcsize(statePackFormatPartial) : \
                    struct.calcsize(statePackFormatPartial) +
                    struct.calcsize(statePackFormat_1)])

    firstNullCharIndex = self.fileName.find("\x00")
    self.fileName = self.fileName[0 : firstNullCharIndex]
    """

    """
    //From lib.inc.php:
    //1660 + 4 bytes (4 bytes for size serialized data).
    if (strlen($stateMarshalled) == 1660) {
        /* 0, uploadHowManyOfLatestBluetoothMessages, 0, startAutomatically, 
        modeManagerIsEnabled, uploadUnsentData, common.MY_DEBUG_STDOUT,
        common.MY_DEBUG_STDERR, common.MY_DEBUG_STDERR_2,
        MY_DEBUG_UPLOAD_MSG */

        $format = "a12reserved0/VmediaFileSize/a16reserved002/" .
                  "a50accessPointName/a20blueToothServerAddress/VcameraId/" .
                  "Vyear/Vmonth/Vday/Vhour/Vminute/Vsecond/VnumMilliseconds/" .
                  "Vbattery/VfreeMainDriveSpaceLowerInt/" .

                  "VfreeMainDriveSpaceUpperInt/VfreeMemCardDriveSpaceLowerInt/" .
                    "VfreeMemCardDriveSpaceUpperInt/VfreeRAM/VfreeRAMUpperInt/" .
                    "VchargerStatus/" .

                  "a2signalUnits/VsignalStrength/" .

                  "VpauseIntervalBetweenGoogleGdataUploads/VpauseInterval/" .
                    "VcuIndex/VresolutionIndex/VresolutionIndex1/" .
                    "VlocalResolutionIndex0/VlocalResolutionIndex1/" .

                  "VimageModeIndex0/VimageModeIndex1/VzoomIndex/VdigitalZoom/" .
                    "VphotoQuality/VphotoQuality1/VexposureIndex0/VexposureIndex1/" .

                  "VwhiteBalanceIndex0/VwhiteBalanceIndex1/VflashIndex/VflashIndex1/" .
                  "a32reserved1/" .
                  "a32reserved2/" .
                  "a32reserved3/" .
                  "a32reserved4/" .
                  "VvideoRecordDuration0/VvideoRecordDuration1/" .
                  "a32reserved5/" .
                  "VaudioRecordDuration/a24reserved6/" .
                  "VrotateDegreesImage/a28reserved7/" .
                  "VmobileCountryCode/VmobileNetworkCode/VlocationAreaCode/VcellId/" .
                  "a32reserved8/" .
                  "a32reserved9/" .
                  "VmotionDetectionIsOn/a28reserved10/" .
                  "a32reserved11/" .
                  "a32reserved12/" .
                  "a32reserved13/" .
                  "a32reserved14/" .
                  "a32reserved15/" .

                  "dGPS_position_latitude/dGPS_position_longitude/" .
                    "dGPS_position_altitude/dGPS_position_vertical_accuracy/" .

                  "dGPS_position_horizontal_accuracy/dGPS_course_speed/" .
                    "dGPS_course_heading/dGPS_course_heading_accuracy/" .

                  "dGPS_course_speed_accuracy/dGPS_satellites_horizontal_dop/" .
                    "dGPS_satellites_vertical_dop/dGPS_satellites_time_dop/" .

                  "dGPS_satellites_time/VGPS_satellites_used_satellites/" .
                    "VGPS_satellites_satellites/" .

                  "a32reserved16/" .
                  "a32reserved17/" .
                  "VlogAccelerometerAndRotationSensors/a28reserved18/" .
                  "a32reservedA1/" .
                  "a32reservedA2/" .
                  "a32reservedA3/" .
                  "a32reservedA4/" .
                  "a32reservedA5/" .
                  "a32reservedA6/" .
                  "a32reservedA7/" .
                  "a32reservedA8/" .
                  "a32reservedA9/" .
                  "a32reservedA10/" .
                  "a32reservedA11/" .
                  "a32reservedA12/" .
                  "a32reservedA13/" .
                  "a32reservedA14/a128filename/a128serverName";

        $associativeArray = unpack($format, $stateMarshalled);
    """
