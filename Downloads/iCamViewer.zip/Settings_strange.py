import common
import pickle
import sys
import traceback



PHP_SERVER_NAME = "mobile-revival.110mb.com"
WEB_FOLDER = "/ReVival"
# """
"""
PHP_SERVER_NAME = "alexsusu.110mb.com"
WEB_FOLDER = "/iCam"
"""



SETTINGS_FILENAME = None


notLoadedSettings = False



def GlobalLoadSettings(settingsInstance):
    print "id(settingsInstance) =", id(settingsInstance)

    try:
        if common.MY_DEBUG_STDOUT:
            print "Entered GlobalLoadSettings(): " \
                "settingsInstance.audioVolume = %d." % \
                settingsInstance.audioVolume
            sys.stdout.flush()

        """
        Inspired from second example at 
            http://docs.python.org/library/pickle.html at 11.1.7:
        """
        fInput = open(SETTINGS_FILENAME, "rb")

        """
        mySettingsTmp = pickle.load(fInput)
        mySettings.audioVolume = mySettingsTmp.audioVolume
        """
        #print "dir(settingsInstance) = %s" % str(dir(settingsInstance))
        settingsInstance = pickle.load(fInput)
        fInput.close()

        if common.MY_DEBUG_STDOUT:
            print "LoadSettings(): settingsInstance.audioVolume = %d." % \
                                                settingsInstance.audioVolume
            sys.stdout.flush()
    except:
        global notLoadedSettings

        notLoadedSettings = True

        if common.MY_DEBUG_STDERR:
            traceback.print_exc()
            sys.stderr.flush()

    if common.MY_DEBUG_STDOUT:
        print "GlobalLoadSettings(): After load: \n" \
            "   settings.mediaServer = %s,\n" \
            "   settings.audioVolume = %d,\n" \
            "   settings.audioMute = %d,\n" \
            "   settings.NUM_VIDEOS = %d,\n" \
            "   settings.PAUSE_BETWEEN_MOVIES = %d,\n" \
            "   settings.deviceId = %s." % (
                settingsInstance.mediaServer,
                settingsInstance.audioVolume,
                settingsInstance.audioMute,
                settingsInstance.NUM_VIDEOS,
                settingsInstance.PAUSE_BETWEEN_MOVIES,
                str(settingsInstance.deviceId)
            )
        sys.stdout.flush()







#rotateVal = ["0", "90", "180", "270"]
class Settings:
    audioVolume = 200
    audioMute = 0
    NUM_VIDEOS = 4 # 5

    #PAUSE_INTERVAL = 2.0 # in seconds
    #PAUSE_INTERVAL = 30.0 # in seconds

    # PAUSE_BETWEEN_MOVIES = 0.1
    PAUSE_BETWEEN_MOVIES = 5.0
    # PAUSE_BETWEEN_MOVIES = 10.0

    playHowManyTimesSameVideo = 2
    titleFontSize = 15
    googleUsername = None
    googlePasswordEncrypted = None
    iCamServerAddress = PHP_SERVER_NAME

    # One more element for slideshow.
    mediaServer = [
        0,
        0,
        0,
        0,
        0,
        0
        ]

    # GetPhoneModel() #"Android device"
    youtubeGroupKeywords = ""

    deviceId = [
                #"N95N95N95N95N95",
                "668066806680668", #"", #"668066806680668", 
                "668066806680668", #"", #"668066806680668", 
                "612061206120612", #"", #"612061206120612", 
                "612061206120612", #"", #"612061206120612"
                "N82N82N82N82N82",
                "N82N82N82N82N82"
        ]

    cameraId = [
            0,
            1,
            0,
            1,
            0,
            1
            #0
        ]

    rotateDegrees = [
            0,
            0,
            0,
            0,
            0, # One more element for slideshow.
            0
        ]

    brightness = [
            1.0,
            1.0,
            1.0,
            1.0,
            1.0, # One more element for slideshow.
            1.0
        ]

    contrast = [
            1.0,
            1.0,
            1.0,
            1.0,
            1.0, # One more element for slideshow.
            1.0
        ]

    hue = [
            1.0,
            1.0,
            1.0,
            1.0,
            1.0, # One more element for slideshow.
            1.0
        ]

    saturation = [
            1.0,
            1.0,
            1.0,
            1.0,
            1.0, # One more element for slideshow.
            1.0
        ]

    gamma = [
            1.0,
            1.0,
            1.0,
            1.0,
            1.0, # One more element for slideshow.
            1.0
        ]

    videoAnalysis = 0
    videoAnalysisShowDifferences = 0
    audioAnalysis = 0

    """
    NUM_VIDEOS = 3
    deviceId = [
                "N95N95N95N95N95",
                "612061206120612",
                "612061206120612",
                "N82N82N82N82N82", 
                #"668066806680668",
                "668066806680668", 
                "612061206120612"
    ]

    cameraId = [
                0,
                0,
                1,
                0
    ]
    """

    """
    NUM_VIDEOS = 4
    #NUM_VIDEOS = 3
    #NUM_VIDEOS = 1
    #PAUSE_INTERVAL = 2.0 #in seconds
    #PAUSE_INTERVAL = 30.0 #in seconds
    FALSE = 0

    deviceId = [
                #"N95N95N95N95N95",
                "668066806680668", 
                "668066806680668", 
                "612061206120612", 
                "612061206120612"
                #"N82N82N82N82N82"
    ]

    cameraId = [
                0,
                1,
                0,
                1
                #0
    ]
    """


    def __init__(self, aSettingsFileName):
        global SETTINGS_FILENAME

        SETTINGS_FILENAME = aSettingsFileName

        if common.MY_DEBUG_STDOUT:
            print "aSettingsFileName = %s." % aSettingsFileName
            sys.stdout.flush()


    def StoreSettings(self):
        """
        if common.MY_DEBUG_STDOUT:
            print "StoreSettings(): self.NUM_VIDEOS = %d." \
                                % self.NUM_VIDEOS

            print "StoreSettings(): self.deviceId = %s" % self.deviceId
            sys.stdout.flush()
        """
        try:
            self.titleFontSize = self.titleFontSize
            """
            #!!!!
            #When value of self.titleFontSize changes, I should give:
            for index in range(5!!!!):
                #See http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qfont.html:
                #   "__init__ (self, QString family, int pointSize = -1,
                #               int weight = -1, bool italic = False)"
                videoTitle[index].setFont(QtGui.QFont("Courier",
                                            self.titleFontSize, 50, False))
            """

            """
            It seems I need to execute these operations in order to pickle
              all data members of class Settings. Strange!!!!
            """
            self.audioVolume = self.audioVolume
            self.audioMute = self.audioMute
            self.NUM_VIDEOS = self.NUM_VIDEOS
            self.PAUSE_BETWEEN_MOVIES = \
                self.PAUSE_BETWEEN_MOVIES
            self.playHowManyTimesSameVideo = \
                self.playHowManyTimesSameVideo
            self.deviceId = self.deviceId
            self.cameraId = self.cameraId
            self.mediaServer = self.mediaServer
            self.googleUsername = self.googleUsername
            self.googlePasswordEncrypted = \
                self.googlePasswordEncrypted
            self.iCamServerAddress = self.iCamServerAddress
            self.videoAnalysis = self.videoAnalysis
            self.videoAnalysisShowDifferences = \
                self.videoAnalysisShowDifferences
            self.audioAnalysis = self.audioAnalysis

            # self.rotateIndex = self.rotateIndex
            self.rotateDegrees = self.rotateDegrees
            self.brightness = self.brightness
            self.contrast = self.contrast
            self.hue = self.hue
            self.saturation = self.saturation
            self.gamma = self.gamma

            # Inspired from first example at
            #    http://docs.python.org/library/pickle.html at 11.1.7:
            fOutput = open(SETTINGS_FILENAME, "wb")

            # Pickle using protocol 0.
            pickle.dump(self, fOutput)
            fOutput.close()
        except:
            if common.MY_DEBUG_STDERR:
                traceback.print_exc()
                sys.stderr.flush()


    def LoadSettings(self):
        """
        self = pickle.load(fInput) gave following exception, so we use do this
            operation outside the class:

        Traceback (most recent call last):
          File "Z:\1PhD\ReVival\iCamViewer\Settings.py", line 268, in LoadSettings
            self = pickle.load(fInput)
          File "C:\Python27\lib\pickle.py", line 1378, in load
            return Unpickler(file).load()
          File "C:\Python27\lib\pickle.py", line 858, in load
            dispatch[key](self)
          File "C:\Python27\lib\pickle.py", line 1070, in load_inst
            self._instantiate(klass, self.marker())
          File "C:\Python27\lib\pickle.py", line 1060, in _instantiate
            value = klass(*args)
        TypeError: in constructor for Settings: 'module' object is not callable
        """
        GlobalLoadSettings(self)

        print "id(self) =", id(self)
        if common.MY_DEBUG_STDOUT:
            print "LoadSettings(): After load: \n" \
                "   self.mediaServer = %s,\n" \
                "   self.audioVolume = %d,\n" \
                "   self.audioMute = %d,\n" \
                "   self.NUM_VIDEOS = %d,\n" \
                "   self.PAUSE_BETWEEN_MOVIES = %d,\n" \
                "   self.deviceId = %s." % (
                    self.mediaServer,
                    self.audioVolume,
                    self.audioMute,
                    self.NUM_VIDEOS,
                    self.PAUSE_BETWEEN_MOVIES,
                    str(self.deviceId)
                )
            sys.stdout.flush()
