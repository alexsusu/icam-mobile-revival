import common
import os
import Settings
import Slideshow
import shutil
import sys
if common.DO_IMPORT_GDATA:
    import TimeSync
import traceback
import UI

import atom

if common.DO_IMPORT_GDATA:
    import gdata.media
    import gdata.youtube
    import gdata.youtube.service

    """
    Note: import youtube-dl gives syntax error, because of "-" .
    """
    import youtube_dl
    import youtube_dl.__init__




youtubeClient = None
youtubeClientAlreadyConnected = False



def GetUserProfile():
    userEntry = youtubeClient.GetYouTubeUserEntry( \
        "https://gdata.youtube.com/feeds/users/" + Settings.myCfg.googleUsername)

    print "userEntry.description.text = %s" % str(userEntry.description.text)

    """
    print "userEntry =", userEntry
    print "userEntry = %s" % str(userEntry)
    print "userEntry.age.text = %s" % str(userEntry.age.text)
    print "userEntry.author = %s" % str(userEntry.author)
    print "userEntry.books = %s" % str(userEntry.books)
    print "userEntry.category = %s" % str(userEntry.category)
    print "userEntry.company.text = %s" % str(userEntry.company.text)
    print "userEntry.description.text = %s" % str(userEntry.description.text)
    print "userEntry.first_name = %s" % str(userEntry.first_name)
    print "userEntry.last_name = %s" % str(userEntry.last_name)
    print "userEntry.gender.text = %s" % str(userEntry.gender.text)
    print "userEntry.hobbies.text = %s" % str(userEntry.hobbies.text)
    print "userEntry.hometown.text = %s" % str(userEntry.hometown.text)
    print "userEntry.id = %s" % str(userEntry.id)
    print "userEntry.location.text = %s" % str(userEntry.location.text)
    print "userEntry.movies.text = %s" % str(userEntry.movies.text)
    print "userEntry.published.text = %s" % str(userEntry.published.text)
    print "userEntry.relationship = %s" % str(userEntry.relationship)
    print "userEntry.rights = %s" % str(userEntry.rights)
    print "userEntry.school.text = %s" % str(userEntry.school.text)
    print "userEntry.summary = %s" % str(userEntry.summary)
    print "userEntry.title.text = %s" % str(userEntry.title.text)
    print "userEntry.username.text = %s" % str(userEntry.username.text)
    """


    #print "dir(userEntry) = %s" % str(dir(userEntry))
    #
    #self.assert_(isinstance(user, gdata.youtube.YouTubeUserEntry))
    #self.assertEquals(user.location.text, "US")
    #
    #GetUserProfile()


def PrintInfoYouTubeVideo(ytVideo):
    try:
        """
        if False:
            common.DebugPrint(
                "FindMostRecentYouTubeVideo(): dir(ytVideo) = %s" % \
                                            str(dir(ytVideo)))
        """
        if False:
            common.DebugPrint(
                "FindMostRecentYouTubeVideo(): ytVideo = %s" % str(ytVideo))

        print "ytVideo.author =", ytVideo.author
        print "ytVideo.category =", ytVideo.category

        print "ytVideo.category ="
        for el in ytVideo.category:
            print "    " + str(el)

        print "ytVideo.content =", ytVideo.content
        print "ytVideo.contributor =", ytVideo.contributor
        print "ytVideo.control =", ytVideo.control
        print "ytVideo.extension_attributes =", ytVideo.extension_attributes

        print "ytVideo.extension_elements =", ytVideo.extension_elements
        print "ytVideo.extension_elements ="
        for el in ytVideo.extension_elements:
            print "    " + str(el)

        print "ytVideo.id =", ytVideo.id

        print "ytVideo.link =", ytVideo.link
        print "ytVideo.link ="
        for el in ytVideo.link:
            print "    " + str(el)

        #print "ytVideo.media =", ytVideo.media

        print "ytVideo.published =", ytVideo.published
        print "ytVideo.rights =", ytVideo.rights
        print "ytVideo.source =", ytVideo.source
        print "ytVideo.summary =", ytVideo.summary
        print "ytVideo.text =", ytVideo.text
        print "ytVideo.title =", ytVideo.title
        print "ytVideo.updated =", ytVideo.updated

        """
        # None of the following work:
        #print ytVideo.id.attributes

        # VideoFeed is empty list
        #UI.videoIdStrList[UI.indexVideo] = \
        #                       ytVideo.id.FindExtensions(tag="id")

        # VideoFeed is empty list
        #UI.videoIdStrList[indexVideo] = ytVideo.id.FindExtensions()

        # VideoFeed is empty list
        #UI.videoIdStrList[UI.indexVideo] = \
        #               ytVideo.id.FindExtensions(namespace="ns0")

        # videoFeed is empty list
        #UI.videoIdStrList[UI.indexVideo] = \
        #           ytVideo.id.FindExtensions(namespace="ns0:id")

        # videoFeed is empty list
        #UI.videoIdStrList[indexVideo] = ytVideo.id.FindExtensions(
        #                               tag="id", namespace="ns0")

        #AttributeError: 'Id' object has no attribute 'FindChildren'
        #UI.videoIdStrList[UI.indexVideo] = \
        #                       ytVideo.id.FindChildren(tag="id")

        # AttributeError: 'Id' object has no attribute 'attributes'
        #UI.videoIdStrList[UI.indexVideo] = ytVideo.id.attributes["id"]

        #print "videoIdStrList[indexVideo] = %s" % \
        #                   str(UI.videoIdStrList[UI.indexVideo])
        """
        try:
            mediaGroup = ytVideo.FindExtensions(tag="group")

            if len(mediaGroup) > 0:
                titleChild = \
                    mediaGroup[0].FindChildren(tag="title")

                if len(titleChild) > 0:
                    print mediaGroup[0].FindChildren(tag="title"
                            )[0].text

                for content in \
                        mediaGroup[0].FindChildren(tag="content"):
                    print content.attributes["url"]

                content = \
                    mediaGroup[0].FindChildren(tag="content")[1]
            sys.stdout.flush()
        except:
            pass
            #common.DebugPrintErrorTrace()
        # """
    except:
        common.DebugPrintErrorTrace()


def PrintInfoYouTubeVideoEntry(ytVideoEntry):
    try:
        """
        YouTubeVideoEntry at
          https://gdata-python-client.googlecode.com/svn/trunk/pydocs/gdata.youtube.html#YouTubeVideoEntry

        This is the complete XML descriptor of ytVideoEntry
        #print "FindMostRecentYouTubeVideo(): ytVideoEntry = %s" % \
        #    str(ytVideoEntry)

        From https://code.google.com/apis/youtube/1.0/developers_guide_python.html#RetrievingVideoInfo

        The fields/info available in YouTubeVideoEntry is discussed in:
            https://developers.google.com/youtube/articles/youtube_api_appengine
        """
        common.DebugPrint(
            "    Video duration: %d\n" % \
                int(ytVideoEntry.media.duration.seconds) + \
            "    Video title: %s\n" % \
                ytVideoEntry.media.title.text)

        common.DebugPrint(
            "    Video published on: %s\n" % \
                        ytVideoEntry.published.text + \
            "    Video description: %s\n" % \
                        ytVideoEntry.media.description.text + \
            "    Video keywords: %s\n" % \
                        ytVideoEntry.media.keywords.text + \
            "    Video category: %s\n" % \
                        ytVideoEntry.media.category[0].text)

        if common.MY_DEBUG_STDOUT:
            try:
                # From http://nullege.com/codes/search/gdata.med
                # ia.Category
                devTags = ytVideoEntry.GetDeveloperTags()
                common.DebugPrint("    devTags = %s" % str(devTags))

                for devTag in devTags:
                    # print "  FindMostRecentYouTubeVideo():
                    # devTag = %s" % str(devTag) #devTag is an
                    # XML element
                    common.DebugPrint(
                        "      devTag.text = %s" % str(devTag.text))
            except:
                common.DebugPrintErrorTrace()

            sys.stdout.flush()

            # """
            print "    Video watch page: %s" % \
                            ytVideoEntry.media.player.url
            print "    Video flash player URL: %s" % \
                            ytVideoEntry.GetSwfUrl()

            """
            From https://code.google.com/apis/gdata/javadoc/com/google/gdata/data/youtube/VideoEntry.html:
              "DateTime getRecorded() - see also
              https://code.google.com/apis/gdata/javadoc/com/google/gdata/data/BaseEntry.html#getPublished%28%29"
            """
            # Seems to always be None
            print "    ytVideoEntry.recorded = %s" % \
                    str(ytVideoEntry.recorded)

            # Non ytVideoEntry.media attributes
            try:
                print "    Video geo location: %s" % \
                                ytVideoEntry.geo.location()
            except:
                pass
                #common.DebugPrintErrorTrace()

            for link in ytVideoEntry.link:
                print "    ytVideoEntry.link = %s" % str(link)
                print "    link.rel = %s" % str(link.rel)

            try:
                print "    Video view count: %s" % \
                            ytVideoEntry.statistics.view_count
            except:
                pass
                #common.DebugPrintErrorTrace()

            try:
                # Show alternate formats
                for alternate_format in ytVideoEntry.media.content:
                    if "isDefault" not in \
                                alternate_format.extension_attributes:
                        print "    Alternate format: %s | url: %s " % \
                                    (alternate_format.type, \
                                        alternate_format.url)

                # Show thumbnails
                for thumbnail in ytVideoEntry.media.thumbnail:
                    print "    Thumbnail url: %s" % thumbnail.url

                print "    Video rating: %s" % \
                            ytVideoEntry.rating.average
            except:
                pass
                #common.DebugPrintErrorTrace()
    except:
        common.DebugPrintErrorTrace()



"""
We retrieve the most recently uploaded video on YouTube for the given
    deviceId and cameraId.

For this we need to check in all the video entries in the YouTube video feed
            the following info:
    - deviceId
    - cameraId
    - for validity purposes:
        - duration in seconds
        - str(ytVideo).find(...) for duplicate video.

The info required:
    - video id (e.g., dBaDb0iIZBg) is available in:
        - we get it from ytVideo.id
          <?xml version='1.0' encoding='UTF-8'?>
          <ns0:id xmlns:ns0="http://www.w3.org/2005/Atom">http://gdata.youtube.com/feeds/api/videos/dBaDb0iIZBg</ns0:id>
        
    - deviceId and cameraId are obtained from the 1st devTag:
        devTag.text = N82N82N82N82N82 1

    - seconds (e.g., 31) is available in:
        - ytVideoEntry.media.duration.seconds
        - we get it from ytVideo from directly parsing the XML ytVideo string

    - not used:
        - title (e.g., "2013_11_16_16_21_42_470_N82N82N82N82N82_1") is available in:
            - ytVideoEntry.media.title.text:
            - could get it from ytVideo.title
                ytVideo.title = <?xml version='1.0' encoding='UTF-8'?>
                <ns0:title xmlns:ns0="http://www.w3.org/2005/Atom" type="text">2013_11_16_16_21_42_470_N82N82N82N82N82_1</ns0:title>
            
        - keywords (e.g., "N82N82N82N82N82") is available in:
            - ytVideoEntry.media.keywords.text:
            - could get it from ytVideo from directly parsing the XML ytVideo string

        - description (e.g., "16:22:13.9 16-11-2013 N82N82N82N82N82, 1 100% 4")
                            is available in:
            - ytVideoEntry.media.description.text:
            - could get it from ytVideo.content
              ytVideo.content = <?xml version='1.0' encoding='UTF-8'?>
              <ns0:content xmlns:ns0="http://www.w3.org/2005/Atom" type="text">16:02:14.7 16-11-2013 N82N82N82N82N82, 1 100% 4</ns0:content>

Since we are given already the video feed, we look for the above mentioned
    fields directly in all entries of the feed, instead of retrieveing the
    ytVideoEntry for each entry - retrieving ytVideoEntry each time is VERY
    costly - another gdata HTTP access.
  For compatibility reasons we read a ytVideoEntry ONLY when we find the
    desired video.

Two examples of ytVideo entries obtained from the YT video feed:
    FindMostRecentYouTubeVideo(): ytVideo = <?xml version='1.0' encoding='UTF-8'?>
    <ns0:entry xmlns:ns0="http://www.w3.org/2005/Atom" xmlns:ns1="http://purl.org/atom/app#" xmlns:ns2="http://gdata.youtube.com/schemas/2007" xmlns:ns3="http://schemas.google.com/g/2005" xmlns:ns4="http://search.yahoo.com/mrss/"><ns0:category scheme="http://schemas.google.com/g/2005#kind" term="http://gdata.youtube.com/schemas/2007#video" /><ns0:category label="People &amp; Blogs" scheme="http://gdata.youtube.com/schemas/2007/categories.cat" term="People" />
    <ns0:category scheme="http://gdata.youtube.com/schemas/2007/keywords.cat" term="N82N82N82N82N82" /><ns0:id>http://gdata.youtube.com/feeds/api/videos/WIoL5c5gpYI</ns0:id><ns0:author><ns0:name>Stefan Susu</ns0:name><ns0:uri>https://gdata.youtube.com/feeds/api/users/googleUser</ns0:uri></ns0:author><ns0:content type="text">17:06:27.3 17-11-2013 N82N82N82N82N82, 1 100% 4</ns0:content><ns0:updated>2013-11-17T15:06:52.000Z</ns0:updated><ns0:published>2013-11-17T15:06:38.000Z</ns0:published><ns0:title type="text">2013_11_17_17_05_55_970_N82N82N82N82N82_1</ns0:title><ns1:control><ns1:draft>yes</ns1:draft><ns2:state name="processing" /></ns1:control><ns0:link href="https://www.youtube.com/watch?v=WIoL5c5gpYI&amp;feature=youtube_gdata" rel="alternate" type="text/html" /><ns0:link href="https://gdata.youtube.com/feeds/api/videos/WIoL5c5gpYI/ratings?client=ytapi-pythonclientlibrary_servicetest" rel="http://gdata.youtube.com/schemas/2007#video.ratings" type="application/atom+xml" /><ns0:link href="https://gdata.youtube.com/feeds/api/videos/WIoL5c5gpYI/complaints?client=ytapi-pythonclientlibrary_servicetest" rel="http://gdata.youtube.com/schemas/2007#video.complaints" type="application/atom+xml" /><ns0:link href="https://gdata.youtube.com/feeds/api/videos/WIoL5c5gpYI/related?client=ytapi-pythonclientlibrary_servicetest" rel="http://gdata.youtube.com/schemas/2007#video.related" type="application/atom+xml" /><ns0:link href="https://gdata.youtube.com/feeds/api/users/googleUser/uploads/WIoL5c5gpYI?client=ytapi-pythonclientlibrary_servicetest" rel="self" type="application/atom+xml" /><ns0:link href="https://gdata.youtube.com/feeds/api/users/googleUser/uploads/WIoL5c5gpYI?client=ytapi-pythonclientlibrary_servicetest" rel="edit" type="application/atom+xml" /><ns3:comments><ns3:feedLink countHint="0" href="https://gdata.youtube.com/feeds/api/videos/WIoL5c5gpYI/comments?client=ytapi-pythonclientlibrary_servicetest" rel="http://gdata.youtube.com/schemas/2007#comments" /></ns3:comments><ns4:group><ns4:category label="People &amp; Blogs" scheme="http://gdata.youtube.com/schemas/2007/categories.cat">People</ns4:category>
    <ns4:category scheme="http://gdata.youtube.com/schemas/2007/developertags.cat">N82N82N82N82N82 1</ns4:category>
    <ns4:category scheme="http://gdata.youtube.com/schemas/2007/developertags.cat">1**</ns4:category>
    <ns4:category scheme="http://gdata.youtube.com/schemas/2007/developertags.cat">N82N82N82N82N82</ns4:category>
    <ns4:content duration="0" expression="full" isDefault="true" medium="video" type="application/x-shockwave-flash" url="https://www.youtube.com/v/WIoL5c5gpYI?version=3&amp;f=user_uploads&amp;c=ytapi-pythonclientlibrary_servicetest&amp;d=AZVYZhQouK_NxHlsnE5dt68O88HsQjpE1a8d1GxQnGDm&amp;app=youtube_gdata" ns2:format="5" /><ns4:description type="plain">17:06:27.3 17-11-2013 N82N82N82N82N82, 1 100% 4</ns4:description><ns4:keywords>N82N82N82N82N82</ns4:keywords><ns4:player url="https://www.youtube.com/watch?v=WIoL5c5gpYI&amp;feature=youtube_gdata_player" /><ns4:thumbnail height="360" time="00:00:00" url="https://i1.ytimg.com/s_vi/WIoL5c5gpYI/0.jpg?sqp=CJy2o5QF&amp;rs=AOn4CLA64JHCYY3p9B43SQy3Sqakd9V9qw" width="480" /><ns4:thumbnail height="90" time="00:00:00" url="https://i1.ytimg.com/s_vi/WIoL5c5gpYI/1.jpg?sqp=CJy2o5QF&amp;rs=AOn4CLC12hKX-75XrTfHI0SqEJ0Ks0K-Hg" width="120" /><ns4:thumbnail height="90" time="00:00:00" url="https://i1.ytimg.com/s_vi/WIoL5c5gpYI/2.jpg?sqp=CJy2o5QF&amp;rs=AOn4CLAh5IQlYCWIEVnffbiyKYu4kPrDnA" width="120" /><ns4:thumbnail height="90" time="00:00:00" url="https://i1.ytimg.com/s_vi/WIoL5c5gpYI/3.jpg?sqp=CJy2o5QF&amp;rs=AOn4CLDYwrBLcYJE2mzfQnixxUmAUt6XAw" width="120" /><ns4:title type="plain">2013_11_17_17_05_55_970_N82N82N82N82N82_1</ns4:title><ns2:duration seconds="0" /><ns2:private /></ns4:group></ns0:entry>

    FindMostRecentYouTubeVideo(): ytVideo = <?xml version='1.0' encoding='UTF-8'?>
    <ns0:entry xmlns:ns0="http://www.w3.org/2005/Atom" xmlns:ns1="http://schemas.google.com/g/2005" xmlns:ns2="http://search.yahoo.com/mrss/" xmlns:ns3="http://gdata.youtube.com/schemas/2007">
        <ns0:category scheme="http://schemas.google.com/g/2005#kind" term="http://gdata.youtube.com/schemas/2007#video" />
        <ns0:category label="People &amp; Blogs" scheme="http://gdata.youtube.com/schemas/2007/categories.cat" term="People" />
        <ns0:category scheme="http://gdata.youtube.com/schemas/2007/keywords.cat" term="N82N82N82N82N82" />
        <ns0:id>http://gdata.youtube.com/feeds/api/videos/2O0c72kuz98</ns0:id>
        <ns0:author>
            <ns0:name>Stefan Susu</ns0:name>
            <ns0:uri>https://gdata.youtube.com/feeds/api/users/googleUser</ns0:uri>
        </ns0:author>
        <ns0:content type="text">16:00:09.5 16-11-2013 N82N82N82N82N82, 1 100% 4</ns0:content>
        <ns0:updated>2013-11-16T13:50:30.000Z</ns0:updated>
        <ns0:published>2013-11-16T13:50:02.000Z</ns0:published>
        <ns0:title type="text">2013_11_16_15_59_37_767_N82N82N82N82N82_1</ns0:title>
        <ns0:link href="https://www.youtube.com/watch?v=2O0c72kuz98&amp;feature=youtube_gdata" rel="alternate" type="text/html" />
        <ns0:link href="https://gdata.youtube.com/feeds/api/videos/2O0c72kuz98/ratings?client=ytapi-pythonclientlibrary_servicetest" rel="http://gdata.youtube.com/schemas/2007#video.ratings" type="application/atom+xml" />
        <ns0:link href="https://gdata.youtube.com/feeds/api/videos/2O0c72kuz98/complaints?client=ytapi-pythonclientlibrary_servicetest" rel="http://gdata.youtube.com/schemas/2007#video.complaints" type="application/atom+xml" />
        <ns0:link href="https://gdata.youtube.com/feeds/api/videos/2O0c72kuz98/related?client=ytapi-pythonclientlibrary_servicetest" rel="http://gdata.youtube.com/schemas/2007#video.related" type="application/atom+xml" />
        <ns0:link href="https://m.youtube.com/details?v=2O0c72kuz98" rel="http://gdata.youtube.com/schemas/2007#mobile" type="text/html" />
        <ns0:link href="https://gdata.youtube.com/feeds/api/users/googleUser/uploads/2O0c72kuz98?client=ytapi-pythonclientlibrary_servicetest" rel="self" type="application/atom+xml" />
        <ns0:link href="https://gdata.youtube.com/feeds/api/users/googleUser/uploads/2O0c72kuz98?client=ytapi-pythonclientlibrary_servicetest" rel="edit" type="application/atom+xml" />
        <ns1:comments>
            <ns1:feedLink countHint="0" href="https://gdata.youtube.com/feeds/api/videos/2O0c72kuz98/comments?client=ytapi-pythonclientlibrary_servicetest" rel="http://gdata.youtube.com/schemas/2007#comments" />
        </ns1:comments>
        <ns2:group>
            <ns2:category label="People &amp; Blogs" scheme="http://gdata.youtube.com/schemas/2007/categories.cat">People</ns2:category>
            <ns2:category scheme="http://gdata.youtube.com/schemas/2007/developertags.cat">N82N82N82N82N82 1</ns2:category>
            <ns2:category scheme="http://gdata.youtube.com/schemas/2007/developertags.cat">1**</ns2:category>
            <ns2:category scheme="http://gdata.youtube.com/schemas/2007/developertags.cat">N82N82N82N82N82</ns2:category>
            <ns2:content duration="31" expression="full" isDefault="true" medium="video" type="application/x-shockwave-flash" url="https://www.youtube.com/v/2O0c72kuz98?version=3&amp;f=user_uploads&amp;c=ytapi-pythonclientlibrary_servicetest&amp;d=AZVYZhQouK_NxHlsnE5dt68O88HsQjpE1a8d1GxQnGDm&amp;app=youtube_gdata" ns3:format="5" />
            <ns2:content duration="31" expression="full" medium="video" type="video/3gpp" url="rtsp://r6---sn-4g57kued.c.youtube.com/CnILENy73wIaaQnfzy5p7xzt2BMYDSANFEIleXRhcGktcHl0aG9uY2xpZW50bGlicmFyeV9zZXJ2aWNldGVzdEgGUgx1c2VyX3VwbG9hZHNyIQGVWGYUKLivzcR5bJxOXbevDvPB7EI6RNWvHdRsUJxg5gw=/0/0/0/video.3gp" ns3:format="1" />
            <ns2:content duration="31" expression="full" medium="video" type="video/3gpp" url="rtsp://r6---sn-4g57kued.c.youtube.com/CnILENy73wIaaQnfzy5p7xzt2BMYESARFEIleXRhcGktcHl0aG9uY2xpZW50bGlicmFyeV9zZXJ2aWNldGVzdEgGUgx1c2VyX3VwbG9hZHNyIQGVWGYUKLivzcR5bJxOXbevDvPB7EI6RNWvHdRsUJxg5gw=/0/0/0/video.3gp" ns3:format="6" />
            <ns2:description type="plain">16:00:09.5 16-11-2013 N82N82N82N82N82, 1 100% 4</ns2:description>
            <ns2:keywords>N82N82N82N82N82</ns2:keywords>
            <ns2:player url="https://www.youtube.com/watch?v=2O0c72kuz98&amp;feature=youtube_gdata_player" />
            <ns2:thumbnail height="360" time="00:00:15.500" url="https://i1.ytimg.com/s_vi/2O0c72kuz98/0.jpg?sqp=CIjwnZQF&amp;rs=AOn4CLAJtNpRTsabLD5zT2kAqqbwjVvPKA" width="480" />
            <ns2:thumbnail height="90" time="00:00:07.750" url="https://i1.ytimg.com/s_vi/2O0c72kuz98/1.jpg?sqp=CIjwnZQF&amp;rs=AOn4CLC_IIgPJjwnBnCudm9z4rvPljFDWA" width="120" />
            <ns2:thumbnail height="90" time="00:00:15.500" url="https://i1.ytimg.com/s_vi/2O0c72kuz98/2.jpg?sqp=CIjwnZQF&amp;rs=AOn4CLBt9_rv_Rg6HdoB2M8SogDO8jCmCg" width="120" />
            <ns2:thumbnail height="90" time="00:00:23.250" url="https://i1.ytimg.com/s_vi/2O0c72kuz98/3.jpg?sqp=CIjwnZQF&amp;rs=AOn4CLAYCOFp8Hlq119qjuwAtIzhKBb9NQ" width="120" />
            <ns2:title type="plain">2013_11_16_15_59_37_767_N82N82N82N82N82_1</ns2:title>
            <ns3:duration seconds="31" />
            <ns3:private />
        </ns2:group>
    </ns0:entry>
"""
def CheckForVideoCameraDeviceIdInFeed(ytVideoFeed):
    # We use it to iterate over the YT videos until we find the one for the
    #   corresponding deviceId and cameraId
    ytVideoEntry = None

    try:
        deviceId = Settings.myCfg.deviceId[UI.indexVideo]
        cameraId = Settings.myCfg.cameraId[UI.indexVideo]

        common.DebugPrint(
            "FindMostRecentYouTubeVideo(): searching for deviceId = %s, " \
                "cameraId = %d; len(ytVideoFeed.entry) = %d." % \
                (deviceId, cameraId, len(ytVideoFeed.entry)))

        #ytVideo = ytVideoFeed.entry[0]
        #if True:
        for ytVideo in ytVideoFeed.entry:
            # This is for the iCam Viewer watchdog.
            common.PetWatchdog()


            ##################################################################
            ##################################################################
            ##########We retrieve the required fields from ytVideo############
            ##################################################################
            ##################################################################
            """
            See https://developers.google.com/youtube/1.0/developers_guide_python
                function PrintEntryDetails(), etc for details on fields for
                ytVideo.
            """
            """
            # See https://gdata-python-client.googlecode.com/svn/trunk/pydocs/atom.html#Id
            Ex:
              ytVideo.id = <?xml version='1.0' encoding='UTF-8'?>
              <ns0:id xmlns:ns0="http://www.w3.org/2005/Atom">
                  http://gdata.youtube.com/feeds/api/videos/DK3ZhoQmqdk
              </ns0:id>
            """
            videoId = ytVideo.id.text.split("/")[-1]

            ytVideoTitleStr = str(ytVideo.title)

            """
            NOTE that this field is NOT obtained through standard API -->
                subject to change.
            """
            ytVideoXML = str(ytVideo)
            pattern1 = '<ns3:duration seconds="'
            index = ytVideoXML.find(pattern1)
            if index < 0:
                continue
            #print index
            videoDuration = ytVideoXML[index + len(pattern1):].split('"')[0]


            """
            We obtain the required fields directly from the video entry from
                the YouTube video field.
            """

            """
            NOTE that these fields are NOT obtained through standard API -->
                subject to change.
            """
            pattern2 = '<ns2:category scheme="http://gdata.youtube.com/schemas/2007/developertags.cat">'
            index = ytVideoXML.find(pattern2)
            if index < 0:
                pattern2 = '<ns4:category scheme="http://gdata.youtube.com/schemas/2007/developertags.cat">'
                index = ytVideoXML.find(pattern2)
                if index < 0:
                    continue
            #print index
            videoStr = ytVideoXML[index + len(pattern2):].split('<')[0]
            common.DebugPrint(
                "FindMostRecentYouTubeVideo(): videoStr = %s" % videoStr)
            videoCrtDeviceId = videoStr.split(' ')[0]
            videoCrtCameraId = int(videoStr.split(' ')[1])

            pattern3 = '<ns0:title xmlns:ns0="http://www.w3.org/2005/Atom" type="text">'
            index = ytVideoTitleStr.find(pattern3)
            if index < 0:
                continue
            #print index
            videoTitle = ytVideoTitleStr[index + len(pattern3):].split('<')[0]
            #print title

            common.DebugPrint("FindMostRecentYouTubeVideo(): videoId = %s" % \
                                                            videoId)
            common.DebugPrint(
                "FindMostRecentYouTubeVideo(): videoDuration = %s" % \
                                                videoDuration)
            common.DebugPrint(
                "FindMostRecentYouTubeVideo(): videoCrtDeviceId = %s" % \
                                                videoCrtDeviceId)
            common.DebugPrint(
                "FindMostRecentYouTubeVideo(): videoCrtCameraId = %d" % \
                                                videoCrtCameraId)
            common.DebugPrint(
                "FindMostRecentYouTubeVideo(): videoTitle = %s" % videoTitle)

            PrintInfoYouTubeVideo(ytVideo)


            ##################################################################
            ##################################################################
            ##########Find valid videos after deviceId and cameraId ##########
            ##################################################################
            ##################################################################

            if (videoCrtDeviceId != deviceId) or \
                                            (videoCrtCameraId != cameraId):
                continue

            """
            If the duration is 0 then this means the video is still
                being processed by YouTube:
              in YouTube the video is shown as a camera with clock and it
                writes under description "Uploaded (processing,
                please wait)"
            """
            if videoDuration == 0:
                common.DebugPrint(
                    "FindMostRecentYouTubeVideo(): " \
                    "videoDuration == 0 " \
                    "which means the video is still being " \
                    "processed by YouTube (in YouTube next to the " \
                    "video it says " \
                    "'Uploaded (processing, please wait)')--> " \
                    "skipping this video.\n\n")
                continue

            """
            Some rejected videos have 
                <ns2:state helpUrl=
                    "http://www.youtube.com/t/community_guidelines"
                    name="rejected" reasonCode="duplicate">Duplicate video
                        </ns2:state>
                <ns4:state helpUrl=
                    "http://www.youtube.com/t/community_guidelines"
                    name="rejected" reasonCode="duplicate">Duplicate video
                </ns4:state>
            """
            if ytVideoXML.find('name="rejected" reasonCode="duplicate">' \
                                    'Duplicate video</ns') != -1:
                common.DebugPrint(
                    "FindMostRecentYouTubeVideo(): found a " \
                        "rejected video on reason of duplicate - " \
                        "video id = %s. We should delete it!" % \
                        UI.videoIdStrList[UI.indexVideo])
                continue


            ###################################################################
            ###################################################################
            ##We found a valid video, with the required deviceId and cameraId.#
            ###################################################################
            ###################################################################

            """
            From http://www.mailinglistarchive.com/html/youtube-api-gdata@googlegroups.com/2011-03/msg00290.html
            From http://www.mailinglistarchive.com/html/youtube-api-gdata@googlegroups.com/2011-03/msg00396.html
            "It looks like the way things are behaving now, you only get
                back the edit link when you request a video entry from the
                'uploads' feed.
                (I've asked the engineering team whether this changed
                  recently, as I don't believe this was always the case,
                  but they have not had a chance to look into it yet.)

            When you just specify a video id, the Python client library
                translates that into a request to the URL pointing to the
                public video feed, not the uploads feed.
              That's why it's necessary to provide the full URL pointing
                to the uploads feed."

            See also https://code.google.com/apis/youtube/2.0/developers_guide_protocol.html#Submitting_Partial_Feed_Update

            NOT IMPORTANT: Updating video entry was not working in 2009,
              but now it does:
              https://groups.google.com/group/gdata-python-client-library-contributors/browse_thread/thread/41d74eeb2acce3d
                - "you can only update a video entry that you've 
                    just uploaded.  You can force feed the edit_uri, but
                    that isn't guaranteed to work either."
            """
            ytVideoEntry = youtubeClient.GetYouTubeVideoEntry(
                "http://gdata.youtube.com/feeds/api/users/default/uploads/" + \
                videoId)

            """
            # See https://gdata-python-client.googlecode.com/svn/trunk/pydocs/gdata.youtube.service.html
            # NOT GOOD - DOESN'T HAVE AN EDIT LINK :(((:
            #ytVideoEntry = youtubeClient.GetYouTubeVideoEntry( \
            #    video_id = UI.videoIdStrList[UI.indexVideo])
            """

            PrintInfoYouTubeVideoEntry(ytVideoEntry)

            ##################################################################
            ##################################################################
            ###  We pass the required info (ytVideoEntry) to the caller:######
            ###    the following assignments are used in PlayNextVideo(). ####
            ##################################################################
            ##################################################################
            UI.videoIdStrList[UI.indexVideo] = videoId

            UI.dateTimeStr[UI.indexVideo] = ytVideoEntry.media.title.text
            if UI.dateTimeStrMax[UI.indexVideo] < UI.dateTimeStr[UI.indexVideo]:
                UI.dateTimeStrMax[UI.indexVideo] = UI.dateTimeStr[UI.indexVideo]
            UI.ytVideoEntryList[UI.indexVideo] = ytVideoEntry

            #UI.videoDescriptionStr[UI.indexVideo] = \
            #    UI.ytVideoEntryList[UI.indexVideo].media.description.text
            UI.videoDescriptionStr[UI.indexVideo] = \
                        ytVideoEntry.media.description.text

            # Video description: 22:08:51.4 12-05-2011
            # 612061206120612, 0
            # len(UI.videoDescriptionStr[UI.indexVideo]) - 24] #15]
            UI.videoDescriptionStr[UI.indexVideo] = \
                        UI.videoDescriptionStr[UI.indexVideo][ : 16]
            """
            #UI.dateTimeStr[UI.indexVideo] = \
            #    ytVideoEntry[UI.indexVideo].media.title.text
            UI.dateTimeStr[UI.indexVideo] = \
                ytVideoEntry[UI.indexVideo].media.description.text

            #Trim down the description to enter in the associated box.
            UI.dateTimeStr[UI.indexVideo] = UI.dateTimeStr[ \
                UI.indexVideo][: len(UI.dateTimeStr[indexVideo]) - 24] #15]

            UI.dateTimeStrMax[UI.indexVideo] = UI.dateTimeStr[UI.indexVideo]
            """
            common.DebugPrint("FindMostRecentYouTubeVideo(): " \
                        "UI.videoDescriptionStr[UI.indexVideo] = %s\n" %
                        UI.videoDescriptionStr[UI.indexVideo])

            # NO longer used: do TimeSync after YouTube server published time.
            if False:
                # Use also crtCameraId from devTag[2]
                # If crtDeviceId is BT server or standalone
                crtDeviceId = ytVideoEntry.media.keywords.text
                if crtDeviceId in ["N82N82N82N82N82", "668066806680668"]:
                    TimeSync.SynchronizeTimePhoneWithYouTube(youtubeClient,
                            crtDeviceId, ytVideoEntry.media.title.text,
                            ytVideoEntry.published.text,
                            int(ytVideoEntry.media.duration.seconds))

            common.DebugPrint("\n\n")

            """
            # We found the most recent video for cameraId and deviceId.
            """
            return True
    except:
        common.DebugPrintErrorTrace()
        # We did not find any video in the ytVideoFeed.
        return False

    # We did not find any video in the ytVideoFeed.
    return False


def FindMostRecentYouTubeVideo():
    # This is for the iCam Viewer watchdog
    common.PetWatchdog()

    try:
        # youtubeClient =
        #       gdata.service.GDataService(server="gdata.youtube.com")

        """
        VERY IMPORTANT NOTE:
        youtubeClient = gdata.youtube.service.YouTubeService()
            derives from class of GDataService, which derives from
            atom.service.AtomService, which derives from ProxiedHttpClient,
            which derives from HttpClient (has method request).
        """

        myPage = ""

        # Maybe useful to youtube-dl
        """
        def MyConverter(aStr):
            return aStr

        youtubeClient.http_client.putheader("User-Agent",
            "Mozilla/5.0 (Windows; U; Windows NT 5.1; it; rv:1.8.1.11) " \
            "Gecko/20071127 Firefox/2.0.0.11')

        print "youtubeClient.http_client = %s" % str(youtubeClient.http_client)

        myPage = youtubeClient.Get("http://gdata.youtube.com/feeds/api/" \
            "videos/o9PUj60apKA?client=ytapi-pythonclientlibrary_servicetest")

        myPage = youtubeClient.Get(
            "http://www.youtube.com/watch?v=wkbBiZXCJ5E&gl=US&hl=en&amp;" \
                "has_verified=1", 
            extra_headers = {
                "User-Agent" :
                "Mozilla/5.0 (Windows; U; Windows NT 5.1; it; rv:1.8.1.11) " \
                    "Gecko/20071127 Firefox/2.0.0.11"},
            converter = MyConverter)
        """

        """
        # Works well
        import urllib

        # Public video
        myPage = urllib.urlopen(
                "http://www.youtube.com/watch?v=wkbBiZXCJ5E").read()
        """

        """
        import urllib

        # Private video
        myPage = urllib.urlopen(
                "http://www.youtube.com/watch?v=o9PUj60apKA").read()
        """

        """
        # Returns private video...
        import urllib
        video_id = "o9PUj60apKA"

        # From http://wolfprojects.altervista.org/changeua.php:
        class MyOpener(urllib.FancyURLopener):
            version = "Mozilla/5.0 (Windows; U; Windows NT 5.1; it; " \
                        "rv:1.8.1.11) Gecko/20071127 Firefox/2.0.0.11"

        myopener = MyOpener()
        webpage = myopener.open("http://www.youtube.com/watch?v=%s&gl=US&" \
                        "hl=en&amp;has_verified=1" % video_id)
        myPage = webpage.read()
        """

        """
        # IT DOESN'T WORK: Probably because the GData server does not
        #    serve standard YouTube pages ;)
        # Malformed
        res = youtubeClient.http_client.request("GET /watch?v=wkbBiZXCJ5E",
                                            "http://www.youtube.com")

        # Gives a 404
        #res = youtubeClient.http_client.request("GET",
        #    "http://www.youtube.com/watch?v=wkbBiZXCJ5E")

        #res = youtubeClient.http_client.request("GET",
        #    "http://www.youtube.com/watch?v=o9PUj60apKA&gl=US&hl=en" \
        #    "&amp;has_verified=1")
        myPage = res.read()
        """

        """
        uri = "http://www.youtube.com/watch?v=o9PUj60apKA"
        extra_headers = {}
        server_response = youtubeClient.request("GET", uri,
                                                headers=extra_headers)
        myPage = server_response.read()
        """

        # print "myPage =", myPage return

        # Iterate over all YouTube video feeds, if necessary.
        startIndex = 1
        MAX_RESULTS_PER_YT_VIDEO_FEED = 50 #10 #50

        # We search EXHAUSTIVELY in the list of video feeds for the video:
        while True:
            try:
                """
                # It gets only the most recent 25 user feeds.

                # It seems you need to use the nick name.
                results = youtubeClient.GetYouTubeUserFeed(
                                    username = Settings.myCfg.googleUsername)
                """

                """
                Important: we can ask for at most 50 results per page - see
                  exception:
                    "RequestError: {
                        'status': 400,
                        'body': 'Max-results value is too high. Only up to '
                                    '50 results can be returned per query.',
                        'reason': 'Bad Request'}"
                """

                """
                It gets as many user feeds specified. Inspired from
                  http://stackoverflow.com/questions/2448801/youtube-api-how-to-limit-results-for-pagination

                results = youtubeClient.Get(
                    "https://gdata.youtube.com/feeds/api/users/" + \
                    Settings.myCfg.googleUsername + "/uploads/?start-index=1&max-results=50")

                # GOOD - THEY BOTH WORK
                results = youtubeClient.Get(
                    "https://gdata.youtube.com/feeds/api/users/" + \
                    Settings.myCfg.googleUsername + "/uploads/?start-index=" + \
                    str(startIndex) + "&max-results=" + str(MAX_RESULTS_PER_YT_VIDEO_FEED))
                """
                results = \
                    youtubeClient.Get("https://gdata.youtube.com/feeds/" \
                        "api/users/default/uploads/?start-index=" +
                        str(startIndex) + "&max-results=" +
                        str(MAX_RESULTS_PER_YT_VIDEO_FEED))

                """
                TODO:
                  Doing a query to retrieve videos with a certain devTag 
                    (i.e., certain deviceId and cameraId), but the videos are
                    NOT retrieved in most recent order
                    (i.e., published time, chrono descending dorted) so we
                    might end up doing even more work.
                    It returns 50 videos per feed.
                  TODO: find the right ballance:
                    - query the most recent videos feed (see above)
                    - if we don't find in the first 50-300 videos returned the
                        video searched then we should do a (few) queries with
                        devTag in it until we find the most recent video.
                """
                if False:
                    """
                    Inspired from
                        https://developers.google.com/youtube/1.0/developers_guide_python:

                    See also 
                        https://developers.google.com/youtube/2.0/developers_guide_protocol#Retrieving_and_searching_for_videos
                        - look for
                        "Always specify the schema, as explained in the
                            previous item, if you are requesting videos
                            associated with a particular developer tag."
                    """
                    tagPattern = "N82N82N82N82N82" # "your_tag_here"
                    devTagURI = "http://gdata.youtube.com/feeds/videos/-/%7B" + \
                        "http%3A%2F%2Fgdata.youtube.com%2Fschemas%2F2007%2Fdevelopertags.cat%7D" + \
                        tagPattern
                    common.DebugPrint(
                        "Alex: " + \
                        str(youtubeClient.GetYouTubeVideoFeed(devTagURI)))

                #return self.Get(uri,
                #    converter=gdata.youtube.YouTubeVideoEntryFromString)

                common.DebugPrint(
                    "FindMostRecentYouTubeVideo(): read YouTube " \
                        "videos startIndex = %d, " \
                        "MAX_RESULTS_PER_YT_VIDEO_FEED = %d, " \
                        "len(results.entry) = %d (time = %s)." % \
                        (startIndex, MAX_RESULTS_PER_YT_VIDEO_FEED,
                        len(results.entry),
                        common.GetCurrentDateTimeStringWithMillisecondsNice()))

                if False:
                    common.DebugPrint(
                        "FindMostRecentYouTubeVideo(): results= %s." % \
                                                        (str(results)))

                """
                if (len(results.entry) == 0) or \
                                (startIndex > MAX_RESULTS_PER_YT_VIDEO_FEED):
                """
                if len(results.entry) == 0:
                    break

                startIndex += MAX_RESULTS_PER_YT_VIDEO_FEED
            except:
                common.DebugPrintErrorTrace()
                continue

            """
            # It surely doesn't return the private videos.
            # Returns only?? the public videos, even if I am logged on.
            #results = youtubeClient.Get( \
            # "http://gdata.youtube.com/feeds/api/videos?author=MultiEnder123")

            results = youtubeClient.Get( \
                    "http://gdata.youtube.com/feeds/api/videos?author=googleUser")

            common.DebugPrint(
                "FindMostRecentYouTubeVideo(): For Get(): " \
                        "len(results.entry) = %d\n" % len(results.entry) + \
                "FindMostRecentYouTubeVideo(): For Get(): " \
                        "results = %s\n" % str(results))
            """

            # These are GLOBAL (from ALL users) recent feeds.
            #results = youtubeClient.GetMostRecentVideoFeed()
            """
            #Old:
            results = youtubeClient.Get( \
                "http://gdata.youtube.com/feeds/api/videos?orderby=viewCount" \
                    "&max-results=1&format=1&vq=n810")
            """
                
            if CheckForVideoCameraDeviceIdInFeed(results):
                return
    except:
        common.DebugPrintErrorTrace()


"""
From http://www.penzilla.net/tutorials/python/functions/:
    "Python passes all arguments using "pass by reference".
        However, numerical values and Strings are all immutable.
        You cannot change the value of a passed in immutable and see that
            value change in the caller."
"""



#TODO: Refactor function - make it smaller
def DownloadYouTubeVideo(ytVideoEntry, videoIdStr):
    common.DebugPrint("Entered DownloadYouTubeVideo()")

    try:
        # This is for the iCam Viewer watchdog
        common.PetWatchdog()

        videoURL = "http://www.youtube.com/watch?v=%s" % videoIdStr

        common.DebugPrint("videoURL = %s" % videoURL)

        videoDuration = int(ytVideoEntry.media.duration.seconds)

        #MAKE_MOVIE_PUBLIC_THEN_PRIVATE_BACK_AGAIN = False
        MAKE_MOVIE_PUBLIC_THEN_PRIVATE_BACK_AGAIN = True

        """
        Normally, the videos are private - we make them public to be able to download
            them and then we immediately make them private back again.
        """
        if MAKE_MOVIE_PUBLIC_THEN_PRIVATE_BACK_AGAIN:
            # See https://code.google.com/apis/youtube/1.0/developers_guide_python.html#UpdateVideoInfo
            #ytVideoEntry.media.title.text = 'My Updated Video Title'
            #ytVideoEntry.media.description.text = "Just updated"
            #print "ytVideoEntry.private =", ytVideoEntry.media.private
            ytVideoEntry.media.private = None

            """
            #gdata.service.RequestError: {'status': 400,
            #       'body': 'Invalid request URI', 'reason': 'Bad Request'}

            #ytVideoEntry.link[1].rel = "edit"

            #gdata.service.RequestError: {'status': 403,
            #    'body': 'Target feed is read-only', 'reason': 'Forbidden'}
            #ytVideoEntry.link[3].rel = "edit"
            """

            #print "updated ytVideoEntry = %s" % str(ytVideoEntry)

            ###################################################################
            ###################################################################
            ###################################################################
            ###################################################################
            ###################################################################
            ####################IMPORTANT!!!!!!!!!!!!!!!!!!!!!#################
            ###################################################################
            ###################################################################
            """
            Can give exception:
                RequestError: {'status': 403,
                    'body': "<?xml version='1.0' encoding='UTF-8'?><errors>
                    <error><domain>yt:quota</domain>
                    <code>too_many_recent_calls</code></error>/errors>",
                    'reason': 'Forbidden'}
            ###################################################################
            See https://gdata-python-client.googlecode.com/svn/trunk/pydocs/gdata.youtube.service.html:
              "Returns: An updated YouTubeVideoEntry on success or None."
            """
            ytVideoEntryUpdated = youtubeClient.UpdateVideoEntry(ytVideoEntry)

            #print "ytVideoEntryUpdated = %s" % str(ytVideoEntryUpdated)
            if ytVideoEntryUpdated is None:
                common.DebugPrint("DownloadYouTubeVideo(): Unsuccessful " \
                        "update: ytVideoEntryUpdated is None!!")

            """
            So we should use http verbs, as suggested:
            See also
              https://code.google.com/apis/youtube/2.0/developers_guide_protocol.html#Updating_Video_Entry
            """

        """
        pathFileName = "./" + Settings.myCfg.deviceId[UI.indexVideo] + "/" + \
                                                    videoIdStr + ".flv"
        pathFileName2 = "./" + Settings.myCfg.deviceId[UI.indexVideo] + "/" + \
                                                    videoIdStr + ".mp4"
        """
        if True:
            pathFileName = common.ICAM_VIEWER_PATH + \
                Settings.myCfg.deviceId[UI.indexVideo] + "\\" + videoIdStr + ".flv"
            pathFileName2 = common.ICAM_VIEWER_PATH + \
                Settings.myCfg.deviceId[UI.indexVideo] + "\\" + videoIdStr + ".mp4"
        else:
            pathFileName = common.ICAM_VIEWER_PATH + \
                Settings.myCfg.deviceId[UI.indexVideo] + "/" + videoIdStr + ".flv"
            pathFileName2 = common.ICAM_VIEWER_PATH + \
                Settings.myCfg.deviceId[UI.indexVideo] + "/" + videoIdStr + ".mp4"

        # If the video file was not already downloaded, we download it now.
        if os.path.isfile(pathFileName) or os.path.isfile(pathFileName2):
            common.DebugPrint("DownloadYouTubeVideo(): Movie seems to be " \
                    "already downloaded - found at %s or %s." % \
                    (pathFileName, pathFileName2))
        else:
            """
            #, stdout=None, stderr=fOutput)
            subprocess.call(["c:/python25/python",
                "Z:/1PhD/ReVival/Google/gdata-python-client/gdata-2.0.14/" \
                    "tests/gdata_tests/youtube/11YouTube-dl/" \
                    "youtube-dl_orig.py", videoURL])

            #, stdout=None, stderr=fOutput)
            subprocess.call(["c:/python25/python",
                "./youtube-dl_orig.py", videoURL])
            """

            if False:
                """
                IMPORTANT: youtube_dl.FileDownloader.download()
                    calls youtube_dl.InfoExtractor().extract,
                    which calls youtube_dl.YoutubeIE()._real_extract(),
                    which calls youtube_dl.FileDownloader.process_info(),
                    which calls youtube_dl.FileDownloader._do_download()
                """
                youtube_dl.fd.download([videoURL])

            if False: # This is for test
                youtube_dl.__init__.main( \
                    ["https://www.youtube.com/watch?v=Jlc_YnCoSp0",
                    "-oJlc_YnCoSp0.flv"])

            if False: # with password - NOT working
                try:
                    #__init__.main(videoURL, "googleUser", "googlePasswd", "--format=5")
                    youtube_dl.__init__.main(videoURL, \
                        Settings.myCfg.googleUsername, \
                        Settings.GetGooglePassword(), "--format=5")
                except:
                    common.DebugPrintErrorTrace()

            if True: # with password
                try:
                    #__init__.main(videoURL, "googleUser", "googlePasswd", "--format=5")
                    youtube_dl.__init__.main( \
                        [videoURL, "-o%s.flv" % videoIdStr])
                except SystemExit:
                    print "youtube_dl.__init__.main() returned SystemExit."
                    sys.stdout.flush()
                except:
                    #(exceptionTypeG, exceptionValueG, exceptionTracebackG) = sys.exc_info()
                    common.DebugPrint("Error: videoIdStr = %s" % videoIdStr)
                    common.DebugPrintErrorTrace()

            # shutil.move("./" + videoIdStr + ".flv", pathFileName)
            shutil.move(common.ICAM_VIEWER_PATH + videoIdStr + \
                                                        ".flv", pathFileName)

            """
            We check for a "valid" file size of the downloaded
                video - iCamViewer blocked because the downloaded file was
                actually invalid - only 871 bytes (only header) - probably
                because YouTube is still processing the video.
            """
            mediaFileSize = os.path.getsize(pathFileName)

            if mediaFileSize < 1000:
                common.DebugPrint(
                    "DownloadYouTubeVideo(): mediaFileSize = %d " \
                        "--> I consider this video to be invalid." % \
                                                        mediaFileSize)
                return ("", -1)
        # return

        if MAKE_MOVIE_PUBLIC_THEN_PRIVATE_BACK_AGAIN:
            ytVideoEntryUpdated.media.private = gdata.media.Private()
            ytVideoEntryUpdated2 = \
                youtubeClient.UpdateVideoEntry(ytVideoEntryUpdated)

            if ytVideoEntryUpdated2 is None:
                common.DebugPrint(
                    "Unsuccessful update: ytVideoEntryUpdated2 is None!!")

            #print "ytVideoEntryUpdated2 = %s" % str(ytVideoEntryUpdated2)

            #return (pathFileName, ytVideoEntry.media.title.text, videoDuration)
        return (pathFileName, videoDuration)
    except:
        common.DebugPrintErrorTrace()
        return ("", -1)


# Only Gdata
def ConnectToYouTubeGData():
    global youtubeClient, youtubeClientAlreadyConnected

    try:
        if youtubeClientAlreadyConnected == False:
            common.DebugPrint("Connecting to youtube.service")

            # Followed https://groups.google.com/forum/#!msg/youtube-api-gdata/dFkrQ_6wVVs/V7U3H3GQyCsJ
            youtubeClient = gdata.youtube.service.YouTubeService( \
                                    additional_headers={"GData-Version": "1"})
            #See https://gdata-python-client.googlecode.com/svn/trunk/pydocs/gdata.youtube.service.html#YouTubeService
            #youtubeClient = gdata.youtube.service.YouTubeService()

            # Yes, we can provide only the Google username,
            #    not the email address.
            youtubeClient.email = Settings.myCfg.googleUsername

            # Settings.myCfg.youtubePassword
            youtubeClient.password = Settings.GetGooglePassword()

            youtubeClient.source = Settings.YOUTUBE_TEST_CLIENT_ID
            youtubeClient.developer_key = Settings.youtubeDeveloperKey
            youtubeClient.client_id = Settings.YOUTUBE_TEST_CLIENT_ID

            try:
                youtubeClient.ProgrammaticLogin()
            except:
                (exceptionType, exceptionValue, exceptionTraceback) = \
                    sys.exc_info()

                errorStr = \
                    "Exception in ConnectToYouTubeGData() - details: "\
                    "exceptionTraceback = %s, exceptionType = %s, "\
                    "exceptionValue = %s. Bailing out..." % \
                    (repr(traceback.format_tb(exceptionTraceback)),
                       str(exceptionType), str(exceptionValue))

                common.DebugPrint(errorStr)

                common.DebugPrintErrorTrace()

                if str(exceptionValue) == "Incorrect username or password":
                    # gdata.service.BadAuthentication: Incorrect
                    # username or password exceptionType = <class
                    # 'gdata.service.BadAuthentication'>

                    """
                    if common.MY_PYSIDE:
                        app = QtGui.QApplication(sys.argv)
                    elif common.MY_PYQT:
                        app = Qt.QApplication(sys.argv)

                    MultiViewer.multiViewer = MultiViewer.MultiViewer()
                    MultiViewer.multiViewer.CreateSettingsDialog()
                    MultiViewer.multiViewer.show()
                    sys.exit(app.exec_())
                    """
                    # Authentication error
                    return -1

            common.DebugPrint("Connected to youtube.service")

            youtubeClientAlreadyConnected = True
        """
        self.assertEquals(youtubeClient.developer_key, \
                                Settings.youtubeDeveloperKey)

        self.assertEquals(youtubeClient.client_id, \
                            Settings.YOUTUBE_TEST_CLIENT_ID)

        self.assertEquals(youtubeClient.additional_headers['X-GData-Key'],
                                                'key=' + youtubeDeveloperKey)

        self.assertEquals(youtubeClient.additional_headers['X-Gdata-Client'],
                                            Settings.YOUTUBE_TEST_CLIENT_ID)
        """

        """
        feed = youtubeClient.GetMostRecentVideoFeed()
        print "RetrieveMostRecentVideoFeed(): feed =", feed
        """
    except:
        common.DebugPrintErrorTrace()
