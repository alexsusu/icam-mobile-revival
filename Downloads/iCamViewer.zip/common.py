import os
import sys
import time
import traceback
import urllib

MY_DEBUG_STDOUT = True
MY_DEBUG_STDERR = True


MY_PYSIDE = True
MY_PYQT = False
"""
MY_PYSIDE = False
MY_PYQT = True
"""

"""
If it is False we make sure we don't import any of the gdata and youtube_dl
    modules, thus reducing if not doing video/audio analysis dependencies only
    to Python 2.7 and PyQt/PySide.
"""
#DO_IMPORT_GDATA = False
DO_IMPORT_GDATA = True


if False:
    PHONE_MEDIA_EXTENSION = ".mp4"
PHONE_MEDIA_EXTENSION = ".3gp"

"""    
We lookup for YT videos by retrieving YT video feeds, which have only 50
    videos each.
NUM_YT_VIDEO_FEED_PAGES_TO_GET is the number of YT video feeds to get when
    doing a lookup for a video - in Slideshow.py.
iCamViewer seems to crash if we have YouTube 
#HOW_MANY_VIDEO_FEED_PAGES_TO_GET_WITHOUT_CRASHING_ICAMVIEWER
"""
NUM_YT_VIDEO_FEED_PAGES_TO_GET = 10 #3 #200 #10

NUM_RETRIES_DOWNLOAD_VIDEO = 1  # 10


#HP DV2 Windows XP settings
ICAM_VIEWER_PATH = "C:\\iCamViewer\\"

if (not os.path.exists(ICAM_VIEWER_PATH)):
    #VLC 2.0+ on Win Vista (at least) requires Winwdows style paths on Windows
    ICAM_VIEWER_PATH = "Z:\\1PhD\\ReVival\\iCamViewer\\"

#HP DV2 Windows XP settings
VLC_EXECUTABLE_PATH_FILENAME = "C:/Program Files/VideoLAN/VLC/vlc.exe"

if (not os.path.exists(VLC_EXECUTABLE_PATH_FILENAME)):
    #VLC 2.0+ on Win Vista (at least) requires Winwdows style paths on Windows
    VLC_EXECUTABLE_PATH_FILENAME = "C:/Program Files (x86)/VideoLAN/VLC/vlc.exe"

SOX_EXECUTABLE_PATH_FILENAME = "./sox/sox.exe"

VIDEO_ANALYSIS_MEDIA_FOLDER = "R:/1"


"""
#VLC_EXECUTABLE_PATH_FILENAME = "C:/Program Files/VideoLAN/VLC/vlc.exe"
VLC_EXECUTABLE_PATH_FILENAME = "C:/Program Files (x86)/VideoLAN/VLC/vlc.exe"

ICAM_VIEWER_PATH = "Z:\\1PhD\\ReVival\\iCamViewer\\" #VLC 2.0+ on Win Vista (at least) requires Winwdows style paths on Windows

SOX_EXECUTABLE_PATH_FILENAME = "./sox/sox.exe"

PETTING_FILENAME = "R:/iCamViewerAlive"

VIDEO_ANALYSIS_MEDIA_FOLDER = "R:/1"
"""

def DebugPrint(aText):
    try:
        if MY_DEBUG_STDOUT:
            print aText
            sys.stdout.flush()
    except:
        pass

def DebugPrintErrorTrace():
    try:
        if MY_DEBUG_STDERR:
            traceback.print_stack()
            traceback.print_exc()
            sys.stderr.write("\n\n")
            sys.stderr.flush()
    except:
        pass


def GetCurrentDateTime():
    return time.localtime()


def GetCurrentDateTimeStringWithMilliseconds():
    crtTime = GetCurrentDateTime()
    crtTime2 = time.time()

    #See http://discussion.forum.nokia.com/forum/showthread.php?116978-What-is-the-time-granularity-in-Pys60
    numMilliseconds = (crtTime2 - int(crtTime2)) * 1000

    """
    fileName = time.strftime("%Y_%m_%d_%H_%M_%S", crtTime) +
                            ("_%03d%s" % (numMilliseconds, fileExtension))
    """
    return time.strftime("%Y_%m_%d_%H_%M_%S", crtTime) + "_%03d" % \
                                                            numMilliseconds


#!!!!do better
def GetCurrentDateTimeStringWithMillisecondsNice():
    crtTime = GetCurrentDateTime()
    crtTime2 = time.time()

    #See http://discussion.forum.nokia.com/forum/showthread.php?116978-What-is-the-time-granularity-in-Pys60
    numMilliseconds = (crtTime2 - int(crtTime2)) * 1000

    """
    fileName = time.strftime("%Y_%m_%d_%H_%M_%S", crtTime) +
                    ("_%03d%s" % (numMilliseconds, fileExtension))
    """
    return time.strftime("%H:%M:%S %d-%m-%Y", crtTime) + " (%03d)" % \
                                                            numMilliseconds



PETTING_FILENAME = "R:/iCamViewerAlive"

def PetWatchdog():
    """
    Another idea: check modif time of STATE_FILENAME if always updating it in
        UploadStateAndFileAndStoreState() - this actually happens only for
        fileName == None maybe save file in LOCAL_FOLDER.
    #PETTING_FILENAME = "R:/iCamViewerAlive"

    #e32.ao_yield()
    """

    DebugPrint("Entered PetWatchdog() at %s." % \
                                    time.asctime(GetCurrentDateTime()))

    try:
        # if not os.path.exists(PETTING_FILENAME):
        if not os.path.isfile(PETTING_FILENAME):
            fOutput = open(PETTING_FILENAME, "wb")
            # fOutput.write()
            fOutput.close()
    except:
        # PowerManager()
        DebugPrintErrorTrace()


def InternetDownloadFile(URL, pathFileName):
    DebugPrint("Entered InternetDownloadFile().")
    """
    DebugPrint("Entered InternetDownloadFile(URL=%s, pathFileName=%s)." % \
                                                        (URL, pathFileName))
    """

    try:
        #data = urllib.urlopen(URL).read()
        myHandle = urllib.urlopen(URL)

        """
        import urllib2
        myHandle = urllib2.urlopen(URL)
        """

        DebugPrint("InternetDownloadFile(): myHandle = %s" % str(myHandle))

        data = myHandle.read()

        DebugPrint("InternetDownloadFile(): finished myHandle.read().")

        fOutput = open(pathFileName, "wb")
        fOutput.write(data)
        fOutput.close()

        return 0
    except:
        """
        exceptionType, exceptionValue, exceptionTraceback = sys.exc_info()
        myText = "Exception in DownloadCommands. Details: time = %s, " \
                "free_ram = %d. %s." % \
                (time.strftime("%H:%M:%S %d-%m-%Y", GetCurrentDateTime()),
                    sysinfo.free_ram(),
                    repr(traceback.format_tb(exceptionTraceback)) )

        if MY_DEBUG_UPLOAD_MSG:
            UploadGZippedData(Settings.myCfg.deviceId, myText, \
                Settings.myCfg.iCamServerAddress, WEBPAGE_UL_GZIPPED_TEXT, None)

        #if MY_DEBUG_STDOUT:
        #   sys.stderr.write(myText + "")
        DebugPrintErrorTrace()
        """
        DebugPrintErrorTrace()
        return -1


NUM_RETRIES_DOWNLOAD = 1 # 20 #1

def DownloadFile(URL, pathFileName, fileSize=-1):
    DebugPrint("Entered DownloadFile(URL=%s, pathFileName=%s, " \
                "fileSize=%d)." % (URL, pathFileName, fileSize))

    for trialIndex in range(NUM_RETRIES_DOWNLOAD + 1):
        PetWatchdog()
        res = InternetDownloadFile(URL, pathFileName)

        DebugPrint("DownloadFile(): trialIndex #%d: res = %d." % \
                                            (trialIndex, res))

        try:
            if res == 0:
                if fileSize != -1:

                    actualFileSize = os.path.getsize(pathFileName)
                    DebugPrint("DownloadFile(), trialIndex #%d: " \
                            "fileSize = %d, actualFileSize = %d." % \
                            (trialIndex, fileSize, actualFileSize))

                    if fileSize == actualFileSize:
                        return 0
                    else:
                        return -1
                else:
                    return 0
        except:
            DebugPrintErrorTrace()
    return -1


"""
def DownloadFile(URL, fileName, originalFileSize):
    try:
        data = urllib.urlopen(URL).read()
        if len(data) != originalFileSize:
            print "WARNING: originalFileSize = %d and read data has " \
                    "%d bytes." % (originalFileSize, len(data))
        fOutput = open(fileName, "wb")
        fOutput.write(data)
        fOutput.close()

        return 0
    except:
        #exceptionType, exceptionValue, exceptionTraceback = sys.exc_info()
        #myText = "Exception in DownloadCommands. " \
        #    "Details: time = %s, free_ram = %d. %s." % \
        #    (time.strftime("%H:%M:%S %d-%m-%Y", GetCurrentDateTime()), \
        #    sysinfo.free_ram(), repr(traceback.format_tb(exceptionTraceback)) )

        #if common.MY_DEBUG_UPLOAD_MSG:
        #    UploadGZippedData(deviceId, myText, PHP_SERVER_NAME, \
        #                        WEBPAGE_UL_GZIPPED_TEXT, None)

        ##if common.MY_DEBUG_STDOUT:
        ##   sys.stderr.write(myText + "\n")
        common.DebugPrint(myText)

        common.DebugPrintErrorTrace()
        return -1
"""
