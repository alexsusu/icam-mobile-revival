import time
import common

if common.MY_PYSIDE:
    from PySide import QtCore, QtGui


NUM_DAYS_TO_ALERT_BEFORE_SIM_BECOMES_INVALID = 14

"""
+40744225605 - dad
+01234567890 - mine
**
HTC TC
    +40763367988 - 1.91 Euro - valab 31 may 2012, grace period 17nov 2012

N95
    - +40763343328
    - 11 nov 2011 valab, 4 euros (11.14??) euro - active until 11.06.2012;
        grace period until 12.05.2013
    //NOT ANYMORE: +40765901942 - Titan acasa - 8.19
            (before 2.19, 2.68, 3.17, 4.17) euros - valab 27.07.2011,
        gratie pana la 26.08.2011

+40772107340 - masina - the other RDS Prepaid. 0.91 euros left.
    Bought 4 euros on July 15, 2011.
    Validity until 20 apr 2011 (bought at 22.10.2010).
    Activated Inet on Jul 31?, 2011.
**
Cernica
    6120 - +40731233735 - Cernica prefer to keep it. Maybe port to Cosmote
        reincarcat 4 euro la 06.06.2012; valab 30 zile,
        gratie inca 300 zile --> validUntil 1.05.2013
            valab pana la 1.4.2012
            - vezi http://www.online-prepay.ro/magazin-online/pc/Tarife-d25.htm
                    pt perioade valabilitate si gratie
    6680 - +40768024051 - 5 euros, grace period until Dec 31st?, 2013
***

Can be used:
    +447438549548 - Lyca mobile (from the UK).

Useless:
    +40730460790 - 2.19euro, exp 22 mar 2012 - kaput
    +40769915606 - 1 euro left, grace period until Aug 04 2012 (used on 6680)
    New Orange (temp) number: +40755511278
"""


# Stats: 13 functional phones; biggest users: Cernica - 4 phones
phoneInfo   = {
                "35598001238745601": [
                                        "+40763367988",
                                        #(2012, 11, 17, 00, 00, 00, 000), # Recharged on
                                        (2014,  1, 15, 00, 00, 00, 000), # validUntil
                                        "valid for 13 months - description",
                                        "HTC Touch Cruise (Polaris - P1000?)",
                                        "Titan"
                                     ],
                "612061206120612":   [
                                        "+40772113815",
                                        (2014,  6,  1, 00, 00, 00, 000), # validUntil
                                        "valid for 6 months active + 6 months grace period",
                                        "Nokia 6120",
                                        "Cernica"
                                     ],
                "668066806680668":   [
                                        "+40768024051",
                                        (2014, 11, 01, 00, 00, 00, 000), # validUntil
                                        "Cosmote prepaid Vibe, recharged 17 Nov 2013",
                                        "Nokia 6680",
                                        "Cernica"
                                     ],
                "N95N95N95N95N95":   [
                                        "+40772102094", #"+40771020948", #"+40763343328",
                                        (2014,  2, 7, 00, 00, 00, 000), #(2014,  7, 30, 00, 00, 00, 000), # validUntil #~0.91 euro
                                        "description",
                                        "Nokia N95, with a lot of problems, Code: 0548979, Model: N95-1, Type: RM-159",
                                        "Cernica"
                                     ],
                "N82N82N82N82N82":   [
                                        "+40770287060",
                                        (2020,  1,  1, 00, 00, 00, 000), # validUntil
                                        "description",
                                        "Nokia N82",
                                        "Cernica"
                                     ],
                "E7E7E7E7E7E7E7E":   [
                                        "+40721920203",
                                        (2018, 12, 31, 00, 00, 00, 000), # validUntil
                                        "description",
                                        "Nokia E7",
                                        "Alex's main phone"
                                     ],
                "351751043443285":   [
                                        "+01234567890",
                                        (2020,  1,  1, 00, 00, 00, 000), # validUntil
                                        "description",
                                        "Samsung Galaxy S",
                                        "Alex's secondary phone"
                                     ]

                # MAYBE sell it :) - I also have an Android tablet Prestigio PMP7074 "354525040419119" - for reading, but also iCam

                # TODO: MAYBE sell it :) - I also have a Samsung SGH810 - dad uses it
                # Huawei dumb phone - dad uses it
                # Motorola dumb phone - dad uses it

                # I also have a Motorola A920, Symbian very old, without good Python support

                # !!!!TODO: sell it :) - I also have an iPhone 2G - not very useful for iCam (it's kindda unstable, no video rec): "011300000880881" - mom uses it
              }



"""
if ("E7E7E7E7E7E7E7E" in phoneInfo):
    print phoneInfo["E7E7E7E7E7E7E7E"][0]
"""

"""
    !!!!Do auto check when starting iCamViewer
        From http://stackoverflow.com/questions/6110023/qt-how-to-set-a-date-with-time-to-a-qdatetimeedit
          void MainWindow::setUIDateAndTime(QString &date)
          {
              QDateTime dateTime;
              dateTime.fromString(date, "yyyy-MM-dd hh:mm:ss");

              // For debug testing
              QString sDatetime = dateTime.toString("yyyy-MM-dd hh:mm:ss");

              // Create the datetime picker
              QDateTimeEdit *dateTimePicker = new QDateTimeEdit(dateTime);
              dateTimePicker->setObjectName("dateTimePicker");

              ui->frameCommentHolderLayout->addWidget(dateTimePicker);
          }
"""


def CheckValiditySIMCard(deviceId):
    #print validUntil["668066806680668"]
    #print validUntil[deviceId]
    devValidUntil = phoneInfo[deviceId][1]
    #pass

    sourceTime = time.mktime( 
                    (devValidUntil[0], devValidUntil[1], devValidUntil[2],
                    devValidUntil[3], devValidUntil[4], devValidUntil[5],
                    devValidUntil[6], -1, -1) )
    targetTime = time.time()
    numSecs = sourceTime - targetTime
    numDays = numSecs / (3600 * 24.0)

    if common.MY_DEBUG_STDOUT:
        print "deviceId = %s:" % deviceId
        print "    Num secs = %d" % numSecs
        print "    Num days = %.2f" % numDays
        print "    Num astronomical years =", numDays / 365.25

    #if abs(numSecs) < NUM_DAYS_TO_ALERT_BEFORE_SIM_BECOMES_INVALID * 24 * 3600:
    if ((numDays >= 0) and \
                (numDays < NUM_DAYS_TO_ALERT_BEFORE_SIM_BECOMES_INVALID)) or \
            (numDays < 0):
        #Alarm
        myText = "Warning! The SIM card of the phone with IMEI %s will become " \
                "invalid in %.2f days, by %s. Please refill the SIM card. " \
                "Did you refill the SIM card " \
                "(Yes-->Go and update the validUntil; No)." % (deviceId, \
                                            numDays, phoneInfo[deviceId][2])
        """
        myText = "Warning! The SIM card of the phone with IMEI %s will " \
                "become invalid/expire/be unsubscribed from the operator in " \
                "%.2f days, by 2012... . Please recharge with credit the " \
                "SIM card." % (deviceId, numDays)
        """

        def Alarm(aText):
            # Check if we run in iCamViewer:
            if __name__ != "__main__":
                QtGui.QMessageBox.information(None, "iCamViewer warning", \
                                                                    myText)
            # If we do NOT run in iCamViewer:
            else:
                if numDays < 0:
                    print "It seems the SIM card became invalid. " \
                            "Try to refill your SIM card or change it!"
                else:
                    print "Warning! You have less than %d days before the SIM " \
                        "card becomes invalid. Go and refill your card." % \
                        NUM_DAYS_TO_ALERT_BEFORE_SIM_BECOMES_INVALID
            #QtGui.QMessageBox.information(self, "iCamViewer", aText)
            #QtGui.QMessageBox.information(None, "iCamViewer", aText)

            for i in range(20):
                # Inspired from http://www.pyside.org/docs/pyside/PySide/QtGui/QSound.html
                QtGui.QSound.play("notify.wav")

                #print "i =", i
                time.sleep(5.0)

        Alarm(myText)


def Main():
    for deviceId in phoneInfo:
        CheckValiditySIMCard(deviceId)

if __name__ == "__main__":
    Main()
