import common
# See maybe cerealizer -
# http://home.gna.org/oomadness/en/cerealizer/index.html
import pickle
import sys
import traceback
import UI


import base64
if common.DO_IMPORT_GDATA:
    import gdata.tlslite.utils.Python_AES

# A 32 bytes long randomly generated (by hand :) ) secret key .
secretKey = "12345678901234567890123456789012"
# secretKey = secretKey[:32]

"""
From C:\Python25\Lib\site-packages\gdata\tlslite\utils\cipherfactory.py
    "param IV: # A 16 byte string"
"""
AES_IV = "1234567890123456"


PHP_SERVER_NAME = "mobile-revival.110mb.com"
WEB_FOLDER = "/ReVival"
# """
"""
PHP_SERVER_NAME = "alexsusu.110mb.com"
WEB_FOLDER = "/iCam"
"""

SETTINGS_FILENAME = None



"""
Note: notLoadedSettings is really NOT redundant - it is True when the settings
  file is not available, in which case LoadSettings() returns a fresh instance
  of class Settings.
"""
notLoadedSettings = False

myCfg = None





# Note: user for youtubeDeveloperKey: ender123@gmail.com???
YOUTUBE_TEST_CLIENT_ID = "ytapi-pythonclientlibrary_servicetest"
youtubeDeveloperKey = \
    "AI39si6eJ7T_TA4Xwl-jZkLDjxi83JPvhgt46Q6k_QfCRWbpW5izuvHCDIw6hjC_C"\
    "DzyhfPIbisquvtcj0mlotr6ejJGSXA_lg"



def SetVolume():
    for aIndexVideo in range(myCfg.NUM_VIDEOS):
        try:
            if UI.player[aIndexVideo] is not None:
                UI.player[aIndexVideo].audio_set_volume( \
                        myCfg.audioVolume * \
                        (1 - myCfg.audioMute))
        except:
            common.DebugPrintErrorTrace()


def SetMediaPathFileName():
    for i in range(myCfg.NUM_VIDEOS):
    # for i in range(4):
        try:
            """
            UI.mediaPathFileName[i] = Settings.myCfg.deviceId[i] +
                "/CurrentSymLink_%d" % Settings.myCfg.cameraId[i] + ".3gp"
            """
            UI.mediaPathFileName[i] = myCfg.deviceId[i] + \
                "/CurrentSymLink_%d" % myCfg.cameraId[i] + \
                common.PHONE_MEDIA_EXTENSION

            UI.imagePathFileName[i] = myCfg.deviceId[i] + \
                "/CurrentSymLink_%d" % myCfg.cameraId[i] + ".jpg"
        except:
            common.DebugPrintErrorTrace()




googlePassword = None
def GetGooglePassword():
    global googlePassword

    if common.DO_IMPORT_GDATA == False:
        return ""

    try:
        if googlePassword is not None:
            return googlePassword

        # Settings.myCfg.googlePasswordEncrypted contains the password read
        #   from STATE_LOCAL_FILENAME
        if myCfg.googlePasswordEncrypted is None:
            return ""
        else:
            """
            I need to reinitialize the Python_AES for decryption because the
                self.IV which is initalized with the 3rd param in new() is
                changed at every Python_AES.encrypt() call, so I need self.IV
                again with the initial value.

            #cipher = python_AES.new(secretKey, 2, AES_IV)
            """
            cipher = gdata.tlslite.utils.Python_AES.new(secretKey, 2, AES_IV)
            googlePasswordAux = cipher.decrypt(base64.b64decode( \
                                    myCfg.googlePasswordEncrypted))
            # print "decodedText = %s" % decodedText

            """
            We remove the added spaces at the end of the password to make it
                have length % 16 == 0.
            Funny: if we leave the password with trailing spaces
                gdata + youtube don't complain and it logs in.
            """
            googlePasswordAux = str(googlePasswordAux) # I saw it is Unicode

            if False:
                common.DebugPrint( \
                    "GetGooglePassword(): googlePasswordAux = %s" % \
                    googlePasswordAux)

            return googlePasswordAux.rstrip()
    except:
        common.DebugPrintErrorTrace()


def SetGooglePassword(googlePasswordClear):
    global googlePassword # !!!!TODO: double-check if good
    global myCfg

    if common.DO_IMPORT_GDATA == False:
        return ""

    try:
        googlePassword = googlePasswordClear

        plainText = googlePassword  # GetGooglePassword()

        while len(plainText) % 16 != 0:
            plainText += " "

        # cipher = Python_AES.new(secretKey, 2, AES_IV)
        cipher = gdata.tlslite.utils.Python_AES.new(secretKey, 2, AES_IV)

        # clearText
        encodedText = base64.b64encode(cipher.encrypt(plainText))

        myCfg.googlePasswordEncrypted = encodedText
    except:
        common.DebugPrintErrorTrace()


#rotateVal = ["0", "90", "180", "270"]
class Settings:
    audioVolume = 200
    audioMute = 0
    NUM_VIDEOS = 4 # 5

    #PAUSE_INTERVAL = 2.0 # in seconds
    #PAUSE_INTERVAL = 30.0 # in seconds
    # PAUSE_BETWEEN_VIDEOS = 0.1
    PAUSE_BETWEEN_VIDEOS = 5.0
    # PAUSE_BETWEEN_VIDEOS = 10.0

    #LOCAL_VIDEO_PATH_FILENAME = "668066806680668/i6YwApSD12o.flv"
    LOCAL_VIDEO_PATH_FILENAME = "2010_11_06_19_39_36_0.3gp" # short video

    playHowManyTimesSameVideo = 2
    titleFontSize = 13 # 15
    googleUsername = None
    googlePasswordEncrypted = None
    iCamServerAddress = PHP_SERVER_NAME

    #!!!!TODO: automatically create lists of length UI.MAX_NUM_VIDEOS
    mediaServer = [
        0,
        0,
        0,
        0,
        0,
        0,
        0 # One more element for slideshow.
        ]

    # GetPhoneModel() #"Android device"
    youtubeGroupKeywords = ""

    deviceId = [
                #"N95N95N95N95N95",
                "668066806680668", #"", #"668066806680668", 
                "668066806680668", #"", #"668066806680668", 
                "612061206120612", #"", #"612061206120612", 
                "612061206120612", #"", #"612061206120612"
                "N82N82N82N82N82",
                "N82N82N82N82N82"
        ]

    cameraId = [
            0,
            1,
            0,
            1,
            0,
            1,
            0 # One more element for slideshow.
        ]

    rotateDegrees = [
            0,
            0,
            0,
            0,
            0,
            0,
            0 # One more element for slideshow.
        ]

    brightness = [
            1.0,
            1.0,
            1.0,
            1.0,
            1.0,
            1.0,
            0.0  # One more element for slideshow.
        ]

    contrast = [
            1.0,
            1.0,
            1.0,
            1.0,
            1.0,
            1.0,
            0.0 # One more element for slideshow.
        ]

    hue = [
            1.0,
            1.0,
            1.0,
            1.0,
            1.0,
            1.0,
            0.0 # One more element for slideshow.
        ]

    saturation = [
            1.0,
            1.0,
            1.0,
            1.0,
            1.0,
            1.0,
            0.0 # One more element for slideshow.
        ]

    gamma = [
            1.0,
            1.0,
            1.0,
            1.0,
            1.0,
            1.0,
            0.0 # One more element for slideshow.
        ]

    videoAnalysis = 0
    videoAnalysisShowDifferences = 0
    audioAnalysis = 0

    """
    NUM_VIDEOS = 3
    deviceId = [
                "N95N95N95N95N95",
                "612061206120612",
                "612061206120612",
                "N82N82N82N82N82", 
                #"668066806680668",
                "668066806680668", 
                "612061206120612"
    ]

    cameraId = [
                0,
                0,
                1,
                0
    ]
    """

    """
    NUM_VIDEOS = 4
    #NUM_VIDEOS = 3
    #NUM_VIDEOS = 1
    #PAUSE_INTERVAL = 2.0 #in seconds
    #PAUSE_INTERVAL = 30.0 #in seconds
    FALSE = 0

    deviceId = [
                #"N95N95N95N95N95",
                "668066806680668", 
                "668066806680668", 
                "612061206120612", 
                "612061206120612"
                #"N82N82N82N82N82"
    ]

    cameraId = [
                0,
                1,
                0,
                1
                #0
    ]
    """


    def __init__(self, aSettingsFileName):
        global SETTINGS_FILENAME

        SETTINGS_FILENAME = aSettingsFileName

        common.DebugPrint("aSettingsFileName = %s." % aSettingsFileName)


    def StoreSettings(self):
        """
        common.DebugPrint(
            "StoreSettings(): self.NUM_VIDEOS = %d.\n" % \
                                    self.NUM_VIDEOS +

            "StoreSettings(): self.deviceId = %s" % self.deviceId)
        """
        try:
            self.titleFontSize = self.titleFontSize
            """
            #!!!!
            #When value of self.titleFontSize changes, I should give:
            for index in range(5!!!!):
                #See http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qfont.html:
                #   "__init__ (self, QString family, int pointSize = -1,
                #               int weight = -1, bool italic = False)"
                videoTitle[index].setFont(QtGui.QFont("Courier",
                                            self.titleFontSize, 50, False))
            """

            """
            It seems I need to execute these operations in order to pickle
              all data members of class Settings. Strange!!!!
            """
            self.audioVolume = self.audioVolume
            self.audioMute = self.audioMute
            self.NUM_VIDEOS = self.NUM_VIDEOS
            self.PAUSE_BETWEEN_VIDEOS = \
                self.PAUSE_BETWEEN_VIDEOS
            self.playHowManyTimesSameVideo = \
                self.playHowManyTimesSameVideo
            self.deviceId = self.deviceId
            self.cameraId = self.cameraId
            self.mediaServer = self.mediaServer
            self.googleUsername = self.googleUsername
            self.googlePasswordEncrypted = \
                self.googlePasswordEncrypted
            self.iCamServerAddress = self.iCamServerAddress
            self.videoAnalysis = self.videoAnalysis
            self.videoAnalysisShowDifferences = \
                self.videoAnalysisShowDifferences
            self.audioAnalysis = self.audioAnalysis

            # self.rotateIndex = self.rotateIndex
            self.rotateDegrees = self.rotateDegrees
            self.brightness = self.brightness
            self.contrast = self.contrast
            self.hue = self.hue
            self.saturation = self.saturation
            self.gamma = self.gamma

            self.LOCAL_VIDEO_PATH_FILENAME = \
                self.LOCAL_VIDEO_PATH_FILENAME

            """
            Inspired from first example at
                http://docs.python.org/library/pickle.html at 11.1.7:
            """
            fOutput = open(SETTINGS_FILENAME, "wb")

            # Pickle using protocol 0.
            pickle.dump(self, fOutput)
            fOutput.close()
        except:
            common.DebugPrintErrorTrace()


    def LoadSettings(self):
        """
        self = pickle.load(fInput) gave following exception, so we use do this
            operation outside the class:

        Traceback (most recent call last):
          File "Z:\1PhD\ReVival\iCamViewer\Settings.py", line 268, in LoadSettings
            self = pickle.load(fInput)
          File "C:\Python27\lib\pickle.py", line 1378, in load
            return Unpickler(file).load()
          File "C:\Python27\lib\pickle.py", line 858, in load
            dispatch[key](self)
          File "C:\Python27\lib\pickle.py", line 1070, in load_inst
            self._instantiate(klass, self.marker())
          File "C:\Python27\lib\pickle.py", line 1060, in _instantiate
            value = klass(*args)
        TypeError: in constructor for Settings: 'module' object is not callable
        """
        try:
            common.DebugPrint( \
                "Entered GlobalLoadSettings(): self.audioVolume = %d." % \
                    self.audioVolume)

            """
            Inspired from second example at 
                http://docs.python.org/library/pickle.html at 11.1.7:
            """
            fInput = open(SETTINGS_FILENAME, "rb")

            """
            mySettingsTmp = pickle.load(fInput)
            mySettings.audioVolume = mySettingsTmp.audioVolume
            """
            #print "dir(self) = %d" % dir(self)
            resLoad = pickle.load(fInput)
            #print "dir(resLoad) = %d" % dir(resLoad)
            fInput.close()

            common.DebugPrint("LoadSettings(): self.audioVolume = %d." % \
                                                    self.audioVolume)
            common.DebugPrint(
                    "LoadSettings(): After load: \n" \
                    "   resLoad.mediaServer = %s,\n" \
                    "   resLoad.audioVolume = %d,\n" \
                    "   resLoad.audioMute = %d,\n" \
                    "   resLoad.NUM_VIDEOS = %d,\n" \
                    "   resLoad.PAUSE_BETWEEN_VIDEOS = %d,\n" \
                    "   resLoad.LOCAL_VIDEO_PATH_FILENAME = %s,\n" \
                    "   resLoad.deviceId = %s." % (
                        resLoad.mediaServer,
                        resLoad.audioVolume,
                        resLoad.audioMute,
                        resLoad.NUM_VIDEOS,
                        resLoad.PAUSE_BETWEEN_VIDEOS,
                        resLoad.LOCAL_VIDEO_PATH_FILENAME,
                        str(resLoad.deviceId)
                    ))
        except:
            global notLoadedSettings
            resLoad = self
            notLoadedSettings = True
            common.DebugPrintErrorTrace()

        return resLoad
