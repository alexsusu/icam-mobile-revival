import base64
import common
if common.DO_IMPORT_GDATA:
    import gdata.tlslite.utils.Python_AES
import Settings
import os
import sys
import traceback
import UI



if common.MY_PYSIDE:
    from PySide import QtCore, QtGui
    from PySide.QtGui import QFileDialog
elif common.MY_PYQT:
    from PyQt4 import Qt
    # For Dialog
    from PyQt4 import QtCore, QtGui
    from PyQt4.Qt import QFileDialog


class SettingsDialog(QtGui.QDialog):
    """
    Note: if we declare here mainLayout, it means it is a static data member
        (or "attribute reference").
      To work you need to create mainLayout in __init__() with
        self.mainLayout.
      Unfortunately http://docs.python.org/tutorial/classes.html doesn't
        explain this issue :(.
    """

    #mainLayout = QtGui.QGridLayout()

    """
    playHowManyTimesSameVideoInput
    pauseBetweenVideosInput
    numVideosInput
    googleUsernameInput
    googlePasswordInput
    iCamServerAddressInput
    videoAnalysis
    videoAnalysisShowDifferences
    audioAnalysis
    audioVolumeSlider
    titleFontSizeInput
    """

    def SliderOnValueChanged(self, aVal):
        try:
            common.DebugPrint(
                "Entered SliderOnValueChanged(): aVal = %d." % aVal)
            """
            try:
                # See http://www.pyside.org/docs/pyside/PySide/QtGui/QAbstractSlider.html#PySide.QtGui.QAbstractSlider
                #self.audioVolumeSlider.sliderPosition() (or .value())

                print "Entered SliderOnValueChanged(): " \
                        "self.audioVolumeSlider.sliderPosition() = %d, " \
                        "aVal = %d." % \
                        (self.audioVolumeSlider.sliderPosition(), aVal)
            except:
                common.DebugPrintErrorTrace()
            """

            # self.audioVolume = aVal
            Settings.myCfg.audioVolume = aVal

            # See http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qlabel.html#setText .
            self.audioVolumeLabel.setText("Audio volume [0-200%%]: %d" % \
                                            Settings.myCfg.audioVolume)

            Settings.SetVolume()
            Settings.myCfg.StoreSettings()

            # See http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qabstractbutton.html#setText
            # self.skipButton.setText("Skip %d" % self.audioVolume)
        except:
            common.DebugPrintErrorTrace()


    def OnClickOkButton(self):
        common.DebugPrint("Entered SettingsDialog::OnClickOkButton().")

        try:
            Settings.myCfg.PAUSE_BETWEEN_VIDEOS = \
                self.pauseBetweenVideosInput.value()

            Settings.myCfg.titleFontSize = self.titleFontSizeInput.value()
            Settings.myCfg.NUM_VIDEOS = self.numVideosInput.value()

            Settings.myCfg.playHowManyTimesSameVideo = \
                self.playHowManyTimesSameVideoInput.value()

            Settings.myCfg.googleUsername = self.googleUsernameInput.text()

            Settings.SetGooglePassword(str(self.googlePasswordInput.text()))

            Settings.myCfg.iCamServerAddress = self.iCamServerAddressInput.text()

            Settings.myCfg.videoAnalysis = self.videoAnalysis.isChecked()

            Settings.myCfg.videoAnalysisShowDifferences = \
                self.videoAnalysisShowDifferences.isChecked()

            Settings.myCfg.audioAnalysis = self.audioAnalysis.isChecked()
            # myCfg.videoAnalysis = iCamServerAddressInput.text()

            """
            #See http://www.pyside.org/docs/pyside/PySide/QtGui/QCheckBox.html
            #  (and http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qcheckbox.html#checkState)

            #common.DebugPrint( \
            #    "SettingsDialog::OnClickOkButton(): " \
            #    "videoAnalysis.checkStateSet() = %s\n" % \
            #    str(videoAnalysis.checkStateSet()))

            #common.DebugPrint( \
            #    "SettingsDialog::OnClickOkButton(): " \
            #    "videoAnalysis.checkStateSet() = %s\n" % \
            #    str(videoAnalysis.checkState()))

            common.DebugPrint(
                "SettingsDialog::OnClickOkButton(): " \
                    "videoAnalysis.checkStateSet() = %s\n",
                    str(videoAnalysis.isChecked()) + \

                "SettingsDialog::OnClickOkButton(): " \
                    "audioAnalysis.checkStateSet() = %s" % \
                    str(audioAnalysis.isChecked()))

            #common.DebugPrint("SettingsDialog::OnClickOkButton(): " \
            #   "audioAnalysis.checkStateSet() = %s\n" % \
            #   str(audioAnalysis.checkStateSet()))

            """
            Settings.myCfg.StoreSettings()
        except:
            common.DebugPrintErrorTrace()

        """
        Close the dialog.
        See http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qdialog.html#done
            (and http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qwidget.html#close)
        """
        self.done(0)


    def __init__(self, parent = None):
        try:
            super(SettingsDialog, self).__init__(parent)
            self.mainLayout = QtGui.QGridLayout()

            # """ buttonBox = QtGui.QDialogButtonBox(QtCore.Qt.Vertical)
            buttonBox = QtGui.QDialogButtonBox(QtCore.Qt.Horizontal)
            self.mainLayout.addWidget(buttonBox, 2, 0, 1, 1)
            # """

            okButton = QtGui.QPushButton("Ok")
            okButton.setDefault(True)
            buttonBox.addButton(okButton,
                                QtGui.QDialogButtonBox.ActionRole)
            # QtCore.QObject.connect(okButton,
            # QtCore.SIGNAL("clicked()"), lambda:
            # SlideshowSliderOnValueChanged(0))

            if common.MY_PYSIDE:
                QtCore.QObject.connect(okButton,
                        QtCore.SIGNAL("clicked()"),
                        self.OnClickOkButton)
            elif common.MY_PYQT:
                Qt.QObject.connect(okButton, Qt.SIGNAL("clicked()"),
                                   self.OnClickOkButton)
            """
            muteButton = QtGui.QPushButton("Mute")
            muteButton.setDefault(True)
            buttonBox.addButton(muteButton, QtGui.QDialogButtonBox.ActionRole)
            #QtCore.QObject.connect(muteButton, QtCore.SIGNAL("clicked()"),
            #    lambda: SlideshowSliderOnValueChanged(0))
            #########################INLINED FUNCTION##########################
            def OnClickMuteButton():
                pass

            if common.MY_PYSIDE:
                QtCore.QObject.connect(muteButton, QtCore.SIGNAL("clicked()"),
                                        OnClickMuteButton)
            elif common.MY_PYQT:
                Qt.QObject.connect(muteButton, Qt.SIGNAL("clicked()"),
                                    OnClickMuteButton)
            """
            googleUsernameLabel = QtGui.QLabel()

            """
            -1 as much as possible, (then if still same video on, don't
                display anymore)
            """
            googleUsernameLabel.setText("YouTube/Picasa Username:")

            self.mainLayout.addWidget(googleUsernameLabel)

            """
            See
              http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qlineedit.html
            """
            self.googleUsernameInput = QtGui.QLineEdit()

            if Settings.myCfg.googleUsername != None:
                self.googleUsernameInput.setText(Settings.myCfg.googleUsername)
            self.mainLayout.addWidget(self.googleUsernameInput)
            googlePasswordLabel = QtGui.QLabel()

            """
            -1 as much as possible, (then if still same video on, don't
                    display anymore)
            """
            googlePasswordLabel.setText("YouTube/Picasa Password:")

            self.mainLayout.addWidget(googlePasswordLabel)

            # See http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qlineedit.html
            self.googlePasswordInput = QtGui.QLineEdit()

            pwdStr = Settings.GetGooglePassword()

            common.DebugPrint("SettingsDialog::__init__(): pwdStr = %s." % str(pwdStr))

            if pwdStr != None:
                self.googlePasswordInput.setText(pwdStr)

            # Can also use QtGui.QLineEdit.Password or QtGui.QLineEdit.NoEcho
            self.googlePasswordInput.setEchoMode(QtGui.QLineEdit.PasswordEchoOnEdit)

            self.mainLayout.addWidget(self.googlePasswordInput)
            iCamServerLabel = QtGui.QLabel()

            """
            -1 as much as possible, (then if still same video on, don't
                display anymore)
            """
            iCamServerLabel.setText("iCam Server Address:")

            self.mainLayout.addWidget(iCamServerLabel)

            """
            See http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qlineedit.html
            """
            self.iCamServerAddressInput = QtGui.QLineEdit()

            self.iCamServerAddressInput.setText(Settings.myCfg.iCamServerAddress)
            self.mainLayout.addWidget(self.iCamServerAddressInput)
            self.audioVolumeLabel = QtGui.QLabel()
            #self.audioVolumeLabel.setFont(QtGui.QFont("Courier", 15, 50, False))

            # See http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qfont.html
            # See http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qlabel.html#setText .
            self.audioVolumeLabel.setText("Audio volume [0-200%%]: %d" % \
                                            Settings.myCfg.audioVolume)

            self.mainLayout.addWidget(self.audioVolumeLabel)
            self.audioVolumeSlider = QtGui.QSlider()

            """
            # Inspired from http://www.devshed.com/c/a/Python/PyQT-Getting-Started/3/:
            slider1 = QtGui.QSlider(self,"slider1")
            audioVolumeSlider.setGeometry(QtCore.QRect(130,220,261,31))
            """
            self.audioVolumeSlider.setOrientation(QtCore.Qt.Horizontal)

            # See http://www.opendocs.net/pyqt/pyqt4/html/qslider.html#tickInterval
            self.audioVolumeSlider.setTickInterval(20)

            # See http://www.opendocs.net/pyqt/pyqt4/html/qslider.html
            self.audioVolumeSlider.setTickPosition(QtGui.QSlider.TicksBelow)

            # See http://www.opendocs.net/pyqt/pyqt4/html/qabstractslider.html#setMinimum
            self.audioVolumeSlider.setMinimum(0)

            """
            See http://www.opendocs.net/pyqt/pyqt4/html/qabstractslider.html#setMaximum
            """
            self.audioVolumeSlider.setMaximum(200)  

            """
            common.DebugPrint(
                "SettingsDialog(): myCfg.audioVolume = %d." % \
                        Settings.myCfg.audioVolume)
            """
            self.audioVolumeSlider.setValue(Settings.myCfg.audioVolume)
            # self.audioVolume)

            self.mainLayout.addWidget(self.audioVolumeSlider)

            QtCore.QObject.connect(self.audioVolumeSlider,
                                   QtCore.SIGNAL("valueChanged(int)"),
                                   self.SliderOnValueChanged)
            """
            Maybe interesting for case common.MY_PYSIDE:
            From http://blog.rburchell.com/2010/02/simple-pyside-tutorial-2-signals-and.html:
            self.connect(self.audioVolumeSlider,
                QtCore.SIGNAL("valueChanged(int)"), self.audioVolumeSlider,
                QtCore.SLOT("SliderOnValueChanged(int)"));

            Not useful so far:
                It seems signal handling is buggy for QSlider on PySide:
                    http://permalink.gmane.org/gmane.comp.lib.qt.pyside/2057
            """
            numVideosLabel = QtGui.QLabel()
            numVideosLabel.setText("Number of Views:")
            self.mainLayout.addWidget(numVideosLabel)

            # See http://www.opendocs.net/pyqt/pyqt4/html/qspinbox.html
            self.numVideosInput = QtGui.QSpinBox()

            self.numVideosInput.setValue(Settings.myCfg.NUM_VIDEOS)
            self.numVideosInput.setMaximum(6) # 4)
            self.numVideosInput.setMinimum(0)
            self.mainLayout.addWidget(self.numVideosInput)
            viewButton = [None] * UI.MAX_NUM_VIDEOS


            def OnClickViewButton(anIndexVideo=0):
                settingsViewDialog = SettingsViewDialog(anIndexVideo)
                settingsViewDialog.exec_()

            OnClickViewButtonCurried = lambda anIndexVideo: (lambda : \
                                            OnClickViewButton(anIndexVideo))

            for i in range(Settings.myCfg.NUM_VIDEOS):
                viewButton[i] = QtGui.QPushButton("View #%d" % (i + 1))
                viewButton[i].setDefault(False)
                # buttonBox.addButton(view1Button,
                # QtGui.QDialogButtonBox.ActionRole)

                self.mainLayout.addWidget(viewButton[i])

                if common.MY_PYSIDE:
                    QtCore.QObject.connect(viewButton[i],
                                            QtCore.SIGNAL("clicked()"),
                                            OnClickViewButtonCurried(i))
                elif common.MY_PYQT:
                    Qt.QObject.connect(viewButton[i],
                                            Qt.SIGNAL("clicked()"),
                                            OnClickViewButtonCurried(i))

            playHowManyTimesSameVideoLabel = QtGui.QLabel()
            playHowManyTimesSameVideoLabel.setText("Play how many times the "
                                                    "same video:")

            """
            -1 as much as possible, (then if still same video on, don't
                display anymore)
            """
            self.mainLayout.addWidget(playHowManyTimesSameVideoLabel)

            # See http://www.opendocs.net/pyqt/pyqt4/html/qspinbox.html
            self.playHowManyTimesSameVideoInput = QtGui.QSpinBox()
            self.playHowManyTimesSameVideoInput.setMaximum(1000)
            self.playHowManyTimesSameVideoInput.setMinimum(0)
            #self.playHowManyTimesSameVideoInput.setRange(0, 1000)
            """
            IMPORTANT: Need to put setValue after setRange - the default
                range has maximum 1000.
            """
            self.playHowManyTimesSameVideoInput.setValue(
                                    Settings.myCfg.playHowManyTimesSameVideo)
            self.mainLayout.addWidget(self.playHowManyTimesSameVideoInput)


            pauseBetweenVideosLabel = QtGui.QLabel()
            pauseBetweenVideosLabel.setText("Pause between videos " \
                                            "[0-100 sec]:")
            self.mainLayout.addWidget(pauseBetweenVideosLabel)

            # See http://www.opendocs.net/pyqt/pyqt4/html/qspinbox.html
            self.pauseBetweenVideosInput = QtGui.QSpinBox()
            self.pauseBetweenVideosInput.setMaximum(100)
            self.pauseBetweenVideosInput.setMinimum(0)
            self.pauseBetweenVideosInput.setValue(
                                        Settings.myCfg.PAUSE_BETWEEN_VIDEOS)
            self.mainLayout.addWidget(self.pauseBetweenVideosInput)


            titleFontSizeLabel = QtGui.QLabel()
            titleFontSizeLabel.setText("Title font size [6-50]:")
            self.mainLayout.addWidget(titleFontSizeLabel)

            # See http://www.opendocs.net/pyqt/pyqt4/html/qspinbox.html
            self.titleFontSizeInput = QtGui.QSpinBox()

            self.titleFontSizeInput.setValue(Settings.myCfg.titleFontSize)
            self.titleFontSizeInput.setMaximum(50)
            self.titleFontSizeInput.setMinimum(6)
            self.mainLayout.addWidget(self.titleFontSizeInput)


            analysisLabel = QtGui.QLabel()
            analysisLabel.setText("Media Analysis:")
            self.mainLayout.addWidget(analysisLabel)

            """
            Inspired from 
                http://www.devshed.com/c/a/Python/PyQT-Input-Widgets/1/

            See http://www.pyside.org/docs/pyside/PySide/QtGui/QCheckBox.html
              (and 
              http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qcheckbox.html)
            """
            self.videoAnalysis = QtGui.QCheckBox("&Perform Video analysis")

            # videoAnalysis.setTristate(TRUE)
            if Settings.myCfg.videoAnalysis:
                self.videoAnalysis.setCheckState(QtCore.Qt.Checked)
                #Qt.PartiallyChecked instead
            else:
                self.videoAnalysis.setCheckState(QtCore.Qt.Unchecked)

            self.mainLayout.addWidget(self.videoAnalysis)

            """
            # See http://www.pyside.org/docs/pyside/PySide/QtGui/QCheckBox.html
                (and http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qcheckbox.html)
            """
            self.videoAnalysisShowDifferences = QtGui.QCheckBox(
                                        "  Video analysis - show differences")

            # if Settings.myCfg.videoAnalysisDiff:
            if Settings.myCfg.videoAnalysisShowDifferences:
                self.videoAnalysisShowDifferences.setCheckState(QtCore.Qt.Checked)
                #Qt.PartiallyChecked
            else:
                self.videoAnalysisShowDifferences.setCheckState(QtCore.Qt.Unchecked)

            self.mainLayout.addWidget(self.videoAnalysisShowDifferences)

            """
            See http://www.pyside.org/docs/pyside/PySide/QtGui/QCheckBox.htm
                (and 
                http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qcheckbox.html)
            """
            self.audioAnalysis = QtGui.QCheckBox("&Perform Audio analysis")

            if Settings.myCfg.audioAnalysis:
                self.audioAnalysis.setCheckState(QtCore.Qt.Checked)
            else:
                self.audioAnalysis.setCheckState(QtCore.Qt.Unchecked)

            self.mainLayout.addWidget(self.audioAnalysis)

            alarmLabel = QtGui.QLabel()

            """
            alarmLabel.setText("Alarm detection criteria/action (alarm " \
                                "on PC, phone number to call, email):")
            """
            alarmLabel.setText("Alarm detection criteria/action:")
            # (alarm on PC, phone number to call, email)

            self.mainLayout.addWidget(alarmLabel)

            """
            socketTimeoutLabel = QtGui.QLabel()
            socketTimeoutLabel.setText("Socket timeout:")
            self.mainLayout.addWidget(socketTimeoutLabel)
            """

            #self.setMinimumSize(300, 300)
            self.setMinimumSize(200, 650)

            #self.setMinimumSize(1024, 680) self.setMinimumSize(1000, 650)
            #self.setMaximumSize(1024, 680)
            self.adjustSize()

            """
            self.setSizePolicy(QtGui.QSizePolicy.Ignored,
                                QtGui.QSizePolicy.Ignored)
            """

            self.setLayout(self.mainLayout)
            self.setWindowTitle("Settings iCam Viewer")
        except:
            # extension.hide()
            common.DebugPrintErrorTrace()




class SettingsViewDialog(QtGui.QDialog):
    """
    mediaServerInput
    self.mediaServerInputValuesList
    deviceIdInput
    cameraIdListInput
    cameraIdInputValuesList
    rotateInput
    self.brightnessSlider
    """

    cameraIdInputValuesList = ["Main", "VGA"]

    def OpenFileDialog(self):
        """
        Opens the QFileDialog for accepting user input
        for the input image file path (self._filePath)
        """

        #Settings.myCfg.LOCAL_VIDEO_PATH_FILENAME = ""

        Settings.myCfg.LOCAL_VIDEO_PATH_FILENAME = \
            QFileDialog.getOpenFileName(
                self,
                "Select Local Video File",
                "",
                "Video file (*.mpg);;FLV(*.flv);;3gp(*.3gp);;AVI(*.avi);;All Files (*.*);;")

        if type(Settings.myCfg.LOCAL_VIDEO_PATH_FILENAME) is tuple:
            Settings.myCfg.LOCAL_VIDEO_PATH_FILENAME = \
                Settings.myCfg.LOCAL_VIDEO_PATH_FILENAME[0]

        common.DebugPrint("After QFileDialog, " \
                            "Settings.LOCAL_VIDEO_PATH_FILENAME = %s" % \
                            Settings.myCfg.LOCAL_VIDEO_PATH_FILENAME)

        if Settings.myCfg.LOCAL_VIDEO_PATH_FILENAME:
            Settings.myCfg.LOCAL_VIDEO_PATH_FILENAME = \
                os.path.normpath(str(Settings.myCfg.LOCAL_VIDEO_PATH_FILENAME))
            #self._dialog.fileLineEdit.setText(self._filePath)
        Settings.myCfg.StoreSettings()


    def OnClickOkButton(self):
        try:
            mediaServerInputSelectedItems = \
                self.mediaServerInput.selectedItems()

            """
            See for interesting amusement
              http://stackoverflow.com/questions/364621/python-get-position-in-list
            """
            Settings.myCfg.mediaServer[self.indexVideo] = \
                self.mediaServerInputValuesList.index(
                                    mediaServerInputSelectedItems[0].text())

            # For Local disk we ask the user to select a video file for play:
            if Settings.myCfg.mediaServer[self.indexVideo] == 3:
                self.OpenFileDialog()

            """
            #QListWidget.currentItem() returns the QListWidget item that has
            #    focus - it is possible to have item(s) selected WITHOUT FOCUS.
            print "SettingsViewDialog::OnClickOkButton(): " \
                    "mediaServerInput.currentItem() = %s." % \
                    ( str(mediaServerInput.currentItem()) )
            """
            common.DebugPrint(
                "SettingsViewDialog::OnClickOkButton(): " \
                    "mediaServerInput.selectedItems() = %s.\n" % \
                    str(mediaServerInputSelectedItems) + \

                "SettingsViewDialog::OnClickOkButton(): " \
                    "mediaServerInputSelectedItems[0].text() = %s.\n" % \
                    mediaServerInputSelectedItems[0].text() + \

                "SettingsViewDialog::OnClickOkButton(): " \
                    "myCfg.mediaServer[self.indexVideo] = %d.\n" % \
                    Settings.myCfg.mediaServer[self.indexVideo])

            Settings.myCfg.deviceId[self.indexVideo] = \
                str(self.deviceIdInput.text().__str__())

            cameraIdListInputSelectedItems = \
                self.cameraIdListInput.selectedItems()

            Settings.myCfg.cameraId[self.indexVideo] = \
                self.cameraIdInputValuesList.index(
                        cameraIdListInputSelectedItems[0].text())

            """
            if cameraIdListWidgetItem[0].isSelected():
                cameraIdListIndex = 0
            elif cameraIdListWidgetItem[1].isSelected():
                cameraIdListIndex = 1
            Settings.myCfg.cameraId[self.indexVideo] = cameraIdListIndex
            """

            """
            In case we changed Settings.myCfg.cameraId and deviceId we
                update UI.mediaPathFileName
            """
            Settings.SetMediaPathFileName()
            Settings.myCfg.rotateDegrees[self.indexVideo] = \
                self.rotateInput.value()

            """
            if rotateListInputWidgetItem[0].isSelected():
                rotateListIndex = 0
            elif rotateListInputWidgetItem[1].isSelected():
                rotateListIndex = 1
            elif rotateListInputWidgetItem[2].isSelected():
                rotateListIndex = 2
            elif rotateListInputWidgetItem[3].isSelected():
                rotateListIndex = 3
            Settings.myCfg.rotateIndex[self.indexVideo] = rotateListIndex
            """

            Settings.myCfg.brightness[self.indexVideo] = \
                self.brightnessSlider.sliderPosition() / 100.0

            Settings.myCfg.contrast[self.indexVideo] = \
                self.contrastSlider.sliderPosition() / 100.0

            Settings.myCfg.hue[self.indexVideo] = \
                self.hueSlider.sliderPosition() / 100.0

            Settings.myCfg.saturation[self.indexVideo] = \
                self.saturationSlider.sliderPosition() / 100.0

            Settings.myCfg.gamma[self.indexVideo] = \
                self.gammaSlider.sliderPosition() / 100.0

            """
            common.DebugPrint(
                "SettingsViewDialog::OnClickOkButton(): " \
                    "myCfg.deviceId[%d] = %s, " \
                    "myCfg.PAUSE_BETWEEN_VIDEOS = %d, " \
                    "cameraIdListIndex = %d, " \
                    "myCfg.rotateDegrees[self.indexVideo] = %d." % \
                    (self.indexVideo,
                        Settings.myCfg.deviceId[self.indexVideo],
                        Settings.myCfg.PAUSE_BETWEEN_VIDEOS,
                        cameraIdListIndex,
                        Settings.myCfg.rotateDegrees[self.indexVideo]))
            """
            common.DebugPrint(
                "SettingsViewDialog::OnClickOkButton(): "\
                    "myCfg.deviceId[%d] = %s, "\
                    "myCfg.PAUSE_BETWEEN_VIDEOS = %d, "\
                    "myCfg.rotateDegrees[self.indexVideo] = %d." % \
                    (self.indexVideo,
                       Settings.myCfg.deviceId[self.indexVideo],
                       Settings.myCfg.PAUSE_BETWEEN_VIDEOS,
                       Settings.myCfg.rotateDegrees[self.indexVideo]))

            Settings.myCfg.StoreSettings()
        except:
            common.DebugPrintErrorTrace()

        """
        Close the dialog.
          See http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qdialog.html#done
          (and http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qwidget.html#close)
        """
        self.done(0)

    """
    def SliderOnValueChanged(self, aVal):
        common.DebugPrint("Entered SliderOnValueChanged(): aVal = %d." % aVal)

        #try:
        # See http://www.pyside.org/docs/pyside/PySide/QtGui/QAbstractSlider.html#PySide.QtGui.QAbstractSlider
        #    #self.audioVolumeSlider.sliderPosition() (or .value())
        #    common.DebugPrint("Entered SliderOnValueChanged(): " \
        #           "self.audioVolumeSlider.sliderPosition() = %d, " \
        #           "aVal = %d." % \
        #           (self.audioVolumeSlider.sliderPosition(), aVal))
        #except:
        #    common.DebugPrintErrorTrace()

        #self.audioVolume = aVal
        Settings.myCfg.audioVolume = aVal

        # See http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qlabel.html#setText
        self.audioVolumeLabel.setText("Audio volume [0-200%%]: %d" % \
                                                Settings.myCfg.audioVolume)

        Settings.SetVolume()
        Settings.myCfg.StoreSettings()

        # See http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qabstractbutton.html#setText
        #self.skipButton.setText("Skip %d" % self.audioVolume)
    """

    def __init__(self, anIndexVideo, parent = None):
        try:
            self.indexVideo = anIndexVideo
            super(SettingsViewDialog, self).__init__(parent)
            self.mainLayout = QtGui.QGridLayout()

            # """ buttonBox = QtGui.QDialogButtonBox(QtCore.Qt.Vertical)
            buttonBox = QtGui.QDialogButtonBox(QtCore.Qt.Horizontal)
            self.mainLayout.addWidget(buttonBox, 2, 0, 1, 1)
            # """

            okButton = QtGui.QPushButton("Ok")
            okButton.setDefault(True)
            buttonBox.addButton(okButton,
                                QtGui.QDialogButtonBox.ActionRole)
            # QtCore.QObject.connect(okButton,
            # QtCore.SIGNAL("clicked()"), lambda:
            # SlideshowSliderOnValueChanged(0))

            if common.MY_PYSIDE:
                QtCore.QObject.connect(okButton,
                        QtCore.SIGNAL("clicked()"),
                        self.OnClickOkButton)
            elif common.MY_PYQT:
                Qt.QObject.connect(okButton, Qt.SIGNAL("clicked()"),
                                   self.OnClickOkButton)
            """
            view1Label = QtGui.QLabel()
            view1Label.setText("View #1:")
            self.mainLayout.addWidget(view1Label)
            """

            mediaServerLabel = QtGui.QLabel()
            # See http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qlabel.html#setText
            mediaServerLabel.setText("Video source:") #"Media server:"
            self.mainLayout.addWidget(mediaServerLabel)

            self.mediaServerInputValuesList = ["YouTube", "Picasa", \
                                                "iCam server", \
                                                "Local video"] #"Local disk"]

            # See http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qlistwidget.html
            self.mediaServerInput = QtGui.QListWidget()

            for val in self.mediaServerInputValuesList:
                self.mediaServerInput.addItem(val)
            """
            #[None, None]
            mediaServerWidgetItem = [None] * len(self.mediaServerInputValuesList)

            #QListWidgetItem
            mediaServerWidgetItem[0] = mediaServerInput.item(0)

            #QListWidgetItem
            mediaServerWidgetItem[1] = mediaServerInput.item(1)

            # From
            #  http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qlistwidgetitem.html
            mediaServerWidgetItem[Settings.myCfg.mediaServer[self.indexVideo]].\
                                                            setSelected(True)
            """
            # From http://www.riverbankcomputing.co.uk/static/Docs/PyQt4
            # /html/qlistwidgetitem.html
            self.mediaServerInput.item(Settings.myCfg.mediaServer[
                                            self.indexVideo]).setSelected(True)

            """
            # For PyQt4, not supported by PySide
            cameraIdListInput.setItemSelected(cameraIdListWidgetItem[
                cameraId[self.indexVideo]], True)
            """
            self.mainLayout.addWidget(self.mediaServerInput)

            deviceIdLabel = QtGui.QLabel()
            # See http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qlabel.html#setText
            deviceIdLabel.setText("Device ID:")  
            self.mainLayout.addWidget(deviceIdLabel)

            try:
                initVal = Settings.myCfg.deviceId[self.indexVideo]
            except:
                common.DebugPrintErrorTrace()
                initVal = ""

            self.deviceIdInput = QtGui.QLineEdit(initVal)
            self.mainLayout.addWidget(self.deviceIdInput)
            """
            # From http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qstring.html
            #Settings.myCfg.deviceId[self.indexVideo] = \
            #                   str(deviceIdInput.placeholderText().__str__())

            # From http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qstring.html
            #   and http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qlineedit.html
            #Settings.myCfg.deviceId[self.indexVideo] = \
            #                   str(deviceIdInput.text.__str__())
            """

            cameraLabel = QtGui.QLabel()
            cameraLabel.setText("Camera broadcasting:")
            self.mainLayout.addWidget(cameraLabel)

            # See http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qlistwidget.html
            self.cameraIdListInput = QtGui.QListWidget()

            for val in self.cameraIdInputValuesList:
                self.cameraIdListInput.addItem(val)

            # From http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qlistwidgetitem.html
            self.cameraIdListInput.item(Settings.myCfg.cameraId[\
                                        self.indexVideo]).setSelected(True)

            """
            cameraIdListWidgetItem = [None, None]

            cameraIdListWidgetItem[0] = cameraIdListInput.item(0)
            #QListWidgetItem

            cameraIdListWidgetItem[1] = cameraIdListInput.item(1)
            #QListWidgetItem

            #From http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qlistwidgetitem.html
            cameraIdListWidgetItem[Settings.myCfg.cameraId[ \
                                        self.indexVideo]].setSelected(True)

            # For PyQt4, not supported by PySide:
            #cameraIdListInput.setItemSelected(cameraIdListWidgetItem[
            #                               cameraId[self.indexVideo]], True)
            """

            """
            #From http://www.qtcentre.org/threads/32007-SetSelection-QListView-Pyqt
            #    doesn't compile :)
            index = cameraIdListInput.listModel.index(0, 0, QModelIndex())
            mySelectionModel = QtGui.QItemSelectionModel()
            cameraIdListInput.mySelectionModel.select(index,
                                                self.mySelectionModel.Select)
            """

            """
            # Not working - don't know why
            selectionCmd = QtGui.QItemSelectionModel.SelectionFlags(1)

            #See http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qitemselectionmodel-selectionflags.html
            bla.setCurrentItem(cameraIdListWidgetItem[Settings.myCfg.cameraId[ \
                                            self.indexVideo]], selectionCmd)
            #AttributeError: 'PySide.QtGui.QListWidget' object has no attribute 'setItemSelected'
            """
            self.mainLayout.addWidget(self.cameraIdListInput)
            """
            common.DebugPrint(
                "SettingsViewDialog(): myCfg.deviceId[%d] = %s, " \
                    "myCfg.cameraId[self.indexVideo] = %d, " \
                    "cameraIdListWidgetItem[0] = %s, " \
                    "QtGui.QListWidget.selectedItems() = %s, " \
                    "myCfg.rotateIndex[self.indexVideo] = %d." \
                    % (self.indexVideo,
                    Settings.myCfg.deviceId[self.indexVideo],
                    Settings.myCfg.cameraId[self.indexVideo],
                    str(cameraIdListWidgetItem[0]),
                    str(cameraIdListInput.selectedItems()),
                    Settings.myCfg.rotateDegrees[self.indexVideo]))
            """
            common.DebugPrint(
                "SettingsViewDialog(): myCfg.deviceId[%d] " \
                    "= %s, myCfg.cameraId[self.indexVideo] = %d, " \
                    "myCfg.rotateIndex[self.indexVideo] = %d." % \
                    (self.indexVideo,
                       Settings.myCfg.deviceId[self.indexVideo],
                       Settings.myCfg.cameraId[self.indexVideo],
                       Settings.myCfg.rotateDegrees[self.indexVideo]))

            rotateLabel = QtGui.QLabel()
            rotateLabel.setText("Rotate:")
            self.mainLayout.addWidget(rotateLabel)

            # See http://www.opendocs.net/pyqt/pyqt4/html/qspinbox.html
            self.rotateInput = QtGui.QSpinBox()

            self.rotateInput.setRange(0, 270)
            """
            IMPORTANT: Need to put setValue after setRange - the default
                range has maximum 99.
            """
            self.rotateInput.setValue(Settings.myCfg.rotateDegrees[self.indexVideo])

            #rotateInput.setMinimum(0) rotateInput.setMaximum(270)
            self.rotateInput.setSingleStep(90)
            self.mainLayout.addWidget(self.rotateInput)
            """
            try:
                #See http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qlistwidget.html
                rotateListInput = QtGui.QListWidget()
                for i in range(len(rotateVal)):
                    rotateListInput.addItem(rotateVal[i])
                rotateListInputWidgetItem = [None, None, None, None]

                #QListWidgetItem
                rotateListInputWidgetItem[0] = rotateListInput.item(0)

                #QListWidgetItem
                rotateListInputWidgetItem[1] = rotateListInput.item(1)

                #QListWidgetItem
                rotateListInputWidgetItem[2] = rotateListInput.item(2)

                #QListWidgetItem
                rotateListInputWidgetItem[3] = rotateListInput.item(3)

                #From http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qlistwidgetitem.html
                rotateListInputWidgetItem[Settings.myCfg.rotateIndex[
                                            self.indexVideo]].setSelected(True)

                self.mainLayout.addWidget(rotateListInput)
            except:
                common.DebugPrintErrorTrace()
            """
            flipLabel = QtGui.QLabel()
            flipLabel.setText("Flip:")
            self.mainLayout.addWidget(flipLabel)

            hueLabel = QtGui.QLabel()
            hueLabel.setText("Hue:")
            self.mainLayout.addWidget(hueLabel)

            """
            Since slide "translates the handle's position into an
             integer value"
             (see http://www.opendocs.net/pyqt/pyqt4/html/qslider.html#details)
             we need to convert ourselves integer to float.
            """
            self.hueSlider = QtGui.QSlider()

            """
            Inspired from http://www.devshed.com/c/a/Python/PyQT-Getting-Started/3/ : 
                slider1 = QtGui.QSlider(self,"slider1")
                hueSlider.setGeometry(QtCore.QRect(130,220,261,31))
            """
            self.hueSlider.setOrientation(QtCore.Qt.Horizontal)

            # See http://www.opendocs.net/pyqt/pyqt4/html/qslider.html#tickInterval
            self.hueSlider.setTickInterval(1.0 * 100)

            self.hueSlider.setSingleStep(0.01 * 100)

            # See http://www.opendocs.net/pyqt/pyqt4/html/qslider.html
            self.hueSlider.setTickPosition(QtGui.QSlider.TicksBelow)

            # See http://www.opendocs.net/pyqt/pyqt4/html/qabstractslider.html#setMinimum
            self.hueSlider.setMinimum(0)


            # See http://www.opendocs.net/pyqt/pyqt4/html/qabstractslider.html#setMaximum
            self.hueSlider.setMaximum(7 * 100)

            self.hueSlider.setValue(Settings.myCfg.hue[self.indexVideo] * 100)
            self.mainLayout.addWidget(self.hueSlider)
            contrastLabel = QtGui.QLabel()
            contrastLabel.setText("Contrast:")
            self.mainLayout.addWidget(contrastLabel)

            """
            Since slide "translates the handle's position into an
             integer value"
             (see http://www.opendocs.net/pyqt/pyqt4/html/qslider.html#details)
             we need to convert ourselves integer to float.
            """
            self.contrastSlider = QtGui.QSlider()

            """
            # Inspired from http://www.devshed.com/c/a/Python/PyQT-Getting-Started/3/:
            slider1 = QtGui.QSlider(self,"slider1")
            contrastSlider.setGeometry(QtCore.QRect(130,220,261,31))
            """
            self.contrastSlider.setOrientation(QtCore.Qt.Horizontal)

            # See http://www.opendocs.net/pyqt/pyqt4/html/qslider.html#tickInterval
            self.contrastSlider.setTickInterval(1.0 * 100)

            self.contrastSlider.setSingleStep(0.01 * 100)

            # See http://www.opendocs.net/pyqt/pyqt4/html/qslider.html
            self.contrastSlider.setTickPosition(QtGui.QSlider.TicksBelow)

            # See http://www.opendocs.net/pyqt/pyqt4/html/qabstractslider.html#setMinimum
            self.contrastSlider.setMinimum(0)

            # See http://www.opendocs.net/pyqt/pyqt4/html/qabstractslider.html#setMaximum
            self.contrastSlider.setMaximum(2 * 100)
            self.contrastSlider.setValue( \
                    Settings.myCfg.contrast[self.indexVideo] * 100)

            self.mainLayout.addWidget(self.contrastSlider)
            brightnessLabel = QtGui.QLabel()
            brightnessLabel.setText("Brightness:")
            self.mainLayout.addWidget(brightnessLabel)

            """
            Since slide "translates the handle's position into an
             integer value"
             (see http://www.opendocs.net/pyqt/pyqt4/html/qslider.html#details)
             we need to convert ourselves integer to float.
            """
            self.brightnessSlider = QtGui.QSlider()

            """
            # Inspired from http://www.devshed.com/c/a/Python/PyQT-Getting-Started/3/ :
            slider1 =
            # QtGui.QSlider(self,"slider1")
            # brightnessSlider.setGeometry(QtCore.QRect(130,220,261,31))
            """
            self.brightnessSlider.setOrientation(QtCore.Qt.Horizontal)

            # See http://www.opendocs.net/pyqt/pyqt4/html/qslider.html#tickInterval
            self.brightnessSlider.setTickInterval(1.0 * 100)

            self.brightnessSlider.setSingleStep(0.01 * 100)

            # See http://www.opendocs.net/pyqt/pyqt4/html/qslider.html
            self.brightnessSlider.setTickPosition(QtGui.QSlider.TicksBelow)

            # See http://www.opendocs.net/pyqt/pyqt4/html/qabstractslider.html#setMinimum
            self.brightnessSlider.setMinimum(0)

            # See http://www.opendocs.net/pyqt/pyqt4/html/qabstractslider.html#setMaximum
            self.brightnessSlider.setMaximum(2 * 100)

            """
            common.DebugPrint(
                "SettingsDialog(): myCfg.brightness = %d." % \
                                        Settings.myCfg.brightness)
            """

            # self.brightness)
            self.brightnessSlider.setValue( \
                        Settings.myCfg.brightness[self.indexVideo] * 100)

            self.mainLayout.addWidget(self.brightnessSlider)

            """
            QtCore.QObject.connect(brightnessSlider,
                        QtCore.SIGNAL("valueChanged(int)"),
                        self.SliderOnValueChanged)
            """

            """
            Maybe interesting for common.MY_PYSIDE:
            From
              http://blog.rburchell.com/2010/02/simple-pyside-tutorial-2-signals-and.html:

            self.connect(self.brightnessSlider,
                        QtCore.SIGNAL("valueChanged(int)"),
                        self.brightnessSlider,
                        QtCore.SLOT("SliderOnValueChanged(int)"));

            # Not useful so far:
            #    It seems signal handling is buggy for QSlider on PySide:
            #    http://permalink.gmane.org/gmane.comp.lib.qt.pyside/2057
            """
            saturationLabel = QtGui.QLabel()
            saturationLabel.setText("Saturation:")
            self.mainLayout.addWidget(saturationLabel)
            #  Since slide "translates the handle's position into an
            # integer value" (see http://www.opendocs.net/pyqt/pyqt4/htm
            # l/qslider.html#details) we need to convert ourselves
            # integer to float.
            self.saturationSlider = QtGui.QSlider()

            """
            # Inspired from http://www.devshed.com/c/a/Python/PyQT-Getting-Started/3/ :
            #slider1 = QtGui.QSlider(self,"slider1")
            #saturationSlider.setGeometry(QtCore.QRect(130,220,261,31))
            """
            self.saturationSlider.setOrientation(QtCore.Qt.Horizontal)

            #See http://www.opendocs.net/pyqt/pyqt4/html/qslider.html#tickInterval
            self.saturationSlider.setTickInterval(1.0 * 100)

            self.saturationSlider.setSingleStep(0.01 * 100)

            # See http://www.opendocs.net/pyqt/pyqt4/html/qslider.html
            self.saturationSlider.setTickPosition(QtGui.QSlider.TicksBelow)

            """
            See
             http://www.opendocs.net/pyqt/pyqt4/html/qabstractslider.html#setMinimum
            """
            self.saturationSlider.setMinimum(0)

            # See http://www.opendocs.net/pyqt/pyqt4/html/qabstractslider.html#setMaximum
            self.saturationSlider.setMaximum(4 * 100)

            self.saturationSlider.setValue(
                                Settings.myCfg.saturation[self.indexVideo] * 100)

            self.mainLayout.addWidget(self.saturationSlider)
            gammaLabel = QtGui.QLabel()
            gammaLabel.setText("Gamma:")
            self.mainLayout.addWidget(gammaLabel)

            """
            Since slide "translates the handle's position into an integer value"
              (see http://www.opendocs.net/pyqt/pyqt4/html/qslider.html#details)
              we need to convert ourselves integer to float.
            """
            self.gammaSlider = QtGui.QSlider()

            """
            Inspired from http://www.devshed.com/c/a/Python/PyQT-Getting-Started/3/:
            #slider1 = QtGui.QSlider(self,"slider1")
            #gammaSlider.setGeometry(QtCore.QRect(130,220,261,31))
            """
            self.gammaSlider.setOrientation(QtCore.Qt.Horizontal)

            #See http://www.opendocs.net/pyqt/pyqt4/html/qslider.html#tickInterval
            self.gammaSlider.setTickInterval(1.0 * 100)

            self.gammaSlider.setSingleStep(0.01 * 100)

            # See http://www.opendocs.net/pyqt/pyqt4/html/qslider.html
            self.gammaSlider.setTickPosition(QtGui.QSlider.TicksBelow)

            """
            See
              http://www.opendocs.net/pyqt/pyqt4/html/qabstractslider.html#setMinimum
            """
            self.gammaSlider.setMinimum(0)

            """
            See
              http://www.opendocs.net/pyqt/pyqt4/html/qabstractslider.html#setMaximum
            """
            self.gammaSlider.setMaximum(10 * 100)

            self.gammaSlider.setValue(Settings.myCfg.gamma[self.indexVideo] * \
                                                                            100)
            self.mainLayout.addWidget(self.gammaSlider)
            self.setLayout(self.mainLayout)
            self.setWindowTitle("View #%d" % (self.indexVideo + 1))
        except:
            common.DebugPrintErrorTrace()
