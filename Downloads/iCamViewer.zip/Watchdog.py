import codecs
import os
#import signal
import subprocess
import sys
import threading
import time
import traceback



LOCAL_FOLDER = "."

MY_DEBUG_STDOUT = True
MY_DEBUG_STDERR = True

STDERR_FILENAME_PREFIX = "stderr_Watchdog"
STDOUT_FILENAME_PREFIX = "stdout_Watchdog"

#VIEWER_PROGRAM_NAME = "VLC_PyQt.pyw"
#VIEWER_PROGRAM_NAME = "VLC_PySide.pyw"
VIEWER_PROGRAM_NAME = "iCamViewer.pyw"

stdoutFile = None
stderrFile = None
stdoutFileName = LOCAL_FOLDER + "/" + STDOUT_FILENAME_PREFIX + ".txt"
stderrFileName = LOCAL_FOLDER + "/" + STDERR_FILENAME_PREFIX + ".txt"
def CreateDirectoriesAndLogFiles():
    global stdoutFile, stderrFile

    try:
        if not os.path.exists(LOCAL_FOLDER):
            os.makedirs(LOCAL_FOLDER)

        if MY_DEBUG_STDOUT:
            stdoutFile = open(stdoutFileName, "a")
            sys.stdout = stdoutFile

        if MY_DEBUG_STDERR:
            stderrFile = open(stderrFileName, "a")
            sys.stderr = stderrFile
    except:
        if MY_DEBUG_STDERR:
            traceback.print_exc()
            sys.stderr.flush()

        if MY_DEBUG_STDOUT:
            sys.stdout.flush()


#os.spawnlpe(os.P_NOWAIT, "/bin/mycmd", "mycmd", "myarg", env)
def StartViewer():
    def Callable():
        try:
            #Python 2.7 required for OpenCV:
            #subprocess.call(["c:/python27/python", VIEWER_PROGRAM_NAME]) #, stdout = None, stderr = fOutput)

            try:
                FILENAME = sys.argv[1]
            except:
                FILENAME = "settings.pkl"
            subprocess.call(["c:/python27/python", VIEWER_PROGRAM_NAME, FILENAME]) #, stdout = None, stderr = fOutput)
        except:
            if MY_DEBUG_STDERR:
                traceback.print_exc()
                sys.stderr.flush()

    if MY_DEBUG_STDOUT:
        print "Entered StartViewer()."
        sys.stdout.flush()
    try:
        t = threading.Timer(0.1, Callable)
        t.start()
    except:
        if MY_DEBUG_STDERR:
            traceback.print_exc()
            sys.stderr.flush()


counterRestartsiCam = 0
#NUM_RESTARTS_ICAM_TO_RESTART_PHONE = 30
#MAX_TIME_BETWEEN_PETTINGS = 60 #120 #240 #30 #600 #2700 #seconds
MAX_TIME_BETWEEN_PETTINGS = 120 #60 #240 #30 #600 #2700 #seconds

#PETTING_FILENAME = "R:/iCamViewerAlive"
#from common import *
import common

lastTimePetted = time.time()
def CheckPetting():
    global lastTimePetted
    global counterRestartsiCam, NUM_RESTARTS_ICAM_TO_RESTART_PHONE
    global pid, viewerRunning

    try:
        if (os.path.isfile(common.PETTING_FILENAME)):
        #if (os.path.exists(PETTING_FILENAME)):
            lastTimePetted = time.time()

            """
            It can give
                "OSError: [Errno 13] Permission denied: 'D:/iCamAlive'"
              probably when the file is just created by the iCam process.
            """
            os.unlink(common.PETTING_FILENAME)

            if MY_DEBUG_STDOUT:
                print "CheckPetting(): File %s was found and erased by the " \
                    "watchdog." % PETTING_FILENAME
                sys.stdout.flush()
        else:
            if (time.time() - lastTimePetted > MAX_TIME_BETWEEN_PETTINGS):
                if MY_DEBUG_STDOUT:
                    print "CheckPetting(): iCam did not pet the watchdog " \
                        "well enough: file %s not available from %s until " \
                        "now. (counterRestartsiCam = %d.) Restarting " \
                        "application." % (common.PETTING_FILENAME, \
                            time.asctime(time.localtime(lastTimePetted)), \
                            counterRestartsiCam) #time.asctime(time.localtime())
                    #computer
                    sys.stdout.flush()

                lastTimePetted = time.time() #We "reset" lastTimePetted

                """
                if (counterRestartsiCam == NUM_RESTARTS_ICAM_TO_RESTART_PHONE):
                    #RestartPhone()
                    #!!!!Restart the OS!!!! :)
                    pass
                """

                #miso.kill_process(u"iCam_0xe21e55ef", 0)
                #miso.kill_process(u"iCam", 0)
                if MY_DEBUG_STDOUT:
                    print "CheckPetting(): Killing non-progressing process."
                    sys.stdout.flush()
                #miso.kill_process(u"iCam*", 0)

                """
                Seems it requires Python 2.7 for kill() and also signal
                  (see http://bugs.python.org/issue1220212:
                    "Prior to Python 2.7 and 3.2, you can use
                        linksomehow:`ctypes` to terminate a process::").
                """

                # It doesn't work to use signal.CTRL_C_EVENT, nor signal.CTRL_BREAK_EVENT, nor 1.
                #os.kill(pid, 10)

                """
                Since sometimes os.kill doesn't succeed in killing the process I use:
                  The /F flag (forcefully terminate) is mandatory to use to
                      really close the process.
                """
                subprocess.call(["taskkill", "/PID", "%d" % pid, "/T", "/F"])

                """
                From http://docs.python.org/library/os.html:
                  "Windows: The signal.CTRL_C_EVENT and signal.CTRL_BREAK_EVENT
                    signals are special signals which can only be sent to
                    console processes which share a common console window,
                    e.g., some subprocesses. Any other value for sig will
                    cause the process to be unconditionally killed by the
                    TerminateProcess API, and the exit code will be set to sig."
                """
                viewerRunning = False


                """
                if MY_DEBUG:
                    print "Calling Quit()."
                    sys.stdout.flush()

                # We restart the watchdog as well because we want to avoid
                #    to have ReV_Watchdog no longer progressing so we make
                #    it Quit() more often. (Not great)!!!!
                Quit()
                """
                #miso.kill_process(u"iCam*", 40)
                #e32.start_exe("E:\\sys\\bin\\iCam_0xe21e55ef.exe", "")
    except:
        if MY_DEBUG_STDERR:
            traceback.print_exc()
            sys.stderr.flush()
        #sys.stdout.flush()


viewerRunning = None
pid = None
def CheckiCamViewer():
    global pid, viewerRunning, counterRestartsiCam

    try:
        viewerRunning = False

        #print "Running WMIC..."
        #sys.stdout.flush()
        subprocess.call(["WMIC", "/OUTPUT:ProcessList.txt", "PROCESS", "get", \
                            "Caption,Commandline,Processid"])
        #print "Finished running WMIC."

        """
        In few cases "ProcessList.txt" can be a 2-byte (or maybe a bit
            more - less than 100 bytes, anyhow) long file, which is invalid
            and don't bother to use its info.
        """
        if (os.path.getsize("ProcessList.txt") > 100):
            fInput = codecs.open("ProcessList.txt", "r", "utf-16") #the encoding is "utf-16"
            for myLine in fInput:
                #print str(line)
                line = str(myLine)
            #for line in open("ProcessList.txt"):
                #print line,
                if (line.find("python " + VIEWER_PROGRAM_NAME) != -1):
                    #print line
                    #tokensLine = line.split(" ")
                    line = line.strip()
                    for i in range(len(line) - 1, 0, -1):
                        if (line[i] == " "):
                            pid = int(line[i : ])
                            break
                    """
                    tokensLine = line.split(" ")
                    pid = tokensLine[0]
                    """
                    if MY_DEBUG_STDOUT:
                        print "CheckiCamViewer(): At %s, pid = %d" % \
                                (time.asctime(time.localtime()), pid)
                        sys.stdout.flush()
                    #pid = int(tokensLine[2])
                    #print "pid = %d" % pid
                    viewerRunning = True
                    break
                #print line,

            if (not viewerRunning):
                if MY_DEBUG_STDOUT:
                    print "CheckiCamViewer(): iCam Viewer is not " \
                        "running --> (re)starting it."
                    sys.stdout.flush()

                StartViewer()
                counterRestartsiCam += 1
                return

        if pid != None:
            CheckPetting()

        """
        Since CheckPetting() can kill a non-progressing iCamViewer, we
            StartViewer() again, if it is the case.
        """
        if not viewerRunning:
            StartViewer()
            counterRestartsiCam += 1
    except:
        if MY_DEBUG_STDERR:
            traceback.print_exc()
            sys.stderr.flush()




if __name__ == "__main__":
    CreateDirectoriesAndLogFiles()

    if MY_DEBUG_STDOUT:
        print "\nStarted the watchdog."
        sys.stdout.flush()

    while True:
        CheckiCamViewer()
        time.sleep(10.0)

#print os.getpid()
#os.kill(pid = 56880, sig)


"""
#To work requires Python.org installation + pywin32 (or ActiveState Python) - otherwise doesn't find win32com.client, nor win32com (see http://bytes.com/topic/python/answers/595771-win32com-client).
#From http://mail.python.org/pipermail/python-win32/2003-December/001482.html
from win32com.client import GetObject
WMI = GetObject("winmgmts:")

#Here is how to get the process list:
processes = WMI.InstancesOf('Win32_Process')
#len(processes)
print processes
"""

"""
#For UNIX:
#From http://stackoverflow.com/questions/1091327/processlist
>>> import os
>>> data = [(int(p), c) for p, c in [x.rstrip('\n').split(' ', 1) \
...        for x in os.popen('ps h -eo pid:1,command')]]

OR

from subprocess import Popen, PIPE

process = Popen(['ps', '-eo' ,'pid,args'], stdout=PIPE, stderr=PIPE)
stdout, notused = process.communicate()
for line in stdout.splitlines():
    pid, cmdline = line.split(' ', 1)
    #Do whatever filtering and processing is needed

"""


"""
#DOESN'T WORK - CAN'T FIND win32pdh
#From http://code.activestate.com/recipes/303339-getting-process-information-on-windows/
import win32pdh, string, win32api

def procids():
    #each instance is a process, you can have multiple processes w/same name
    junk, instances = win32pdh.EnumObjectItems(None,None,'process', win32pdh.PERF_DETAIL_WIZARD)
    proc_ids=[]
    proc_dict={}
    for instance in instances:
        if instance in proc_dict:
            proc_dict[instance] = proc_dict[instance] + 1
        else:
            proc_dict[instance]=0
    for instance, max_instances in proc_dict.items():
        for inum in xrange(max_instances+1):
            hq = win32pdh.OpenQuery() # initializes the query handle 
            path = win32pdh.MakeCounterPath( (None,'process',instance, None, inum,'ID Process') )
            counter_handle=win32pdh.AddCounter(hq, path) 
            win32pdh.CollectQueryData(hq) #collects data for the counter 
            type, val = win32pdh.GetFormattedCounterValue(counter_handle, win32pdh.PDH_FMT_LONG)
            proc_ids.append((instance,str(val)))
            win32pdh.CloseQuery(hq) 

    proc_ids.sort()
    return proc_ids


print procids()
"""
