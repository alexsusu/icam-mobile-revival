import common
import Google
import os
import Settings
import Slideshow
import time
import thread
import threading

"""
DO_ANALYSIS = True
if DO_ANALYSIS:
    import VideoAnalysis
    import AudioAnalysis
"""
import Analyze
import VideoAnalysis
import AudioAnalysis



#!!!!TODO: think well if inheritance is necessary
class BatchMode(Slideshow.SlideshowMC):
    #!!!!TODO: move BatchMode() out from class Slideshow
    def DoIt(self,
                filterVideosAfterDeviceIdAndCameraId=True,
                doVideoAnalysis=False,
                doAudioAnalysis=False,
                deleteSearchKeywordRE=None,
                deleteSearchDeviceId=None,
                aStartIndex=1):

        # global mediaFileURLList

        # r"2011_12_(10|11)")
        deleteSearchKeywordRECompiled = re.compile(deleteSearchKeywordRE)

        try:
            """
            myText2 = "Video %s seems to be without audio and without " \
                        "motion (VideoAnalysis.motionFactorPerFrame = %.2f, " \
                        "AudioAnalysis.soundPercentage = %.1f)." % \
                        ("http://www.youtube.com/watch?v=jxLPU46Cimo", 0.0, 0.0)

            reply = QtGui.QMessageBox().question(self, "Delete video",
                    myText2 + " Are you sure you want to delete the video?",
                    QtGui.QMessageBox.Yes | QtGui.QMessageBox.No,
                    QtGui.QMessageBox.No)

            if reply == QtGui.QMessageBox.Yes:
                Google.youtubeClient.DeleteVideoEntry(ytVideoEntryAux)

                common.DebugPrint("Deleted video %s." % ytVideoURL)
            """
            common.DebugPrint("Entered BatchMode(" \
                    "filterVideosAfterDeviceIdAndCameraId=%d, " \
                    "doVideoAnalysis=%d, doAudioAnalysis=%d, " \
                    "deleteSearchKeywordRE=%s, deleteSearchDeviceId=%s, " \
                    "aStartIndex=%d): myCfg.deviceId[self.indexVideo]=%s, " \
                    "myCfg.cameraId[self.indexVideo]=%d." % \
                    (filterVideosAfterDeviceIdAndCameraId,
                        doVideoAnalysis,
                        doAudioAnalysis,
                        str(deleteSearchKeywordRE),
                        str(deleteSearchDeviceId),
                        aStartIndex,
                        Settings.myCfg.deviceId[self.indexVideo],
                        Settings.myCfg.cameraId[self.indexVideo]
                    ))

            if Settings.myCfg.mediaServer[self.indexVideo] == 0:
                # YouTube

                # Iterate over all YouTube video feeds.

                if aStartIndex is None:
                    # self.startIndex = 19800 #580 + 1500 #580 #1
                    self.startIndex = 950
                else:
                    self.startIndex = 1

                self.mediaFileURLList = []
                # ytCompleteResultEntryList = []
                ytVideoEntryListAux = []

                self.DownloadYouTubeVideoFeedPages(howManyVideoFeedPagesToGet=2)
                # 100) #2 #5 #90) #1)
                # #30) #100 #400 #5
                """
                common.DebugPrint("BatchMode(): " \
                                    "self.results = %s " % str(self.results) + \
                                "BatchMode(): " \
                                    "self.results.entry = %s" % \
                                    str(self.results.entry))
                """


                if common.MY_DEBUG_STDOUT:
                    print "BatchMode(): Bla"
                    sys.stdout.flush()

                # SearchYouTubeVideosInGeneral("2011_06_05_10_") return

                if deleteSearchKeywordRE is None:
                    DELETE_VIDEOS_AFTER_CRITERIA = False
                else:
                    DELETE_VIDEOS_AFTER_CRITERIA = True

                if common.MY_DEBUG_STDOUT:
                    print "BatchMode(): " \
                        "DELETE_VIDEOS_AFTER_CRITERIA =", \
                        DELETE_VIDEOS_AFTER_CRITERIA
                    sys.stdout.flush()

                #DELETE_VIDEOS_AFTER_CRITERIA = False #True
                #GetVideoInfoFromGDataEntry(self.results.entry[0])
                if DELETE_VIDEOS_AFTER_CRITERIA:
                    for ytVideo in self.results.entry:
                        # """ devTags = ytVideo.GetDeveloperTags()
                        """
                        common.DebugPrint(
                            "BatchMode(): " \
                                "ytVideo.category = %s" \
                                % (str(ytVideo.category[1])))
                        """

                        common.DebugPrint(
                            "BatchMode(): " \
                                "ytVideo.category = %s. Video title = %s." % \
                                (str(ytVideo.category[2].term),
                                    ytVideo.title.text))

                        """
                        common.DebugPrint(
                            "BatchMode(): " \
                                "Video title = %s. dev = %s, %s" % \
                            (ytVideo.title.text, devTags[0], devTags[2]))
                        """
                        # """

                        """
                        # Plain search, without regexp
                        if ytVideo.title.text.find(deleteSearchKeywordRE) != -1:
                        if (ytVideo.category[2].term.find(
                                deleteSearchDeviceId) != -1) and
                            deleteSearchKeywordRECompiled.search(
                                ytVideo.title.text):

                        # Plain search, without regexp 
                        if ytVideo.title.text.find(deleteSearchKeywordRE) != -1:
                        if (ytVideo.category[2].term.find(
                                deleteSearchDeviceId) != -1) and
                            deleteSearchKeywordRECompiled.search(
                                ytVideo.title.text):
                        """

                        if (ytVideo.category[2].term == \
                                    deleteSearchDeviceId) and \
                                    deleteSearchKeywordRECompiled.search(
                                                ytVideo.title.text):
                            common.DebugPrint(
                                "BatchMode(): " \
                                    "Video candidate for deletion: "\
                                    "title %s." % ytVideo.title.text)

                            if False:
                                try:
                                    videoIdXMLStr = str(ytVideo.id)
                                    videoIdStrAux = \
                                        ytVideo.id.text.split("/")[-1]

                                    ytVideoEntryAux = \
                                        Google.youtubeClient.GetYouTubeVideoEntry(
                                        "http://gdata.youtube.com/feeds/api/" \
                                        "users/default/uploads/" +
                                        videoIdStrAux)

                                    ytVideoURL = \
                                        "http://www.youtube.com/watch?v=%s" % \
                                        videoIdStrAux

                                    reply = QtGui.QMessageBox().question(
                                        self, "Delete video",
                                        "Are you sure you want to delete the "
                                        "video %s (title %s)?" % (ytVideoURL,
                                        ytVideo.title.text),
                                        QtGui.QMessageBox.Yes | \
                                        QtGui.QMessageBox.No,
                                        QtGui.QMessageBox.No)

                                    if reply == QtGui.QMessageBox.Yes:
                                        # Google.youtubeClient.DeleteVideoEntry
                                        # (ytVideoEntryAux)
                                        """
                                        I can receive "too many recent calls"
                                            here also.
                                        ("RequestError:
                                            {'status': 403,
                                            'body': "<?xml version='1.0' " \
                                                "encoding='UTF-8'?><errors>" \
                                                "<error><domain>yt:quota</domain>" \
                                                "<code>too_many_recent_calls</code>" \
                                                "</error></errors>",
                                            'reason': 'Forbidden'}")
                                        """
                                        Google.youtubeClient.DeleteVideoEntry(
                                                            ytVideoEntryAux)

                                        common.DebugPrint(
                                            "BatchMode(): Deleted video %s " \
                                            "with title %s (time = %s)." % \
                                            (ytVideoURL,
                                            ytVideo.title.text,
                                            common.GetCurrentDateTimeStringWithMillisecondsNice()))
                                    else:
                                        common.DebugPrint( \
                                            "    Not deleting this video.")
                                except:
                                    common.DebugPrintErrorTrace()
                    return

                """
                t = threading.Timer(0.001, self.exec_)
                t.start()
                """
                #if True:
                for ytVideo in self.results.entry:
                    try:
                        common.DebugPrint("\n")

                        videoIdXMLStr = str(ytVideo.id)
                        videoIdStrAux = ytVideo.id.text.split("/")[-1]

                        ytVideoEntryAux = \
                            Google.youtubeClient.GetYouTubeVideoEntry(
                                "http://gdata.youtube.com/feeds/api/" \
                                "users/default/uploads/" + videoIdStrAux)

                        ytVideoURL = \
                            "http://www.youtube.com/watch?v=%s" % videoIdStrAux

                        if int(ytVideoEntryAux.media.duration.seconds) == 0:
                            common.DebugPrint( \
                                "BatchMode(): " \
                                "int(ytVideoEntryAux.media.duration.seconds) == 0 " \
                                "which means the video is still being " \
                                "processed by YouTube (in YouTube " \
                                "next to the video it says " \
                                "'Uploaded (processing, please wait)') " \
                                "--> skipping this video.\n\n")
                            continue

                        """
                        Filter out the videos that are not for the
                          desired deviceId and cameraId - this is the
                          reason why we have to call
                          Google.youtubeClient.GetYouTubeVideoEntry() - to
                          retrieve deviceId and cameraId.
                        """
                        if filterVideosAfterDeviceIdAndCameraId:
                            deviceId = Settings.myCfg.deviceId[
                                                    self.indexVideo]
                            # We look for the video with the right deviceId
                            if ytVideoEntryAux.media.keywords.text != deviceId:
                                common.DebugPrint(
                                    "BatchMode(): "\
                                    "deviceId = %s while ytVideoEntryAux.media.keywords.text " \
                                    "= %s --> skipping this video." % (deviceId,
                                        ytVideoEntryAux.media.keywords.text))
                                continue

                            cameraId = Settings.myCfg.cameraId[
                                            self.indexVideo]

                            try:
                                crtCameraId = \
                                    int(ytVideoEntryAux.media.title.text[
                                        len(ytVideoEntryAux.media.title.text)
                                                    - 1 : ])
                            except:
                                crtCameraId = -1
                                common.DebugPrintErrorTrace()

                            # We look for the video for the current cameraId
                            if crtCameraId != cameraId:
                                common.DebugPrint(
                                    "BatchMode(): " \
                                    "crtCameraId = %d while " \
                                    "cameraId = %d --> skipping this video." % \
                                    (crtCameraId, cameraId))
                                continue

                        """
                        ytVideoEntryListAux.append(ytVideoEntryAux)
                        self.mediaFileURLList.append(ytVideo)
                        """
                        ytVideoEntryListAux.insert(0, ytVideoEntryAux)
                        self.mediaFileURLList.insert(0, ytVideo)

                        common.DebugPrint(
                            "BatchMode(): " \
                            "found a good video (title = %s; " \
                            "description = %s; ytVideoURL = %s) - " \
                            "len(self.mediaFileURLList) = %d." % \
                            (ytVideoEntryAux.media.title.text,
                                ytVideoEntryAux.media.description.text,
                                ytVideoURL,
                                len(self.mediaFileURLList)))

                        """
                        common.DebugPrint(
                            "BatchMode(): found " \
                            "a good video (title = %s; " \
                            "description = %s) - " \
                            "len(self.mediaFileURLList) = %d.\n" % \
                            (ytVideoEntryAux.media.title.text,
                                ytVideoEntryAux.media.description.text,
                                len(self.mediaFileURLList)))
                        """

                        Analyze.AnalyzeMedia( \
                            Settings.myCfg.mediaServer[self.indexVideo],
                            ytVideoEntryAux, None,
                            dontPerformAnalysisJustReadPreviousAnalysisResultsIfExist=True)

                        # If I call it I will not get back to this function
                        #self.PlayNextVideoInSlideshow() 
                        if (VideoAnalysis.motionFactorPerFrame < 0.0) and \
                            (AudioAnalysis.soundPercentage < 0.0):
                            """
                            The video description doesn't contain
                                analysis info. So we need to download the
                                video and analyze it now.
                            """
                            pathFileName = None

                            # while True:
                            for retryCounter in \
                                range(common.NUM_RETRIES_DOWNLOAD_VIDEO + 1):
                                (pathFileName, videoLength) = \
                                    DownloadYouTubeVideo(
                                        ytVideoEntryAux, videoIdStrAux)

                                """
                                (pathFileName, descriptionStr,
                                    videoLength) =
                                          DownloadYouTubeVideo(self.indexVideo)
                                """

                                if (pathFileName == "") and \
                                    (videoLength == -1):
                                    """
                                    We got an exception at
                                            DownloadYouTubeVideo().
                                      We have the following possibilities:
                                      - We might receive
                                        "DownloadError: ERROR: YouTube
                                          said: This video is unavailable."
                                            - see Z:\1PhD\ReVival\Logs\iCamViewer\HP_DV5_1017nr\Video_unavailable\stderr_2011_04_18_22_51_02.txt.
                                      - Z:\1PhD\ReVival\Logs\iCamViewer\HP_DV5_1017nr\InsteadOfRedirectRecoveryOptions\login_redirect.html
                                          "Google accounts" management:
                                            "Don't wait until it's too late"
                                            - asking to give recovery options
                                    """

                                    """
                                    In case the video was rejected by
                                        YouTube as 
                                        "Rejected (duplicate upload)",
                                        youtube-dl will give
                                        "ERROR: unable to download video
                                            webpage:
                                            HTTP Error 404: Not Found"
                                    """
                                    time.sleep(10)
                                else:
                                    break

                            Analyze.AnalyzeMedia(Settings.myCfg.mediaServer[self.indexVideo],
                                    ytVideoEntryAux, pathFileName,
                                    dontPerformAnalysisJustReadPreviousAnalysisResultsIfExist=False)

                        if (VideoAnalysis.motionFactorPerFrame < 0.001) and \
                            (VideoAnalysis.motionFactorPerFrame >= 0.0) and \
                            (AudioAnalysis.soundPercentage < 0.001) and \
                            (AudioAnalysis.soundPercentage >= 0.0):
                            myText2 = \
                                "Video %s seems to be without " \
                                "audio and without motion " \
                                "(VideoAnalysis.motionFactorPerFra" \
                                "me = %.2f, AudioAnalysis.soundPer" \
                                "centage = %.1f)." % (ytVideoURL,
                                    VideoAnalysis.motionFactorPerFrame,
                                    AudioAnalysis.soundPercentage)

                            myText = \
                                "BatchMode(): " + myText2 + \
                                " --> we proceed to delete it " \
                                "from YouTube."

                            common.DebugPrint(myText)

                            """
                            QtGui.QMessageBox.information(self,
                                    "Image Viewer",
                                    "Cannot load %s." % fileName)
                            """
                            """
                            msgBox = QtGui.QMessageBox()
                            msgBox.setText(myText)
                            msgBox.exec_()
                            """

                            # From http://zetcode.com/tutorials/pyqt4/firstprograms/
                            reply = \
                                QtGui.QMessageBox().question(self,
                                    "Delete video", myText2 +
                                    " Would you like to delete the video?",
                                    QtGui.QMessageBox.Yes |
                                    QtGui.QMessageBox.No,
                                    QtGui.QMessageBox.No)

                            if reply == QtGui.QMessageBox.Yes:
                                Google.youtubeClient.DeleteVideoEntry( \
                                                            ytVideoEntryAux)
                                common.DebugPrint(
                                    "Deleted video %s." % ytVideoURL)

                        if False:
                            # break
                            if len(self.mediaFileURLList) == 2: # == 20
                                break

                            """
                            myCfgVideoAnalysisOrig = Settings.myCfg.videoAnalysis
                            myCfgAudioAnalysisOrig = Settings.myCfg.audioAnalysis
                            Settings.myCfg.videoAnalysis = doVideoAnalysis
                            Settings.myCfg.audioAnalysis = doAudioAnalysis
                            self.PlayNextVideoInSlideshow()
                            Settings.myCfg.videoAnalysis = myCfgVideoAnalysisOrig
                            Settings.myCfg.audioAnalysis = myCfgAudioAnalysisOrig
                            """
                    except:
                        common.DebugPrintErrorTrace()
                """
                # From http://docs.python.org/tutorial/controlflow.html:
                #  "Loop statements may have an else clause;
                #   it is executed when the loop terminates through
                #   exhaustion of the list (with for) or when the condition
                #   becomes false (with while), but not when the loop is
                #   terminated by a break statement."
                else:
                    continue
                    common.DebugPrint(
                        "BatchMode(): took else branch of for.")
                break
                """
                common.DebugPrint( \
                    "BatchMode(): " \
                    "self.mediaFileURLList = %s" % str(self.mediaFileURLList))
            elif Settings.myCfg.mediaServer[self.indexVideo] == 1:
                # Picasa
                pass
            elif Settings.myCfg.mediaServer[self.indexVideo] == 2:
                # iCam Server
                """
                # Choose depending on self.indexVideo:
                mediaFileListPathFileName = Settings.myCfg.deviceId[
                        self.indexVideo] + "/MediaFileList.js"
                """
                #!!!!TODO: mediaFileListPathFileName is NOT defined!!!!
                if not os.path.isfile(mediaFileListPathFileName):
                    """
                    assert common.DownloadFile(
                        "http://alexsusu.110mb.com/iCam/" \
                        "668066806680668/MediaFileList.js",
                        mediaFileListPathFileName) == 0
                    """
                    assert common.DownloadFile("http://" + \
                        Settings.myCfg.iCamServerAddress + \
                        Settings.WEB_FOLDER + "/" + \
                        Settings.myCfg.deviceId[self.indexVideo] + \
                                 "/MediaFileList.js",
                                 mediaFileListPathFileName) == 0
                """
                #assert common.DownloadFile("http://alexsusu.110mb.com/iCam/" +
                #       mediaFileListPathFileName,
                #       mediaFileListPathFileName) == 0

                ####assert common.DownloadFile("http://" + \
                ####            Settings.myCfg.iCamServerAddress + \
                ####            Settings.WEB_FOLDER + \
                ####            "/" + mediaFileListPathFileName,
                ####            mediaFileListPathFileName) == 0
                # Check if returns False

                self.ReadMediaFileList(mediaFileListPathFileName,
                                    Settings.myCfg.cameraId[self.indexVideo])

                # Without - 1, since it gets subtracted in
                #    PlayNextVideoInSlideshow()
                self.indexMediaFileURLList = len(self.mediaFileURLList)

                common.DebugPrint(
                    "BatchMode(): after ReadMediaFileList(), " \
                        "self.indexMediaFileURLList = %d." % \
                        self.indexMediaFileURLList)
                """
                pass

            """
            myCfgVideoAnalysisOrig = Settings.myCfg.videoAnalysis
            myCfgAudioAnalysisOrig = Settings.myCfg.audioAnalysis
            Settings.myCfg.videoAnalysis = doVideoAnalysis
            Settings.myCfg.audioAnalysis = doAudioAnalysis
            self.PlayNextVideoInSlideshow()
            Settings.myCfg.videoAnalysis = myCfgVideoAnalysisOrig
            Settings.myCfg.audioAnalysis = myCfgAudioAnalysisOrig
            """
        except:
            common.DebugPrintErrorTrace()
