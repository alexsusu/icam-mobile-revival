import sys
import os
import subprocess
#import shutil
import traceback
#import urllib

import common

"""
From http://digitalcardboard.com/blog/2009/08/25/the-sox-of-silence/:
    sox in.wav out4.wav silence 1 0.1 1% -1 0.1 1% #Example 4. Trimming all silence
    sox in.wav out3.wav silence 1 0.3 1% 1 0.3 1%

#Inspired from http://www.justlinux.com/forum/showthread.php?t=136678
    sox Darioli.wav -n stat #stats file
    To amplify (-9db here):
        sox filename -v 0.125 filename
    To reverse:
        sox filename filename reverse

#From http://osdir.com/ml/audio.sox/2005-04/msg00015.html
    sox with_silence.wav temp.wav silence 1 0:0:0.01 -55d reverse
      #trim silence from the beginning of the temp file and reverse the wav into the new file
    sox temp.wav without_silence.wav silence 1 0:0:0.01 -55d reverse

    You may wish to experiment with the "non-silence" length and the
        threshold that it uses to consider something silence.
    My guess is those values are good enough for you.
"""

soundPercentage = -1.0
amplitudeMean = 0.0
amplitudeMax = 0.0
amplitudeMin = 0.0
amplitudeRMS = 0.0
frequencyRough = 0.0
def AnalyzeMovieAudio(moviePathFileName, audioLength=30.0, \
                        lookIfReportFileIsAlreadyPresent=True):
    global soundPercentage
    global amplitudeMean, amplitudeRMS, frequencyRough, amplitudeMax, amplitudeMin

    soundPercentage = -1.0

    STRINGS_TO_SEARCH = [ \
                            "Length (seconds)",  \
                            "Mean    amplitude", \
                            "Maximum amplitude", \
                            "Minimum amplitude", \
                            "RMS     amplitude", \
                            "Rough   frequency"  \
                        ]
    myStats = {}

    if common.MY_DEBUG_STDOUT:
        print "AnalyzeMovieAudio(moviePathFileName=%s, audioLength=%.2f): " \
            "Extracting audio from movie." % (moviePathFileName, \
                                                float(audioLength))
        sys.stdout.flush()

    try:
        """
        "c:\program files\videolan\vlc\vlc.exe" 2010_06_22_16_05_29_1.3gp vlc://quit --sout=#transcode{acodec=s16l}:standard{access=file,mux=wav,dst="recaudio.wav",select="novideo"}
        Z:\1PhD\ReVival\1ComputerVision\SOX\sox-14.3.1\sox.exe recaudio.wav rec_without_silence.wav silence 1 0.1 1% -1 0.1 1%
        Z:\1PhD\ReVival\1ComputerVision\SOX\sox-14.3.1\sox.exe rec_without_silence.wav -n stat
        """

        reportPathFileName = moviePathFileName + ".rep"
        if (lookIfReportFileIsAlreadyPresent == False) or \
                    ((lookIfReportFileIsAlreadyPresent == True) and \
                    (not os.path.isfile(reportPathFileName))):
            """
            subprocess.call(["C:/Program Files/VideoLAN/VLC/vlc.exe", \
                moviePathFileName, "--intf=dummy", \
                "--dummy-quiet", "vlc://quit", \
                '--sout=#transcode{acodec=s16l}:standard{access=file,mux=wav,dst="recaudio.wav",select="novideo"}'])
            """
            subprocess.call([common.VLC_EXECUTABLE_PATH_FILENAME, \
                moviePathFileName, "--intf=dummy", "--dummy-quiet", \
                "vlc://quit", \
                '--sout=#transcode{acodec=s16l}:standard{access=file,mux=wav,dst="recaudio.wav",select="novideo"}'])
            
            """
            # It seems if there are too many files in the current directory
            #   (at least for .3gp files) it is possible that VLC returns the
            #   .wav file later - so we wait a few seconds.
            time.sleep(3.0)
            """

            """
            From http://digitalcardboard.com/blog/2009/08/25/the-sox-of-silence/
            silence [-l] above-periods [duration threshold [d|%] [below-periods duration threshold [d|%] ]
            """
            #I used Y9G9yZqOhdQ.flv as input file.
            #subprocess.call([SOX_EXECUTABLE_PATH_FILENAME, "recaudio.wav", "rec_without_silence.wav", "silence", "1", "0.1", "1%", "-1", "0.1", "1%"])
            #subprocess.call([SOX_EXECUTABLE_PATH_FILENAME, "recaudio.wav", "rec_without_silence.wav", "silence", "0.1", "0.05", "0.5%", "-1", "0.1", "1%"]) #It gives warning: "FAIL silence: silence threshold should be between 0.0 and 100.0 %"

            #subprocess.call([SOX_EXECUTABLE_PATH_FILENAME, "recaudio.wav", "rec_without_silence.wav", "silence", "1", "0.1", "1%", "-1", "0.1", "0.5%"]) #1.19 secs of useful sound
            #subprocess.call([SOX_EXECUTABLE_PATH_FILENAME, "recaudio.wav", "rec_without_silence.wav", "silence", "1", "0.05", "0.5%", "-1", "0.1", "0.5%"]) #4.05 secs of useful sound

            #Used for a lot of weeks - quite sensitive (but very light sounds are not detected): subprocess.call([SOX_EXECUTABLE_PATH_FILENAME, "recaudio.wav", "rec_without_silence.wav", "silence", "1", "0.05", "0.1%", "-1", "0.1", "0.1%"]) #13.58 secs of useful sound

            #Very light sounds are Detected: 
            #subprocess.call([SOX_EXECUTABLE_PATH_FILENAME, "recaudio.wav", "rec_without_silence.wav", "silence", "1", "0.005", "0.01%", "-1", "0.1", "0.1%"])
            subprocess.call([common.SOX_EXECUTABLE_PATH_FILENAME, \
                "recaudio.wav", "rec_without_silence.wav", "silence", "1", \
                "0.005", "0.01%", "-1", "0.1", "0.1%"])

            """
            From http://docs.python.org/library/subprocess.html - parameters
                are the same as for popen().
            """
            fOutput = open(reportPathFileName, "w")
            subprocess.call([common.SOX_EXECUTABLE_PATH_FILENAME, \
                "rec_without_silence.wav", "-n", "stat"], \
                stdout=None, stderr=fOutput) #, '2>bbbbla' 
            fOutput.close()

        audioLengthWithoutNoise = 0.0

        #fInput  = open(moviePathFileName + ".rep", "r")
        #fInput.close()
        if common.MY_DEBUG_STDOUT:
            print "AnalyzeMovieAudio(): SoX finished %s:" % moviePathFileName
            sys.stdout.flush()

        for line in open(reportPathFileName):
            for strToSearch in STRINGS_TO_SEARCH:
                if (line.startswith(strToSearch + ":")):
                    #audioLengthWithoutNoise = float(line[len(strToSearch) : ])
                    #myStats[strToSearch[: len(strToSearch)]] = float(line[len(strToSearch) + 1 : ])
                    myStats[strToSearch] = float(line[len(strToSearch) + 1 : ])
                    if (strToSearch == STRINGS_TO_SEARCH[0]) and \
                                (myStats[STRINGS_TO_SEARCH[0]] < 0.001):
                        """
                        This video has no (useful) sound in it, so the other statistics are 0.0 or -1.#IND00. 
                        We want to avoid conerting -1.#IND00, so we make all other stats 0.
                        """
                        if common.MY_DEBUG_STDOUT:
                            print "AnalyzeMovieAudio(): This video has no " \
                                "(useful) sound in it, so we make the other " \
                                "statistics 0.0."
                            sys.stdout.flush()

                        for i in range(1, len(STRINGS_TO_SEARCH)):
                            myStats[STRINGS_TO_SEARCH[i]] = 0.0

                        break
            else:
                """
                The else for the FOR loop is inspired from
                    http://stackoverflow.com/questions/653509/breaking-out-of-nested-loops
                """
                # Executed if the break in the FOR loop above was not used.
                continue

            # Executed only if the break above was used.
            break
                    
            if common.MY_DEBUG_STDOUT:
                print line,
                sys.stdout.flush()

            """
            if (line.find(".push(") != -1) and (line.find(".3gp") != -1) and \
                    (line.find("Array%d" % cameraId) != -1) and \
                    (line.find(" = new Array();") == -1) and \
                    (line.find("( bytes)") == -1):
                #print line
                tokensLine = line.split("', ")
                index = tokensLine[0].find("http://")
            """
        audioLengthWithoutNoise = myStats["Length (seconds)"]
        soundPercentage = audioLengthWithoutNoise / audioLength
        amplitudeMean = myStats["Mean    amplitude"]
        amplitudeMax  = myStats["Maximum amplitude"]
        amplitudeMin  = myStats["Minimum amplitude"]
        amplitudeRMS = myStats["RMS     amplitude"]
        frequencyRough = myStats["Rough   frequency"]

        if common.MY_DEBUG_STDOUT:
            print "myStats =", myStats
            print "audioLengthWithoutNoise = %.2f" % audioLengthWithoutNoise
            print "SP (sound/non-silence percentage from total) = %.0f%%" % \
                                                    (soundPercentage * 100.0)
            #print "A[M;RMS] = %.2f;%.2f" % (amplitudeMean, amplitudeRMS)
            #print "A[M;RMS] = %.2e;%.2e" % (amplitudeMean, amplitudeRMS)
            print "A[max;min;M;RMS]=%.6f;%.6f;%.6f;%.6f" % (amplitudeMax, \
                                    amplitudeMin, amplitudeMean, amplitudeRMS)
            print "F[M] = %.0f" % (frequencyRough)
            sys.stdout.flush()
        #Example file:
        """
        Samples read:                 0
        Length (seconds):      0.000000
        Scaled by:         2147483647.0
        Maximum amplitude:     0.000000
        Minimum amplitude:     0.000000
        Midline amplitude:     0.000000
        Mean    norm:         -1.#IND00
        Mean    amplitude:    -1.#IND00
        RMS     amplitude:    -1.#IND00
        Maximum delta:         0.000000
        Minimum delta:         0.000000
        Mean    delta:        -0.000000
        RMS     delta:        -0.000000
        Rough   frequency:  -2147483648

        Probably text, not sound
        """
    except:
        if common.MY_DEBUG_STDERR:
            traceback.print_exc()
            sys.stderr.flush()
        

if __name__ == "__main__":
    #AnalizeMovie("2011_01_17_14_40_17_000_0.3gp")
    #AnalyzeMovieAudio("2011_01_17_14_41_03_000_1.3gp")
    #AnalyzeMovieAudio("temp.3gp")
    AnalyzeMovieAudio("jxLPU46Cimo.flv")
