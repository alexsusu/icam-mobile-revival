iCamViewer.zip contains the important files required to run iCam Viewer.
Unzip it in any directory you want.

iCamViewer dependencies:
    - requires only PySide and Python 2.7 (preferably) if running locally (using a video available on a local disk)
    - gdata, youtube_dl modules
        - not required if using local videos; can ~easily be adapted to run without them in iCam server mode;
        - but required if using YouTube as server;
    - SoX and OpenCV applications only if enabled.

Tu use YouTube as a server go in common.py and make:
    DO_IMPORT_GDATA = True .

To work, the iCam Viewer requires:
    - Python2.7 (you can get it from http://www.python.org/download/releases/2.7/). 
      Note: We require Python2.7 because OpenCV relies on it to run its bindings.
        If you don't plan using OpenCV then you can use also Python 2.5, 2.6, etc.

    - the latest VLC player: http://www.videolan.org/vlc/

    - PySide (Python bindings for Qt):
        download the latest version from
            http://developer.qt.nokia.com/wiki/PySideDownloads/ and install it.

    - for YouTube and Picasa support:
        - the mechanize Python package: you can find version 0.2.5 in the kit;
            you can get the latest version from https://github.com/jjlee/mechanize-build-tools
            (or https://github.com/jjlee/mechanize/downloadshttps://github.com/jjlee/mechanize/downloads).
            To install mechanize extract the ZIP and use the standard installation command:
                python setup.py install (make sure you run Python 2.7)

        - gdata-python-client: you can find version 2.0.14 in the kit;
            you can get the latest version from https://code.google.com/p/gdata-python-client/downloads/list.
            To install mechanize extract the ZIP and use the standard installation command:
                python setup.py install (make sure you run Python 2.7)

    - if you want to perform Video analysis:
        - OpenCV - download the latest version from http://opencv.willowgarage.com/wiki/ (see Download section)
            - after installing the OpenCV package you need to install the Python bindings:
                - for example, on Windows after installing OpenCV-2.4.6
                  copy  C:\opencv\build\python\2.7\cv2.pyd (or 2.6)
                        and
                        C:\opencv\modules\python\src2\cv.py
                    to the C:\Python27\Lib\site-packages\ folder
                        (if you install for different Python change accordingly).

        - for best performance when doing video analysis we recommend installing a RAM disk driver
            - on Windows we use http://www.mydigitallife.info/free-ramdisk-for-windows-vista-xp-2000-and-2003-server/
                and we install it as drive R:.

    - for Sound analysis we use SoX:
        you can get the latest version from http://sox.sourceforge.net/ and
            unarchive in the already created sox folder. 

Note: you can download the latest vlc.py from http://wiki.videolan.org/Python_bindings#Download - note that at least once it had some bugs... :), so better use the one that is shipped with this distribution.

iCamViewer was used with success on Windows.
Minimal adjustments are required to make it run on Linux, MacOS, etc.

To run iCamViewer give:
    python iCamViewer.pyw (make sure you run Python 2.7 - as discussed above,
    we require Python2.7 because OpenCV relies on it to run its bindings.)
First time you run iCamViewer a "Settings iCam Viewer" dialog will appear.
    You should specify the servers you use and the logins.

If the iCamViewer is crashing from time to time you can use the watchdog that
    will make sure to restart the iCamViewer when necessary.
Run Viewer_Watchdog.bat, for example.
