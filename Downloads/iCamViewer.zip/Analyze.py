import os
import subprocess
import sys
import time
import traceback

import common
import Google
import PhoneNumbers
import Settings
import Slideshow
import State
import UI

import VideoAnalysis
import AudioAnalysis

if common.DO_IMPORT_GDATA:
    import gdata.media
    import gdata.youtube
    #import gdata.youtube.service



UPDATE_YOUTUBE_ENTRY = True  # False

STATE_FILENAME = "state.bin"


def Monitor(deviceId):
    #!!!!TODO: if Settings.myCfg.monitor == False...
    return

    try:
        statePathFileName = deviceId + "/" + STATE_FILENAME
        """
        assert common.DownloadFile("http://alexsusu.110mb.com/iCam/" +
                    Settings.myCfg.deviceId[UI.indexVideo] + "/" + STATE_FILENAME,
                    statePathFileName) == 0
        """
        stateFileURL = "http://" + Settings.myCfg.iCamServerAddress + \
                    Settings.WEB_FOLDER + "/" + deviceId + "/" + STATE_FILENAME

        if common.DownloadFile(stateFileURL, statePathFileName) == 0:
            State.LoadStateFromFile(statePathFileName)
            """
            if deviceId == "668066806680668":
                common.DebugPrint(
                    "AnalyzeMedia():Monitor(): stateFileURL = %s, " \
                            "time = %s, fileNameStr = %s." % (stateFileURL,
                            str(tm_year, tm_mon, tm_mday, tm_hour,
                                tm_min, tm_sec, numMilliseconds), fileNameStr))
            """
            # if deviceId == "668066806680668":
            if deviceId in PhoneNumbers.phoneInfo:
                stateTime = State.GetStateTime()

                """
                See http://docs.python.org/library/time.html, at
                    "Use the following functions to convert between time
                    representations:"
                """
                deltaTime = time.mktime(time.localtime()) - \
                                        time.mktime(stateTime)

                common.DebugPrint(
                    "AnalyzeMedia():Monitor(): deltaTime = %d." % deltaTime)

                if False: # >30):
                    if deltaTime > 3600: # >30):
                        myText = "Phone deviceId = %s seems not to be active "\
                                    "(deltaTime = %d) --> calling %s " \
                                    "to restart." % (deviceId, deltaTime, \
                                    PhoneNumbers.phoneInfo[deviceId])

                        common.DebugPrint("AnalyzeMedia():Monitor(): " + myText)

                        UI.Alarm(myText)

                        """
                        One option of alarm triggering - Make phone call
                            with Skype:
                           "C:\Program Files\Skype\Phone\Skype.exe"
                                /callto:+40772103340 #+01234567890 #/nosplash
                         doesn't work
                        """
                        subprocess.call([
                            "C:\\Program Files\\Skype\\Phone\\Skype.exe",
                            "/callto:" + PhoneNumbers.phoneInfo[deviceId]])

            if State.chargerStatus == 0:
                UI.Alarm("For deviceId %s, chargerStatus is %d." % \
                                        (deviceId, State.chargerStatus))

            common.DebugPrint("AnalyzeMedia():Monitor(): stateFileURL = %s, " \
                    "chargerStatus = %d." % (stateFileURL, State.chargerStatus))
    except:
        if common.MY_DEBUG_STDERR:
            traceback.print_exc()
            sys.stderr.flush()



# justReadPreviousAnalysisResultsIfExist = dontPerformAnalysisJustReadPreviousAnalysisResultsIfExist
def AnalyzeMedia(mediaServer, ytVideoEntry, aMediaPathFileName,
                justReadPreviousAnalysisResultsIfExist=False):
    ###########################################################################
    ###########################################################################
    ###########################################################################
    ###########################################################################
    ###########################################################################
    #######################PERFORM ANALYSIS OF THE VIDEO#######################
    ###########################################################################
    ###########################################################################
    ###########################################################################
    ###########################################################################
    ###########################################################################
    ###########################################################################

    try:
        common.DebugPrint(
            "Entered AnalyzeMedia(mediaServer=%d): " \
                "Settings.myCfg.videoAnalysis = %d." % \
                (mediaServer, Settings.myCfg.videoAnalysis))

        if Settings.myCfg.videoAnalysis == True:
            common.PetWatchdog()
            # This is for the iCam Viewer watchdog

            if mediaServer == 0:
                # YouTube
                VideoAnalysis.motionFactorPerFrame = -1.0
                """
                if (len(UI.dateTimeStrHistory[UI.indexVideo]) == 1) and 
                     (ytVideoEntry.media.description.text.find("mfpf") == -1):
                """
                MFPF_STR = "MFPF="
                indexMFPF = ytVideoEntry.media.description.text.find(MFPF_STR)

                if indexMFPF == -1:
                    if justReadPreviousAnalysisResultsIfExist == False:

                        if not os.path.isfile(aMediaPathFileName):
                            common.DebugPrint(
                                "AnalyzeMedia(): File %s doesn't exist so " \
                                    "am not trying to video analyze the file." % \
                                    aMediaPathFileName)
                        else:
                            common.DebugPrint("AnalyzeMedia(): Calling " \
                                    "VideoAnalysis.AnalyzeVideo(%s)" % \
                                    aMediaPathFileName)

                            VideoAnalysis.AnalyzeVideo(aMediaPathFileName,
                                    Settings.myCfg.videoAnalysisShowDifferences)

                            """
                            AnalyzeVideoClosure = lambda pathFileName: lambda : \
                                        VideoAnalysis.AnalyzeVideo(pathFileName)

                            timerAnalyzeVideo = threading.Timer(0.1, \
                                        AnalyzeVideoClosure(aMediaPathFileName))

                            timerAnalyzeVideo.start()
                            """

                            """
                            If VideoAnalysis.AnalyzeVideo() gave error
                                VideoAnalysis.motionFactorPerFrame = -1.0
                            """
                            if UPDATE_YOUTUBE_ENTRY and \
                                    (VideoAnalysis.motionFactorPerFrame >= 0.0):
                                common.DebugPrint(
                                    "AnalyzeMedia():"
                                        "    ytVideoEntry = %s\n" % \
                                        str(ytVideoEntry) + \

                                    "    Video published on: %s\n" % \
                                        ytVideoEntry.published.text + \

                                    "    Video description: %s\n" % \
                                        ytVideoEntry.media.description.text + \

                                    "    Video keywords: %s\n" % \
                                        ytVideoEntry.media.keywords.text + \

                                    "    Video category: %s\n" % \
                                        ytVideoEntry.media.category[0].text)

                                """
                                #From iCam.py YouTubeVideoUpload():
                                #($mediaFileSize bytes)
                                videoDescription = time.strftime(
                                        "%H:%M:%S.* %d-%m-%Y", crtTime) + " " + \
                                        deviceId + ", " + str(cameraId)

                                myMediaGroup = gdata.media.Group(
                                    title = gdata.media.Title(text = videoTitle),
                                    description = gdata.media.Description(
                                        description_type = "plain",
                                        text = videoDescription),
                                    keywords = gdata.media.Keywords(text = aKeyword),

                                    # See also
                                    #  https://gdata-python-client.googlecode.com/svn/trunk/pydocs/gdata.media.html#Private
                                    #Alex: From C:\Python27\Lib\site-packages\gdata\media\__init__.py

                                    # Does not work - it gives
                                    #    AttributeError: 'bool' object has no
                                    #           attribute '_BecomeChildElement'
                                    # private = True,
                                    # duration = aDuration,
                                    private = gdata.media.Private(),

                                    category = [gdata.media.Category(
                                        text = "People",
                                        scheme = "http://gdata.youtube.com/schemas/2007/categories.cat",
                                        label = "People" #'People &amp; Blogs'
                                        )],
                                    player = None
                                )
                                videoEntry = gdata.youtube.YouTubeVideoEntry( \
                                                            media = myMediaGroup)
                                """

                                # From iCam.py YouTubeVideoUpload():
                                devTags = ytVideoEntry.GetDeveloperTags()
                                """
                                developerTag01 = deviceId
                                developerTag02 = str(cameraId) + "**"
                                developerTag03 = motion_factor 
                                myDeveloperTags = [developerTag01, developerTag02,
                                                    developerTag03]
                                """

                                if len(devTags) == 2:
                                    """
                                    devTags.append(str(
                                        VideoAnalysis.motionFactorPerFrame))
                                    """

                                    devTags[1] = \
                                        str(VideoAnalysis.motionFactorPerFrame)
                                elif len(devTags) == 3:
                                    devTags[2] = \
                                        str(VideoAnalysis.motionFactorPerFrame)

                                """
                                It seems this triggers a strange exception:
                                    "tree.attrib[xml_attribute] =
                                        member.decode(MEMBER_STRING_ENCODING)"
                                    (e.g., see
                                  Z:\1PhD\ReVival\iCamViewer\stderr_2011_05_13_19_26_06.txt)
                                """
                                # ytVideoEntry.AddDeveloperTags(devTags)

                                ytVideoEntry.media.description.text += " (" + \
                                                                    MFPF_STR + \
                                    "%.2f;" % VideoAnalysis.motionFactorPerFrame

                                # ytVideoEntryUpdated
                                """
                                See https://gdata-python-client.googlecode.com/svn/trunk/pydocs/gdata.youtube.service.html:
                                    "Returns: An updated YouTubeVideoEntry on
                                        success or None."
                                """
                                ytVideoEntry = \
                                    Google.youtubeClient.UpdateVideoEntry(ytVideoEntry)

                                """
                                print "ytVideoEntryUpdated = %s" %
                                        str(ytVideoEntryUpdated) 

                                if ytVideoEntryUpdated is None:
                                """
                                if ytVideoEntry is None:
                                    common.DebugPrint("Unsuccessful update: " \
                                            "ytVideoEntryUpdated is None at " \
                                            "video analysis!!")
                else:
                    try:
                        # find(")")
                        indexMFPF_End = \
                            ytVideoEntry.media.description.text[indexMFPF +
                                                        len(MFPF_STR) : ].find(";")

                        if indexMFPF_End == -1:
                            indexMFPF_End = \
                                ytVideoEntry.media.description.text[indexMFPF +
                                                        len(MFPF_STR) : ].find(")")

                        common.DebugPrint(
                            "AnalyzeMedia(): indexMFPF_End = %d" % indexMFPF_End)

                        myStr = ytVideoEntry.media.description.text[indexMFPF +
                                        len(MFPF_STR) : indexMFPF + len(MFPF_STR) +
                                        indexMFPF_End]

                        VideoAnalysis.motionFactorPerFrame = float(myStr)
                    except:
                        common.DebugPrintErrorTrace()

                common.DebugPrint(
                    "AnalyzeMedia(): VideoAnalysis.motionFactorPerFrame = " \
                        "%.2f" % VideoAnalysis.motionFactorPerFrame)

            elif (mediaServer == 2) or (mediaServer == 3):
                # iCam server OR Local video

                # Settings.myCfg.playHowManyTimesSameVideo + 1
                if len(UI.dateTimeStrHistory[UI.indexVideo]) == 1: # 2 + 1): 
                    common.DebugPrint(
                        "AnalyzeMedia(): Calling "\
                            "VideoAnalysis.AnalyzeVideo(%s)" % aMediaPathFileName)

                    VideoAnalysis.AnalyzeVideo(aMediaPathFileName,
                            Settings.myCfg.videoAnalysisShowDifferences)

        ###########################################################################
        ###########################################################################
        ###########################################################################
        if Settings.myCfg.audioAnalysis == True:
            # This is for the iCam Viewer watchdog:
            common.PetWatchdog()

            if mediaServer == 0:
                # YouTube
                AudioAnalysis.soundPercentage = -1.0
                """
                if (len(UI.dateTimeStrHistory[UI.indexVideo]) == 1) and 
                     (ytVideoEntry.media.description.text.find("mfpf") == -1):
                """
                STR_TO_SEARCH = "SP=" # "A[M;RMS]"
                indexFound = ytVideoEntry.media.description.text.find(
                                                                STR_TO_SEARCH)

                if indexFound == -1:
                    if justReadPreviousAnalysisResultsIfExist == False:
                        if not os.path.isfile(aMediaPathFileName):
                            common.DebugPrint(
                                "AnalyzeMedia(): File %s doesn't exist so " \
                                    "am not trying to audio analyze the file." % \
                                    aMediaPathFileName)
                        else:
                            common.DebugPrint(
                                "AnalyzeMedia(): Calling " \
                                    "AudioAnalysis.AnalyzeVideo(%s, ...)" % \
                                    aMediaPathFileName)

                            AudioAnalysis.AnalyzeMovieAudio(aMediaPathFileName,
                                    int(ytVideoEntry.media.duration.seconds))
                            """
                            AnalyzeMovieAudioClosure = lambda aMediaPathFileName: \
                                lambda : AudioAnalysis.AnalyzeMovieAudio(
                                                            aMediaPathFileName)

                            timerAnalyzeMovieAudio = threading.Timer(0.1,
                                    AnalyzeMovieAudioClosure(aMediaPathFileName))

                            timerAnalyzeMovieAudio.start()
                            """
                            # time.sleep(1.1) pass

                            if UPDATE_YOUTUBE_ENTRY and \
                                        (AudioAnalysis.soundPercentage >= 0.0):
                                ytVideoEntry.media.description.text += \
                                        "SP=%.1f%%;" % \
                                        (AudioAnalysis.soundPercentage * 100.0)

                                """
                                ytVideoEntry.media.description.text +=
                                    "A[max;min;M;RMS]=%.2e;%.2e;%.2e;%.2e;" % \
                                    (AudioAnalysis.amplitudeMax,
                                        AudioAnalysis.amplitudeMin,
                                        AudioAnalysis.amplitudeMean,
                                        AudioAnalysis.amplitudeRMS)
                                """
                                ytVideoEntry.media.description.text += \
                                    "A[max;min;M;RMS]=%.6f;%.6f;%.6f;%.6f;" % \
                                    (AudioAnalysis.amplitudeMax,
                                       AudioAnalysis.amplitudeMin,
                                       AudioAnalysis.amplitudeMean,
                                       AudioAnalysis.amplitudeRMS)

                                # I used also "A[M;RMS]"
                                ytVideoEntry.media.description.text += \
                                        "F[M]=%.0f)" % AudioAnalysis.frequencyRough

                                """
                                See https://gdata-python-client.googlecode.com/svn/trunk/pydocs/gdata.youtube.service.html:
                                    "Returns: An updated YouTubeVideoEntry on
                                        success or None."
                                """
                                ytVideoEntry = \
                                    Google.youtubeClient.UpdateVideoEntry(ytVideoEntry)

                                if ytVideoEntry is None:
                                    common.DebugPrint(
                                        "AnalyzeMedia(): Unsuccessful " \
                                            "update: ytVideoEntryUpdated is " \
                                            "None at audio analysis!!")
                else:
                    try:
                        """
                        IMPORTANT Note: if I use .find("%%;") I think it interprets
                            the string really as %%; (3 chars) :o
                        """
                        indexFound_End = \
                            ytVideoEntry.media.description.text[indexFound +
                                            len(STR_TO_SEARCH) : ].find("%;")

                        """
                        if indexFound_End == -1:
                            indexFound_End = ytVideoEntry.media.description.text[ \
                                    indexFound + len(STR_TO_SEARCH) : ].find(")")
                        """
                        common.DebugPrint("AnalyzeMedia(): indexFound_End = %d" % \
                                                            indexFound_End)

                        myStr = \
                            ytVideoEntry.media.description.text[indexFound +
                                    len(STR_TO_SEARCH) : indexFound +
                                    len(STR_TO_SEARCH) + indexFound_End]

                        AudioAnalysis.soundPercentage = float(myStr) / 100.0

                        """
                        Compute also the following:
                            A[max;min;M;RMS]
                            frequencyRough = !!!!
                        """
                    except:
                        common.DebugPrintErrorTrace()

                common.DebugPrint(
                    "AnalyzeMedia(): AudioAnalysis.soundPercentage = %.2f" % \
                                        AudioAnalysis.soundPercentage)

            elif (mediaServer == 2) or (mediaServer == 3):
                # iCam server OR Local video

                if len(UI.dateTimeStrHistory[UI.indexVideo]) == 1: #2 + 1):
                    #Settings.myCfg.playHowManyTimesSameVideo + 1

                    common.DebugPrint("AnalyzeMedia(): Calling " \
                                "AudioAnalysis.AnalyzeVideo(%s, ...)" % \
                                aMediaPathFileName)

                    AudioAnalysis.AnalyzeMovieAudio(aMediaPathFileName, 30.0,
                                        lookIfReportFileIsAlreadyPresent=False)
                    # int(ytVideoEntry.media.duration.seconds))

        # ##########################INTERESTING EVENT DETECTION####################
        # ##########################INTERESTING EVENT DETECTION####################
        # ##########################INTERESTING EVENT DETECTION####################
        # ##########################INTERESTING EVENT DETECTION####################
        """
        Detect interesting events based on the analysis and trigger alarm if
            interesting events detected.
        One option of alarm triggering - Make phone call with Skype:
          "C:\Program Files\Skype\Phone\Skype.exe" /callto:+40772103340
              #+01234567890 #/nosplash doesn't work

        #Check if phone's charger status is 0 (Not charging)
        """

        if False:
            # Use also sound Amplitude, Frequency
            if (VideoAnalysis.motionFactorPerFrame > 30.0) or \
                        (AudioAnalysis.soundPercentage > 10.0):
                UI.Alarm("Detected activity (video or audio).")

        """
        If 110mb.com is down this can take ~6 mins for each Monitor()
            (because of retries).
        if False:
        """
        if True:
            Monitor(Settings.myCfg.deviceId[UI.indexVideo])
            # Detect interesting events of phones monitored that are not Viewed
            #Monitor("N95N95N95N95N95")
            #Monitor("N82N82N82N82N82")
    except:
        if common.MY_DEBUG_STDERR:
            traceback.print_exc()
            sys.stderr.flush()
