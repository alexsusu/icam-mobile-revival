"""
Here we have declared the vars for GUI (and not only),
    the QLabel for video titles and
    the widgets that are going to hold the video elements.
"""

import common
import Settings
import Slideshow
import subprocess
import time
import SplitScreenMC

if common.MY_PYSIDE:
    from PySide import QtCore, QtGui
elif common.MY_PYQT:
    from PyQt4 import Qt
    # For Dialog
    from PyQt4 import QtCore, QtGui



RATIO_BETWEEN_TITLE_AND_VIDEO = 10

DISPLAY_VIDEO = True

# SHOW_PHOTO = True
SHOW_PHOTO = False

MAX_NUM_VIDEOS = 6 + 1 # 1 for the slideshow dialog widget

indexVideo = -1

vlcVideo =              [None] * MAX_NUM_VIDEOS
player =                [None] * MAX_NUM_VIDEOS
videoTitle =            [None] * MAX_NUM_VIDEOS
instance =              [None] * MAX_NUM_VIDEOS
media =                 [None] * MAX_NUM_VIDEOS
# It seems it is no longer used !!!!
#vlcVideoLayout =        [None] * MAX_NUM_VIDEOS
videoTitleStr =         [None] * MAX_NUM_VIDEOS
videoDescriptionStr =   [None] * MAX_NUM_VIDEOS
# These are not really UI related
dateTimeStr =           [None] * MAX_NUM_VIDEOS
dateTimeStrHistory =    [[]] * MAX_NUM_VIDEOS
dateTimeStrMax =        [""] * MAX_NUM_VIDEOS

mediaPathFileName =     [None] * MAX_NUM_VIDEOS
imagePathFileName =     [None] * MAX_NUM_VIDEOS
ytVideoEntryList =      [None] * MAX_NUM_VIDEOS #!!!!TODO: move this to Google.py
videoIdStrList =        [None] * MAX_NUM_VIDEOS
"""
It is required at least for the non-modal windows - otherwise they don't
    appear at all??
"""
errorDialog = [None] * MAX_NUM_VIDEOS







# Used by InitializeVLCVideoWidget() function below - TODO: maybe move it to SplitScreen
class MyQLabel(QtGui.QLabel):

    def __init__(self, aIndexVideo, parent=None):
        super(MyQLabel, self).__init__(parent)
        self.indexVideo = aIndexVideo

        # Qt.AlignBottom | Qt.AlignRight);
        self.setAlignment(QtCore.Qt.AlignCenter)

        """
        # From http://qbzr.sourcearchive.com/documentation/0.16/ui__info_8py-source.html:

        #QtCore.Qt.LinksAccessibleByMouse
        self.setTextInteractionFlags(QtCore.Qt.TextSelectableByKeyboard)

        self.setTextInteractionFlags(QtCore.Qt.TextSelectableByKeyboard |
                                        QtCore.Qt.TextSelectableByMouse)
        """

        """
        !!!!Gives error:
            QObject: Cannot create children for a parent that is in a
                    different thread.

            (Parent is MyQLabel(0x2166698), parent's thread is
                    QThread(0x1d5baf8), current t

            hread is QThread(0x21b0b28)
            QObject: Cannot create children for a parent that is in a
                    different thread.

            (Parent is QTextDocument(0x21bebb0), parent's thread is
                    QThread(0x21b0b28), current thread is QThread(0x1d5baf8)
        """


    @staticmethod
    def OnContextMenuVideoTitle(aIndexVideo, aQPoint=None):
        # global indexMediaFileURLList global deltaIndexMediaFileList

        try:
            common.DebugPrint(
                "MyQLabel::OnContextMenuVideoTitle(aIndexVideo=%d, " \
                "aQPoint=%s)." % (aIndexVideo, aQPoint))

            #Slideshow.slideshowView = Slideshow.SlideshowView(aIndexVideo)
            res = Slideshow.SlideshowView(aIndexVideo)

            assert res == Slideshow.slideshowView

            res.BeforeExec()

            """
            This doesn't work well - you can't manipulate the dialog at all
                (press buttons, close it, move it).
                Is it because the exec_() is called in a different thread?

            #!!!!If we want to display the dialog before downloading
                MediaFileList.js use the thread below:
            threading.Timer(0.01, slideshowView.exec_).start()
            """

            """
            This doesn't work well either - the video appears in the other window
                not for this dialog :).
                And when the video stops, the app freezes at release VLC objects.
                It seems that excuting Slideshow.slideshowView.PreparePlaylist in a
                    separate thread is NOT good for the VLC objects.
            #threading.Timer(0.01, Slideshow.slideshowView.PreparePlaylist).start()
            thread.start_new_thread(Slideshow.slideshowView.PreparePlaylist, ())
            """
            #Slideshow.slideshowView.PreparePlaylist()

            #Slideshow.slideshowView.exec_()
            resExec = res.exec_()

            common.DebugPrint(
                "MyQLabel::OnContextMenuVideoTitle(): resExec = %s." % str(resExec))

            # Unfortunately del does not delete the SlideshoMC.view reference
            #del Slideshow.slideshowView
            del Slideshow.slideshowView
            res.__del__()

            """
            It seems that when we open the SlideshowView the other video
                in SplitScreen freezes and doesn't call
                MediaFinishedPlayingEventHandler().
                Therefore, we should call it ourselves now, in order
                to attempt to make SplitScreen "unfreeze".
            """
            #!!!!TODO: sometimes it blocks Slideshow because of this
            SplitScreenMC.splitScreenMC.MediaFinishedPlayingEventHandler(None,
                                                                    None, None)
        except:
            common.DebugPrintErrorTrace()

    #OnContextMenuVideoTitleCurried = lambda aIndexVideo: (lambda aQPoint: \
    #    OnContextMenuVideoTitle(aIndexVideo, aQPoint))
    @staticmethod
    def OnContextMenuVideoTitleCurried(aIndexVideo):
        return lambda aQPoint: MyQLabel.OnContextMenuVideoTitle(aIndexVideo, aQPoint)


    def mouseDoubleClickEvent(self, event):
        global player

        try:
            self.justDoubleClicked = True
            #self.text = QString("Double-clicked.")
            #self.update()

            common.DebugPrint( \
                "Entered MyQLabel::mouseDoubleClickEvent(event=%s)." % \
                                                                str(event))

            """
            Undo the previous mouse click since this was not a single-click
                but a double-click.

            player[self.indexVideo].set_pause(
                                        player[self.indexVideo].is_playing())
            """
            common.DebugPrint("MyQLabel::mouseDoubleClickEvent(): before " \
                                "self.mousePressEvent(None).")

            #!!!!TODO: remove self.mousePressEvent(None) - I guess NOT necessary
            self.mousePressEvent(None)

            #player[4] = None
            player[MAX_NUM_VIDEOS - 1] = None

            MyQLabel.OnContextMenuVideoTitleCurried(self.indexVideo)(None)
        except:
            common.DebugPrintErrorTrace()

        common.DebugPrint("Exiting MyQLabel::mouseDoubleClickEvent().")


    def mousePressEvent(self, event):
        if event is None:
            return

        try:
            #self.justClicked = True
            #self.text = QString("Double-clicked.")
            #self.update()
            common.DebugPrint(
                "Entered MyQLabel::mousePressEvent(event=%s)." % str(event))

            if event.button() == QtCore.Qt.LeftButton:
                print "MyQLabel::mousePressEvent(): event.button() == " \
                    "QtCore.Qt.LeftButton"

                if player[self.indexVideo] is not None:
                    # play/resume if zero, pause if non-zero.

                    player[self.indexVideo].set_pause(
                                        player[self.indexVideo].is_playing())
            elif event.button() == QtCore.Qt.RightButton:
                """
                In case we right-click on title video, we start a separate
                    instance of VLC to play the corresponding video.
                """
                """
                subprocess.call(["c:/python25/python",
                  "Z:/1PhD/ReVival/Google/gdata-python-client/gdata-2.0.14/" \
                    "tests/gdata_tests/youtube/11YouTube-dl/" \
                    "youtube-dl_orig.py", videoURL])
                #, stdout = None, stderr = fOutput)
                """
                common.DebugPrint(
                    "MyQLabel::mousePressEvent(): event.button() == " \
                    "QtCore.Qt.RightButton. self.indexVideo = %d, " \
                    "mediaPathFileName[self.indexVideo] = %s, " \
                    "myCfg.rotateDegrees[self.indexVideo] = %d" % \
                    (self.indexVideo,
                       mediaPathFileName[self.indexVideo],
                       Settings.myCfg.rotateDegrees[self.indexVideo]))

                """
                subprocess.call([common.VLC_EXECUTABLE_PATH_FILENAME,
                        mediaPathFileName[self.indexVideo],
                        "--vout-filter=transform", "--transform-type=90",
                        "--video-filter=adjust", "--brightness=0.5"])
                #, "CurrentSymLink_1.3gp"
                """

                """
                See http://docs.python.org/library/subprocess.html#sub
                    process.Popen subprocess.Popen() spawns the process
                    and does not wait for its completion, while
                    subprocess.call() does wait.

                We treat specially case 0 because otherwise if we give
                    --vout-filter=transform --transform-type=0 it still rotates
                    (by 90? degrees) the video
                """
                if Settings.myCfg.rotateDegrees[self.indexVideo] == 0:
                    subprocess.Popen([
                        common.VLC_EXECUTABLE_PATH_FILENAME,
                        mediaPathFileName[self.indexVideo],
                        "--video-filter=adjust",
                        "--brightness=%.2f" %
                            Settings.myCfg.brightness[self.indexVideo],
                        "--contrast=%.2f" %
                            Settings.myCfg.contrast[self.indexVideo],
                        "--hue=%.2f" % Settings.myCfg.hue[self.indexVideo],
                        "--saturation=%.2f" %
                            Settings.myCfg.saturation[self.indexVideo],
                        "--gamma=%.2f" %
                            Settings.myCfg.gamma[self.indexVideo]
                        ])
                else:
                    subprocess.Popen([
                        common.VLC_EXECUTABLE_PATH_FILENAME,
                        mediaPathFileName[self.indexVideo],
                        "--video-filter=adjust",
                        "--brightness=%.2f" %
                            Settings.myCfg.brightness[self.indexVideo],
                        "--contrast=%.2f" %
                            Settings.myCfg.contrast[self.indexVideo],
                        "--hue=%.2f" % Settings.myCfg.hue[self.indexVideo],
                        "--saturation=%.2f" %
                            Settings.myCfg.saturation[self.indexVideo],
                        "--gamma=%.2f" %
                            Settings.myCfg.gamma[self.indexVideo],
                        "--video-filter=transform",
                        "--transform-type=%d" %
                            Settings.myCfg.rotateDegrees[self.indexVideo]
                        ])

                    """
                    media[indexVideo] = instance[indexVideo].media_new(
                        pathFileName, "no-video-title-show",
                        "sub-filter=marq{marquee=Playing}",
                        "video-filter=adjust", "brightness=%.2f" % \
                        Settings.myCfg.brightness[indexVideo],
                            "contrast=%.2f" % Settings.myCfg.contrast[indexVideo],
                            "hue=%.2f" % Settings.myCfg.hue[indexVideo],
                            "saturation=%.2f" % Settings.myCfg.saturation[indexVideo],
                            "gamma=%.2f" % Settings.myCfg.gamma[indexVideo])

                    media[indexVideo] = instance[indexVideo].media_new(
                        pathFileName, "no-video-title-show",
                        "vout-filter=transform",
                        "transform-type=%d" % Settings.myCfg.rotateDegrees[indexVideo],
                        "video-filter=adjust",
                        "brightness=%.2f" % Settings.myCfg.brightness[indexVideo],
                        "contrast=%.2f" % Settings.myCfg.contrast[indexVideo],
                        "hue=%.2f" % Settings.myCfg.hue[indexVideo],
                        "saturation=%.2f" % Settings.myCfg.saturation[indexVideo],
                        "gamma=%.2f" % Settings.myCfg.gamma[indexVideo])

                    AnalyzeMedia(Settings.myCfg.mediaServer[indexVideo],
                                ytVideoEntryList[indexVideo],
                                mediaPathFileName[indexVideo])
                    """

            #if event is None:
        except:
            common.DebugPrintErrorTrace()




# Used by SplitScreen and slideshowView
def InitializeVLCVideoWidget(index, mainLayout):
    """
    if vlcVideo[1]:
        # Frees up window system resources.
        #    Destroys the widget window if destroyWindow is true.

        # destroy() calls itself recursively for all the child widgets,
        #    passing destroySubWindows for the destroyWindow parameter.
        #    To have more control over destruction of subwidgets, destroy
        #    subwidgets selectively first.

        # This function is usually called from the QWidget destructor.
        print "Calling vlcVideo[1].destroy()"

        vlcVideo[1].destroy(destroyWindow = True, destroySubWindows = True)

        #del vlcVideo[1]
    """
    if SHOW_PHOTO:
        vlcVideo[index] = QtGui.QLabel()
    else:
        """
        # QtGui.QWidget - doesn't have setPixmap() to display photos - see
        #  http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qwidget.html

        Another solution, from
          http://stackoverflow.com/questions/2286864/how-can-i-add-a-picture-to-a-qwidget-in-pyqt4:
            "A generic QWidget does not have setPixmap().
            If this approach does not work for you, you can look at making
                your own custom widget that derives from QWidget and
                override the paintEvent method to display the image."
        """
        vlcVideo[index] = QtGui.QWidget()

    """
    #Does not work with vlcVideo[index] - probably because it is overwritten by
    #    VLC media player, etc

    #Inspired from
    #    http://stackoverflow.com/questions/782255/qt-and-context-menu

    vlcVideo[index].setContextMenuPolicy( QtCore.Qt.CustomContextMenu )

    #QtCore.QObject.connect(vlcVideo[index],
    #    QtCore.SIGNAL("customContextMenuRequested(const QPoint&)"),
    #    VlcVideoOnContextMenu)

    QtCore.QObject.connect(vlcVideo[index],
                QtCore.SIGNAL("customContextMenuRequested(QPoint)"),
                VlcVideoOnContextMenu)
    """

    # See http://www.opendocs.net/pyqt/pyqt4/html/qboxlayout.html (and
    # http://www.opendocs.net/pyqt/pyqt4/html/qvboxlayout.html)
    ###################vlcVideoLayout[index] = QtGui.QVBoxLayout()
    # !!!!This helps in setting the size of vlcVideoLayout[index]
    ###################vlcVideoLayout[index].setMargin(200)

    # Not useful - the layout is defined by mainLayout.addWidget()
    #vlcVideoLayout[index].setGeometry(QtCore.QRect(0, 100, 800, 500))
    # See http://www.opendocs.net/pyqt/pyqt4/html/qrect.html#QRect-2

    # #self.vlcVideoLayout[index].addSpacing(300) #See
    # http://www.opendocs.net/pyqt/pyqt4/html/qboxlayout.html#addSpacing
    # #self.vlcVideoLayout[index].setSpacing(90)
    # self.vlcVideoLayout[index].addStretch(200)
    """
    label = QtGui.QLabel("Line bla bla bla %d" % index)

    # See http://www.opendocs.net/pyqt/pyqt4/html/qt-alignment.html
    self.vlcVideoLayout[index].addWidget(label, 50)
    """

    # ##################vlcVideo[index].setLayout(vlcVideoLayout[index])
    # vlcVideo[index].setLayout(vlcVideoLayout[index])

    # Line bla bla bla %d" % index)
    #videoTitle[index] = QtGui.QLabel("")

    # Line bla bla bla %d" % index)
    videoTitle[index] = MyQLabel(index)

    """
    See http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qfont.html:
        "__init__ (self, QString family, int pointSize = -1, int weight = -1,
                    bool italic = False)"
    """
    #videoTitle[index].setFont(QtGui.QFont("Courier", 15, 50, False))

    """
    #See http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qfont.html:
            "__init__ (self, QString family, int pointSize = -1,
                        int weight = -1, bool italic = False)"
    """
    videoTitle[index].setFont(QtGui.QFont("Courier",
                              Settings.myCfg.titleFontSize, 50, False))
    # __init__ (self, QString family, int pointSize = -1, int weight =
    # -1, bool italic = False)

    videoTitle[index].setFrameStyle(QtGui.QFrame.Box)
    videoTitle[index].setLineWidth(0)

    # Inspired from http://stackoverflow.com/questions/782255/qt-and-
    # context-menu
    videoTitle[index].setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
    # QtCore.QObject.connect(vlcVideo[index],
    # QtCore.SIGNAL("customContextMenuRequested(const QPoint&)"),
    # VlcVideoOnContextMenu)

    if False:
        """
        We do not need to register these signals with the
            MyQLabel.OnContextMenuVideoTitleCurried function since we already have
            the event-handler functions MyQLabel.mouseDoubleClickEvent() and
            MyQLabel.mousePressEvent().
        """
        if common.MY_PYSIDE:
            QtCore.QObject.connect(videoTitle[index],
                                   QtCore.SIGNAL("customContextMenuRequested(QPoint)"),
                                   MyQLabel.OnContextMenuVideoTitleCurried(index))
        elif common.MY_PYQT:
            Qt.QObject.connect(videoTitle[index],
                               QtCore.SIGNAL("customContextMenuRequested(QPoint)"),
                               MyQLabel.OnContextMenuVideoTitleCurried(index))
    """
    #!!!!TODO
    settingsButton = QtGui.QPushButton("&Settings")
    settingsButton.setDefault(True)
    buttonBox = QtGui.QDialogButtonBox(QtCore.Qt.Vertical)
    buttonBox.addButton(settingsButton, QtGui.QDialogButtonBox.ActionRole)
    self.mainLayout.addWidget(buttonBox, 0, 1)
    #videoTitle[index].addWidget(buttonBox, 0, 1)
    #self.vlcVideoLayout[index].addWidget(buttonBox)
    """
    """
    #See http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qframe.html
    myFrame = QtGui.QFrame(vlcVideo[index])
    #myFrame = QtGui.QFrame(self.vlcVideoLayout[index])
    myFrame.setFrameShape(QtGui.QFrame.Box)
    myFrame.setLineWidth(100)
    #vlcVideo[index].addWidget(myWidget)
    #self.vlcVideoLayout[index].addWidget(myFrame)
    """
    if index == 0:
        """
        videoTitle = QtGui.QLabel("Line bla bla bla %d" % index)
        #See http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qgridlayout.html#addWidget-3:
        #    QGridLayout.addWidget(self, QWidget, int row, int column,
        #                           int rowSpan, int columnSpan,
        #                           Qt.Alignment alignment = 0)
        self.mainLayout.addWidget(vlcVideo[0], 0, 0, 1, 1)
        self.mainLayout.addWidget(videoTitle, 1, 0, 1, 1)
        """
        mainLayout.addWidget(videoTitle[index], 0, 0, 1, 1)
        """
        #See http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qframe.html
        myFrame = QtGui.QFrame(vlcVideo[0])
        #myFrame = QtGui.QFrame(self.vlcVideoLayout[index])
        myFrame.setFrameShape(QtGui.QFrame.Box)
        myFrame.setLineWidth(10)

        # This displays the VLC video in a separate window (at least when
        #    NUM_VIDEOS = 1), besides the frame which is displayed in the
        #    iCamViewer window.
        mainLayout.addWidget(myFrame, 1, 0, RATIO_BETWEEN_TITLE_AND_VIDEO, 1)
        """

        """
        See http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qgridlayout.html#addWidget-3:
            QGridLayout.addWidget(self, QWidget, int row, int column,
                                    int rowSpan, int columnSpan,
                                    Qt.Alignment alignment = 0)
        """
        mainLayout.addWidget(vlcVideo[0], 1, 0,
                             RATIO_BETWEEN_TITLE_AND_VIDEO, 1)

        """
        #AttributeError: 'PySide.QtGui.QWidget' object has no
        #    attribute 'setFrameStyle'
        vlcVideo[0].setFrameStyle(QtGui.QFrame.Box)

        vlcVideo[0].setLineWidth(20)
        """
    elif index == 1:
        # self.mainLayout.addWidget(vlcVideo[1], 0, 1, 1, 2)
        # #self.mainLayout.addWidget(vlcVideo[1], 0, 1, 1, 1)
        mainLayout.addWidget(videoTitle[index], 0, 1, 1, 1)
        mainLayout.addWidget(vlcVideo[1], 1, 1,
                             RATIO_BETWEEN_TITLE_AND_VIDEO, 1)
        # self.mainLayout.addWidget(label, 0, 0, 0, 1)

        """
        From http://tamss60.tamoggemon.com/2010/01/10/qpainterbegin-paint-device-returned-engine-0-type-1-2/:
            QPainter::begin: Paint device returned engine == 0, type: 1
            In this case, the situation is simple. You are most likely drawing
                on a QWidget outside of its PaintEvent.
            Like it or not, but there is no way to draw on a QWidget outside
                of its paintEvent (unless some special flags are set, which
                limit compatibility, blah blah).

        try:
            myPhoto = QtGui.QImage("./612061206120612/CurrentSymLink_0.jpg")
            painter = QtGui.QPainter(vlcVideo[1])
            painter.drawImage(0, 0, myPhoto)
            vlcVideo[1].show()
        except:
            common.DebugPrintErrorTrace()
        """
    elif index == 2:
        # mainLayout.addWidget(vlcVideo[1], 0, 0, 1, 2)
        mainLayout.addWidget(videoTitle[index],
                             RATIO_BETWEEN_TITLE_AND_VIDEO, 0, 1, 1)

        mainLayout.addWidget(vlcVideo[2], 1 +
                            RATIO_BETWEEN_TITLE_AND_VIDEO, 0,
                            RATIO_BETWEEN_TITLE_AND_VIDEO, 1)
    elif index == 3:
        # self.mainLayout.addWidget(vlcVideo[3], 1, 1, 1, 2)
        mainLayout.addWidget(videoTitle[index],
                             RATIO_BETWEEN_TITLE_AND_VIDEO, 1, 1, 1)

        mainLayout.addWidget(vlcVideo[3], 1 +
                            RATIO_BETWEEN_TITLE_AND_VIDEO, 1,
                            RATIO_BETWEEN_TITLE_AND_VIDEO, 1)
    elif index == 4:
        # This is for Slideshow
        """
        #self.mainLayout.addWidget(vlcVideo[3], 1, 1, 1, 2)
        mainLayout.addWidget(videoTitle[index], 0, 0, 1, 1)

        mainLayout.addWidget(vlcVideo[4], 1, 0,
                                RATIO_BETWEEN_TITLE_AND_VIDEO, 1)
        """
        mainLayout.addWidget(videoTitle[index], 2 *
                            RATIO_BETWEEN_TITLE_AND_VIDEO, 0, 1, 1)

        mainLayout.addWidget(vlcVideo[4], 1 + 2 *
                            RATIO_BETWEEN_TITLE_AND_VIDEO, 0,
                            RATIO_BETWEEN_TITLE_AND_VIDEO, 1)
    elif index == 5:
        mainLayout.addWidget(videoTitle[index], 2 *
                             RATIO_BETWEEN_TITLE_AND_VIDEO, 1, 1, 1)

        mainLayout.addWidget(vlcVideo[5], 1 + 2 *
                             RATIO_BETWEEN_TITLE_AND_VIDEO, 1,
                             RATIO_BETWEEN_TITLE_AND_VIDEO, 1)
    """
        # See http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qgridlayout.html#addWidget-3: 
        #QGridLayout.addWidget (self, QWidget, int row, int column, int rowSpan, int columnSpan, Qt.Alignment alignment = 0)

        mainLayout.addWidget(videoTitle[index], 0, 0, 1, 1)
        mainLayout.addWidget(vlcVideo[0], 1, 0, 1, 1)
    elif index == 1:
        #self.mainLayout.addWidget(vlcVideo[1], 0, 1, 1, 2)
        ##self.mainLayout.addWidget(vlcVideo[1], 0, 1, 1, 1)
        mainLayout.addWidget(videoTitle[index], 0, 1, 1, 1)
        mainLayout.addWidget(vlcVideo[1], 1, 1, 1, 1)
        #self.mainLayout.addWidget(label, 0, 0, 0, 1)
    elif index == 2:
        #mainLayout.addWidget(vlcVideo[1], 0, 0, 1, 2)
        mainLayout.addWidget(videoTitle[index], 2, 0, 1, 1)
        mainLayout.addWidget(vlcVideo[2], 3, 0, 1, 1)
    elif index == 3:
        #self.mainLayout.addWidget(vlcVideo[3], 1, 1, 1, 2)
        mainLayout.addWidget(videoTitle[index], 2, 1, 1, 1)
        mainLayout.addWidget(vlcVideo[3], 3, 1, 1, 1)
    elif index == 4:
        #self.mainLayout.addWidget(vlcVideo[3], 1, 1, 1, 2)
        mainLayout.addWidget(videoTitle[index], 0, 0, 1, 1)
        mainLayout.addWidget(vlcVideo[4], 1, 0, 1, 1)
    """


# !!!!TODO: make sure it runs in the GUI/main thread
def Alarm(aText):
    for i in range(5):
        """
        Inspired from
            http://www.pyside.org/docs/pyside/PySide/QtGui/QSound.html
        """
        QtGui.QSound.play("notify.wav")  

        # print "i =", i
        time.sleep(5.0)

    # QtGui.QMessageBox.information(self, "iCamViewer", aText)
    QtGui.QMessageBox.information(None, "iCamViewer", aText)
    """
    msgBox = QtGui.QMessageBox()
    msgBox.setText(aText)
    msgBox.exec_()
    """
