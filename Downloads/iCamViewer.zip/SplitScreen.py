import common
import Settings
import SettingsDialog
import thread
import threading
import UI
import View

if common.MY_PYSIDE:
    from PySide import QtCore, QtGui
elif common.MY_PYQT:
    from PyQt4 import Qt
    # For Dialog
    from PyQt4 import QtCore, QtGui



multiViewer = None

class SplitScreen(QtGui.QMainWindow, View.View):
#class SplitScreen(QtGui.QMainWindow):
    """
    Inspired from C:\Python25\Lib\site-packages\PyQt4\examples\mainwindows\
                                                application\application.pyw
    """

    """
    def __init__(self, *args): #aIndexVideo):
        common.DebugPrint(
            "Entered View::__init__(self=%s, args=%s)" % \
                                                        (self, str(args)))
        super(View, self).__init__() #*args)

        self.condition = threading.Condition()

        self.SetSignals()
    """


    def __init__(self, parent=None):
        try:
            super(SplitScreen, self).__init__(parent)

            common.DebugPrint(
                "SplitScreen::__init__(): threading.currentThread() = %s\n" % \
                                            str(threading.currentThread()) +
                "SplitScreen::__init__(): thread.get_ident() = %d\n" % \
                                                        thread.get_ident())

            myDialog = QtGui.QDialog()
            self.setCentralWidget(myDialog)
            self.mainLayout = QtGui.QGridLayout()

            """
            #See http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qmenubar.html#addMenu
            self.settingsMenu = self.menuBar().addMenu("&Settings")

            self.exitAct = QtGui.QAction("E&xit", self, shortcut = "Ctrl+Q",
                                statusTip = "Exit the application",
                                triggered = self.close)

            self.settingsMenu.addAction(self.exitAct)
            """
            """
            self.fileMenu.addAction(self.newAct)
            self.fileMenu.addAction(self.openAct)
            self.fileMenu.addAction(self.saveAct)
            self.fileMenu.addAction(self.saveAsAct)
            self.fileMenu.addSeparator();
            """

            """
            self.viewMenu = self.menuBar().addMenu("&Videos")

            self.view00Act = QtGui.QAction("Phone 0, camera 0", self,
                                shortcut = "", statusTip = "",
                                triggered = self.close)

            self.viewMenu.addAction(self.view00Act)

            self.view01Act = QtGui.QAction("Phone 0, camera 1", self,
                                shortcut = "",
                                statusTip = "", triggered = self.close)

            self.viewMenu.addAction(self.view01Act)

            self.view10Act = QtGui.QAction("Phone 1, camera 0", self,
                                shortcut = "", statusTip = "",
                                triggered = self.close)

            self.viewMenu.addAction(self.view10Act)

            self.view11Act = QtGui.QAction("Phone 1, camera 1", self,
                                shortcut = "", statusTip = "",
                                triggered = self.close)

            self.viewMenu.addAction(self.view11Act)
            """

            """
            self.googleAction = QtGui.QAction("&YouTube/Picasa", self,
                            shortcut = "Ctrl+Y",
                            statusTip = "YouTube/Picasa account",
                            triggered = self.CreateSettingsDialog)

            self.menuBar().addAction(self.googleAction)
            """

            """
            global settingsDialog
            settingsDialog = SettingsDialog()

            self.settingsAction = QtGui.QAction("&Settings", self,
                            shortcut = "Ctrl+S",
                            statusTip = "Settings for the viewer",
                            triggered = settingsDialog.exec_)

            self.menuBar().addAction(self.settingsAction)
            """
            self.settingsAction = QtGui.QAction("&Settings", self,
                    shortcut="Ctrl+S", statusTip="Settings for the viewer",
                    triggered=self.CreateSettingsDialog)

            self.menuBar().addAction(self.settingsAction)

            if Settings.myCfg.audioMute == 0:
                muteButtonText = "&Mute"
            else:
                muteButtonText = "Unmute"

            """
            self.muteAction = QtGui.QAction("&Mute", self, shortcut = "Ctrl+M",
                                statusTip = "Mute audio", triggered = self.Mute)
            """
            self.muteAction = QtGui.QAction(muteButtonText, self, shortcut="Ctrl+M",
                                statusTip="Mute audio", triggered=self.ToggleMute)
            self.menuBar().addAction(self.muteAction)

            """
            self.analysisAction = QtGui.QAction("&Analysis", self,
                            shortcut = "Ctrl+A", statusTip = "Video/audio",
                            triggered = self.close)

            self.menuBar().addAction(self.analysisAction)
            """
            self.exitAction = QtGui.QAction("E&xit", self, shortcut="Ctrl+Q",
                                            statusTip="Exit the application",
                                            triggered=self.close)

            self.menuBar().addAction(self.exitAction)

            if Settings.myCfg.NUM_VIDEOS > 2:
                #self.setMinimumSize(700, 700)
                #self.setMinimumSize(1024, 680)
                self.setMinimumSize(1000, 650)

                #self.setMaximumSize(1024, 680)
                self.adjustSize()

                #self.setSizePolicy(QtGui.QSizePolicy.Ignored,
                #                   QtGui.QSizePolicy.Ignored)

                # buttonBox = QtGui.QDialogButtonBox(QtCore.Qt.Vertical)
            buttonBox = QtGui.QDialogButtonBox(QtCore.Qt.Horizontal)

            # See http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qdialog.html
            # See http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qgridlayout.html

            """
            UI.vlcVideo[0] = QtGui.QWidget()
            self.vlcVideoLayout[0] = QtGui.QVBoxLayout()
            self.vlcVideoLayout[0].setMargin(0)

            #See http://www.opendocs.net/pyqt/pyqt4/html/qboxlayout.html#addSpacing
            self.vlcVideoLayout[0].addSpacing(400)

            UI.vlcVideo[0].setLayout(self.vlcVideoLayout[0])
            self.mainLayout.addWidget(UI.vlcVideo[0], 0, 0, 1, 1)
            """
            index = 0
            # label = QtGui.QLabel("Line bla bla bla %d" % index)
            # self.mainLayout.addWidget(label, 0, 1, 1, 2)
            #
            # moreButton.toggled.connect(extension.setVisible)
            #
            # This is what populates the layout of the main window.
            for i in range(Settings.myCfg.NUM_VIDEOS):
                UI.InitializeVLCVideoWidget(i, self.mainLayout)
            # UI.InitializeVLCVideoWidget(1, self.mainLayout)
            # UI.InitializeVLCVideoWidget(2, self.mainLayout)
            # UI.InitializeVLCVideoWidget(3, self.mainLayout)
            #
            # """
            pal = QtGui.QPalette(myDialog.palette())
            myDialog.setAutoFillBackground(True)
            # pal.setColor(QtGui.QPalette.Window, QtGui.QColor("white"))
            pal.setColor(QtGui.QPalette.Window, QtGui.QColor("black"))
            pal.setColor(QtGui.QPalette.WindowText, QtGui.QColor("white"))
            myDialog.setPalette(pal)
            # """

            """
            This was initially immediately after
                mainLayout.addWidget(extension, 1, 0, 1, 2)
            """
            #self.setLayout(self.mainLayout)
            myDialog.setLayout(self.mainLayout)
            self.setWindowTitle("iCam Viewer")
            # extension.hide()

            self.setWindowModality(QtCore.Qt.NonModal)

            """
            Inspired from
                http://lists.trolltech.com/qt-interest/2006-08/thread00695-0.html
              and 
                http://www.qtcentre.org/threads/31905-Show-maximize-button-in-the-title-bar-of-a-QDialog-under-GNOME .
            """
            self.setWindowFlags(QtCore.Qt.CustomizeWindowHint |
                                QtCore.Qt.WindowCloseButtonHint |
                                QtCore.Qt.WindowMinMaxButtonsHint)

            myScreen = QtGui.QDesktopWidget().screenGeometry()

            """
            Maximize the window - a bit too much :)
            From
              http://nullege.com/codes/search/PyQt4.QtGui.QMainWindow.setGeometry
            """
            self.setGeometry(0, 20, myScreen.width(), myScreen.height() - 100)
        except:
            common.DebugPrintErrorTrace()


    def ToggleMute(self):
        try:
            #common.DebugPrint("Entered ToggleMute().")

            # Settings.myCfg.audioVolume = 0
            Settings.myCfg.audioMute = 1 - Settings.myCfg.audioMute

            Settings.SetVolume()

            if Settings.myCfg.audioMute == 0:
                multiViewer.muteAction.setText("Mute")
            else:
                multiViewer.muteAction.setText("Unmute")

            Settings.myCfg.StoreSettings()

            common.DebugPrint(
                "Entered SplitScreen::ToggleMute(): " \
                    "myCfg.audioVolume = %d." % Settings.myCfg.audioVolume)
        except:
            common.DebugPrintErrorTrace()


    def CreateSettingsDialog(self):
        try:
            #settingsDialog = None global settingsDialog
            settingsDialog = SettingsDialog.SettingsDialog()
            settingsDialog.exec_()
        except:
            #del settingsDialog
            #settingsDialog = None
            common.DebugPrintErrorTrace()


    def SetVideoTitleAndDrawRectangle(self):
        try:
            common.DebugPrint(
                "SplitScreen::SetVideoTitleAndDrawRectangle(): " \
                        "threading.currentThread() = %s\n" % \
                        str(threading.currentThread()) + \
                "SplitScreen::SetVideoTitleAndDrawRectangle(): " \
                        "thread.get_ident() = %d\n" % \
                        thread.get_ident())

            """
            if MODE_NO_UI:
                pass
            else:
            """
            if UI.DISPLAY_VIDEO:
                UI.videoTitle[UI.indexVideo].setLineWidth(2)

                UI.videoTitle[(UI.indexVideo - 1) % \
                           Settings.myCfg.NUM_VIDEOS].setLineWidth(0)

                pal = QtGui.QPalette(UI.videoTitle[UI.indexVideo].palette())

                pal.setColor(QtGui.QPalette.WindowText,
                             QtGui.QColor(85, 255, 0)) # QtGui.QColor("green"))

                UI.videoTitle[UI.indexVideo].setPalette(pal)

                pal = QtGui.QPalette(UI.videoTitle[(UI.indexVideo - 1) % \
                                        Settings.myCfg.NUM_VIDEOS].palette())

                pal.setColor(QtGui.QPalette.WindowText,
                                QtGui.QColor("white"))

                UI.videoTitle[(UI.indexVideo - 1) % \
                                    Settings.myCfg.NUM_VIDEOS].setPalette(pal)

            """
            Before calling this, the caller PlayNextVideoNew() called
                DownloadAndPlayVideoAndSetTitleWithCallable which
                calls
                DownloadAndStartPlayingVideoAndSetTitle
                which updated the UI.videoTitleStr.
            """
            if False:
                self.SetVideoTitle(UI.indexVideo, UI.videoTitle[UI.indexVideo])
            else:
                UI.videoTitle[UI.indexVideo].setText( \
                                            UI.videoTitleStr[UI.indexVideo])
        except:
            common.DebugPrintErrorTrace()


    """
    def SetVideoTitle(self, indexVideo, aVideoTitle): #aVideoTitle
        #global indexVideo, videoTitle, UI.videoTitleStr
        #!!!!TODO: aVideoTitle == UI.videoTitle[indexVideo]

        # See http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qlabel.html#setText
        UI.videoTitle[indexVideo].setText(UI.videoTitleStr[indexVideo])
        #aVideoTitle.setText(UI.videoTitleStr[indexVideo])

        # See http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qlabel.html#setText
        if MODE_NO_UI:
            pass
        else:
            aVideoTitle.setText(UI.videoTitleStr[indexVideo])
    """
