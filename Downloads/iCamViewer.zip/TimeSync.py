"""
This is a somewhat complicated way (and with sec? resolution at most) of doing time sync,
    using only the YouTube server:
        - basically it looks at the videos received at:
            - videoTitle = title composed of date & time of the video
            - publishedTime = YouTube server time when video was published (start? of the upload)
            - durationVideo
          and based on these values, assuming YouTube server time is correct,
            it computes a time drift and sends time adjusting command to that respective device.

    Note that this time sync works for the BT server phones in a BT "LAN".
        For the BT clients phones we haven't done an implementation yet.
    Note that the BT server can get better resolution time from an NTP server.
"""
import Google
import traceback

"""
TODO:                                                                                          
    !!!!!!!!
        N82 sends only actual videos, being BT server.
            But it sends a new video each ~11mins.
                And TimeSync sent more commands in this interval, because N82
                  checks for commands more often during this ~11mins time
                    interval.
                    Sending more sync commands than just one messes up the
                        clock: in ~10 hours clock got to 1951, etc.
        Solutions:
            Send cmd only every 20 mins, if N82 uploads videos on YT every
                    ~11mins.
                !!Even better - store also last video that was processed for sync.
            OR
            N82 gets command from YT only once per video rec.
            OR
            the sync cmd is specifying the absolute correct (YouTube-based, etc) time

    Generalize TIME_DIFFERENCE.
                                                                                                         
    !!!!We should take into account (almost) fully automatic for time zone
            differences between the iCamViewer and the iCam phone clients.
        Currently I am using GetDeltaTimeZoneRelatedToUTC(), but this is NOT
            the best implementation, since GetDeltaTimeZoneRelatedToUTC() should
            run on the phone, which probably won't (since the module dateutil
            is most likely (especially on Symbian :) ) not supported on the
            mobile platforms.
        The best solution is to specify the (UTC delta) time zone when
            registering the phone (in iCamViewer, maybe on the site).
      Also, the playlist iCam_cmd_[deviceId] should be created when
            registering the phone (in iCamViewer, maybe on the site).

    !!!!We need to specify in iCamViewer which phone is the BT server
        (if we have a BT net).
    We actually (should) specify this thing in iCamServer, in the Phone table.
    Also, we need to know for the BT clients the MAC addresses.

    On server check state.bin and get the time values and compare with the
      current time on server (adjusted!!!! to the time zone where the device is).

    !!Note there is also a latency from moment starting to upload to when
          upload finishes.
        I am curious the field published on YouTube which moment represents
            exactly.

    !!Make this module have access to (some) vars & methods from iCamViewer.pyw
            (probably the best way is to move them in common.pyw:
        SendCommandViaYouTube
        uploadMediaToYouTube
        if Google.youtubeClientAlreadyConnected == False:

DONE:
    When numSecs to adjust is < 60 don't do sync

    In TimeSync.SynchronizeTimePhoneWithYouTube():
        keep track the last time we did a sync - keep it in a
                        var lastTimeCommandSent["358..."]
            if ~20 mins have passed from the last update
                if the command sent last time is still in the playlist description then
                    do nothing
                else:
                    issue it again
            else:
                wait

    YouTube playlists 
      - sometimes it doesn't find playlist iCam_cmd_
        - I create another one  - I shouldn't create in SendCmd...() the
            playlist iCam_cmd_[deviceId] - it should be created when
            registering the phone.
        - when I don't find the playlist I should search for it again.
"""

"""
Synchronization between phones and server (with the benefit that the phones
            will have the right time, if the server will have it also :) ):
    Both info are in the state sent from phone
        filename: 2011_04_11_12_40_57_845_0.3gp
        crtTime = '12:41:13 11-04-2011 (126742 bytes)'
    movieArray0.push(
        ['http://mobile-revival.110mb.com/ReVival/N95N95N95N95N95/Media/2011/04/11/2011_04_11_12_40_57_845_0.3gp',
        'information', '12:41:13 11-04-2011 (126742 bytes)']);
"""

import sys
import time
import common

import datetime
import dateutil.tz
#from dateutil import tz


#MY_DEBUG_STDOUT = True
#MY_DEBUG_STDERR = True


"""
Time difference in seconds between local time iCamViewer and gdata
    YouTube server.
"""
TIME_DIFFERENCE = 3 * 3600
HOW_MUCH_TIME_TO_PASS_FROM_LAST_SYNC_COMMAND_TO_ISSUE_A_NEW_ONE = 2 * 600.0

lastTimeCommandSent = {} #None
#lastTimeCommandSent["N82N82N82N82N82"] = time.time()

"""
!!!!This is NOT the best implementation - see comments at the beginning of the file.

Note that even if on the YouTube.com site it shows the correct time for the
    time zone we are in, the GData client is:
        - either UTC or GMT based.
  See https://groups.google.com/forum/?fromgroups=#!topic/youtube-api-gdata/cym8b9Xdv5s
   "2007-10-15T15:39:34.000-07:00 is a timestamp in UTC-7, i.e. 7 hours earlier than UTC.
     2012-05-26T23:50:54.000Z is in UTC.
     The "Z" abbreviation is explained at
     http://en.wikipedia.org/wiki/Coordinated_Universal_Time#Time_zones"
  Note: The "Z" abbreviation comes from Zero time, which means GMT/UTC time.
"""
def GetDeltaTimeZoneRelatedToUTC():
    global TIME_DIFFERENCE

    #!!!!TODO Use instead time.timezone()

    #Inspired from http://stackoverflow.com/questions/4770297/python-convert-utc-datetime-string-to-local-datetime:
    to_zone = dateutil.tz.tzlocal()
    #print "to_zone =", to_zone

    #utc = datetime.utcnow()
    #print "dir(datetime) =", dir(datetime)

    #See http://docs.python.org/2/library/datetime.html:
    aUselessDatetime = datetime.datetime(2000, 1, 1, 0, 0, 0)

    """
    See http://doc.astro-wise.org/datetime.html#tzinfo for details:
    See C:\iCamViewer\111Kits\python-dateutil\python-dateutil-1.5\dateutil\tz.py
        for implementation details
    """
    #print "to_zone.utcoffset() =", to_zone.utcoffset(aUselessDatetime)

    """
    to_zone.utcoffset() returns a timedelta -
        see http://doc.astro-wise.org/datetime.html#timedelta for details.
    """
    #print "to_zone.utcoffset() =", to_zone.utcoffset(aUselessDatetime).seconds
    TIME_DIFFERENCE = to_zone.utcoffset(aUselessDatetime).seconds



#!!!!Not used
def ProcessYouTubePlaylists():
    try:
        playlistTitle = "iCam_cmd"
        
        playlistDescription = "set-pause-interval"

        playlistToUse = None

        """
        !!!!We require the YouTube alias/nickname which can be different to
            the Google username!!!!
        #feed = Google.youtubeClient.GetYouTubePlaylistFeed(username="MultiEnder123")
        #                                           username='ender123')

        # TODO!!!!You need to get all playlists - I think it returns only first 25!!!!
        """
        feed = Google.youtubeClient.GetYouTubePlaylistFeed()

        # Returns: A YouTubePlaylistFeed if successfully retrieved.
        print "ProcessYouTubePlaylists(): feed = %s" % str(feed)
        print "feed.entry[0] = %s" % str(feed.entry[0])

        for myEntry in feed.entry:
            myEntryTitle = myEntry.title.text
            #print "myEntryTitle = %s" % myEntryTitle

            #myEntry.id.text = http://gdata.youtube.com/feeds/api/users/MultiEnder123/playlists/3FD3773F7AC5DD1E
            #myEntry.id = <xml>...
            myEntryIdStr = myEntry.id.text.split("/")[-1]
            #print "  myEntryIdStr = %s" % myEntryIdStr

            if playlistTitle == myEntryTitle:
                playlistToUse = myEntry
                break

        Google.youtubeClient.UpdatePlaylist(playlist_id=myEntryIdStr,
                        new_playlist_title=playlistTitle,
                        new_playlist_description="", playlist_private=True,
                        username="default")
        """
        if playlistToUse == None:
            # Create the playlist if it was not found
            # Returns: The YouTubePlaylistEntry if successfully posted.
            playlistToUse = Google.youtubeClient.AddPlaylist(playlistTitle,
                                    playlistTitle, playlist_private=True)

        # It seems this info is not used!
        aVideoTitle = ""

        # It seems this info is not used!
        aVideoDescription = ""

        playlistURI = playlistToUse.feed_link[0].href
        #time.sleep(10) #!!!!!!!!!!!!!Maybe required

        response = Google.youtubeClient.AddPlaylistVideoEntryToPlaylist(playlistURI,
                        newVideoEntry.id.text.split("/")[-1],
                        aVideoTitle, aVideoDescription)
        """

        #newVideoEntry = Google.youtubeClient.InsertVideoEntry(videoEntry, \
        #                                               pathFileName)
    except:
        exceptionType, exceptionValue, exceptionTraceback = sys.exc_info()
        errorStr = "Exception in ProcessYouTubePlaylists() - details: " \
                    "exceptionTraceback = %s, exceptionType = %s, " \
                    "exceptionValue = %s. Bailing out..." % \
                    ( repr(traceback.format_tb(exceptionTraceback)),
                        str(exceptionType), str(exceptionValue) )

        common.DebugPrint(errorStr)

        common.DebugPrintErrorTrace()

#ProcessYouTubePlaylists()


def SendCommandViaYouTube(youtubeClient, playlistTitle, cmd):
    #global youtubeClient, youtubeClientAlreadyConnected
    #global googleUsername
    global deviceId

    """
    global uploadMediaToYouTube
    if (uploadMediaToYouTube == 0):
        uploadMediaToYouTube = 1
    """

    #common.DebugPrint("Entered SendCommandViaYouTube() at %s: cmd = %s." % \
    #           (GetCurrentDateTimeStringWithMilliseconds(), cmd))
    common.DebugPrint("Entered SendCommandViaYouTube(): cmd = %s." % cmd)

    """
    if Google.youtubeClientAlreadyConnected == False:
        if gdataModulesImported == False:
            ImportGdataModules()

        connResult = ConnectToYouTubeGData()
        # If connResult == -1 then don't continue
        #     (most likely bad username/passwd).!!!!
    """

    try:
        # Create the playlist if it doesn't exist.
        if False:
            playlistDescription = playlistTitle

            playlistToUse = None

            """
            !!!!We require the YouTube alias/nickname which can be different
                    to the Google username!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

            #feed = youtubeClient.GetYouTubePlaylistFeed(
            #                   username="MultiEnder123") #username='ender123')
            """

            # TODO!!!!You need to get all playlists - I think it returns only first 25
            feed = youtubeClient.GetYouTubePlaylistFeed()

            #Returns: A YouTubePlaylistFeed if successfully retrieved.
            #print "feed = %s" % str(feed)
            #print "feed.entry[0] = %s" % str(feed.entry[0])

            for myEntry in feed.entry:
                myEntryTitle = myEntry.title.text
                #print "myEntryTitle = %s" % myEntryTitle

                #myEntry.id.text = http://gdata.youtube.com/feeds/api/users/MultiEnder123/playlists/3FD3773F7AC5DD1E
                #myEntry.id = <xml>...
                myEntryIdStr = myEntry.id.text.split('/')[-1]
                #print "  myEntryIdStr = %s" % myEntryIdStr

                if playlistTitle == myEntryTitle:
                    playlistToUse = myEntry
                    break

            if playlistToUse is None:
                # Create the playlist if it was not found
                # Returns: The YouTubePlaylistEntry if successfully posted.
                playlistToUse = youtubeClient.AddPlaylist(playlistTitle,
                                    playlistTitle, playlist_private=False)

        """
        Note: YouTube has description playlists of at max 5000 characters.
        Picasa has album descriptions of max 1000 characters.
        """
        playlistDescription = ""
        #newPlaylistDescription = "Alarm: motion degree... audio degree... %s." % cmd
        newPlaylistDescription = cmd

        playlistToUse = None

        """
        Sometimes it doesn't find a playlist even if it is present 
            (is youtubeClient.GetYouTubePlaylistFeed() returning an invalid
            result) in the first few ones), so we retry a few times.
        """
        NUM_RETRIES_READ_PLAYLISTS = 3

        for myRetry in range(NUM_RETRIES_READ_PLAYLISTS):
            """
            !!!!We require the YouTube alias/nickname which can be different to
                the Google username!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

            #feed = youtubeClient.GetYouTubePlaylistFeed(username="MultiEnder123")
            #                                               username='ender123')
            """
            #TODO!!!!You need to get all playlists - I think it returns only first 25
            feed = youtubeClient.GetYouTubePlaylistFeed()

            # Returns: A YouTubePlaylistFeed if successfully retrieved.
            #print "DownloadCommandsFromYouTube(): feed = %s" % str(feed)
            #print "feed.entry[0] = %s" % str(feed.entry[0])

            for myEntry in feed.entry:
                myEntryTitle = myEntry.title.text
                #print "myEntryTitle = %s" % myEntryTitle

                #myEntry.id.text = http://gdata.youtube.com/feeds/api/users/MultiEnder123/playlists/3FD3773F7AC5DD1E
                #myEntry.id = <xml>...
                myEntryIdStr = myEntry.id.text.split("/")[-1]
                #print "  myEntryIdStr = %s" % myEntryIdStr

                if myEntryTitle == playlistTitle:
                    common.DebugPrint(
                        "SendCommandViaYouTube(): Feed matched " \
                            "myEntry = %s\n" % str(myEntry) + \

                        "SendCommandViaYouTube(): " \
                            "myEntry.content = %s\n" % str(myEntry.content) + \

                        "SendCommandViaYouTube(): " \
                            "myEntry.description = %s" % \
                                str(myEntry.description))

                    #playlistDescription = myEntry.description.split("/")[-1]
                    playlistDescription = str(myEntry.description).split( \
                                                ">")[-2].split("</")[0]
                    #"""
                    patternNoCmd = '<ns0:description xmlns:ns0=' \
                                    '"http://gdata.youtube.com/schemas/2007"'

                    if playlistDescription.find(patternNoCmd) != -1:
                        common.DebugPrint(
                            "SendCommandViaYouTube(): This is not a " \
                            "command, just an empty description.")
                        playlistDescription = ""
                    """
                    else:
                        common.DebugPrint(
                            "SendCommandViaYouTube(): This is a real command.")
                    """

                    common.DebugPrint("SendCommandViaYouTube(): " \
                                "playlistDescription = %s" % \
                                str(playlistDescription))

                    playlistToUse = myEntry

                    break
            """
            else:
                # Executed only if break was not used.
                continue
            break
            """
            if playlistToUse != None:
                break

        if playlistToUse is None:
            # "Creating it."
            common.DebugPrint(
                "SendCommandViaYouTube(): Couldn't find YouTube " \
                        "playlist %s." % playlistTitle)

            if False:
                # Create the playlist if it was not found
                # Returns: The YouTubePlaylistEntry if successfully posted.
                playlistToUse = youtubeClient.AddPlaylist(playlistTitle,
                            newPlaylistDescription, playlist_private=False)
                myEntryIdStr = playlistToUse.id.text.split("/")[-1]
        else:
            # If the description is not empty, we wait for it to be processed.
            """
            common.DebugPrint(
                "SendCommandViaYouTube(): playlistDescription = %s" % \
                                                    str(playlistDescription))
            """

            if len(playlistDescription) != 0:
                common.DebugPrint(
                    "SendCommandViaYouTube(): Already the playlist " \
                        "has playlistDescription = %s, so we do not " \
                        "send another command." % (str(playlistDescription)))
                return

            if False:
                if len(newPlaylistDescription) + len(playlistDescription) < 5000:
                    playlistDescription += newPlaylistDescription
                else:
                    playlistDescription = newPlaylistDescription
            else:
                playlistDescription = newPlaylistDescription

            #if playlistDescription != "":
            youtubeClient.UpdatePlaylist(playlist_id=myEntryIdStr,
                                new_playlist_title=playlistTitle,
                                new_playlist_description=playlistDescription,
                                playlist_private=True, username="default")

        #return playlistDescription

        if False:
            newVideoEntry = None #!!!!
            # It seems this info is not used!
            aVideoTitle = ""

            # It seems this info is not used!
            aVideoDescription = ""

            playlistURI = playlistToUse.feed_link[0].href
            #!!!!!!!!!!!!!Maybe required
            #time.sleep(10)
            response = youtubeClient.AddPlaylistVideoEntryToPlaylist(
                        playlistURI,
                        newVideoEntry.id.text.split('/')[-1],
                        aVideoTitle, aVideoDescription)

            """
            newVideoEntry = youtubeClient.InsertVideoEntry(videoEntry,
                                                            pathFileName)
            """
    except:
        common.DebugPrintErrorTrace()

    """
    common.DebugPrint("Exiting SendCommandViaYouTube() at %s." % \
                    GetCurrentDateTimeStringWithMilliseconds())
    """


def ComputeDeltaBetweenTimes(tupleSourceTime, tupleTargetTime):
    if tupleSourceTime[0] < 1970: #or > 2050??
        common.DebugPrint(
            "ComputeDeltaBetweenTimes(): Not continuing because " \
                    "tupleSourceTime = %s" % str(tupleSourceTime))
        return 0

    # Original (Source/Wrong) time:
    #(2006, 1, 5, 11, 18, 33, 0) #(2012, 06, 26, 19, 46, 00, 000)
    (tm_year, tm_mon, tm_mday, tm_hour, tm_min, tm_sec, numMilliseconds) = \
                                                            tupleSourceTime

    """
    From http://www.tutorialspoint.com/python/time_mktime.htm
     The last 3 parameters are tm_wday, tm_yday, tm_isdst
    """
    sourceTime = time.mktime( (tm_year, tm_mon, tm_mday,
                                        tm_hour, tm_min, tm_sec, -1, -1, -1) )

    #print btMediaTimeAux - btMediaTimeAux

    (tm_year, tm_mon, tm_mday, tm_hour, tm_min, tm_sec, numMilliseconds) = \
                                                            tupleTargetTime

    if True:
        # The last 3 parameters are tm_wday, tm_yday, tm_isdst
        targetTime = time.mktime( (tm_year, tm_mon, tm_mday,
                                    tm_hour, tm_min, tm_sec, -1, -1, -1) )
    else:
        targetTime = time.time()

    #print sourceTime
    #print time.time()
    numSecs = targetTime - sourceTime + TIME_DIFFERENCE

    common.DebugPrint(
        "ComputeDeltaBetweenTimes(): Num seconds = %d\n" % numSecs + \
        "ComputeDeltaBetweenTimes(): Num years = %.3f\n" % \
                                            (numSecs / (3600 * 24 * 365.25)) )

    """
    crtTime = time.localtime()
    print sourceTime - crtTime

    sourceTime = time.localtime(sourceTime)
    print time.strftime("%Y_%m_%d_%H_%M_%S", sourceTime)
    """

    """
    # Destination (Good) time:
    #(tm_year, tm_mon, tm_mday, tm_hour, tm_min, tm_sec, numMilliseconds) = \
    #                                       (2011, 05, 29, 00, 04, 30, 100)

    (tm_year, tm_mon, tm_mday, tm_hour, tm_min, tm_sec, numMilliseconds) = \
                                            (2012, 06, 27, 03, 11, 00, 000)

    # The last 3 parameters are tm_wday, tm_yday, tm_isdst
    btMediaTimeAux2 = time.mktime( (tm_year, tm_mon, tm_mday,
                                    tm_hour, tm_min, tm_sec, -1, -1, -1) )

    btMediaTime2 = time.localtime(btMediaTimeAux2)
    print time.strftime("%Y_%m_%d_%H_%M_%S", btMediaTime2)

    print btMediaTimeAux2 - btMediaTimeAux
    """
    return numSecs


def SynchronizeTimePhoneWithYouTube(youtubeClient, deviceId, videoTitle,
                                            publishedTime, durationVideo):
    global lastTimeCommandSent

    common.DebugPrint(
        "Entered SynchronizeTimePhoneWithYouTube(): deviceId = %s, " \
                "videoTitle = %s, publishedTime = %s, durationVideo = %s" % \
                (deviceId, videoTitle, publishedTime, durationVideo))

    common.DebugPrint(
        "SynchronizeTimePhoneWithYouTube(): lastTimeCommandSent = %s" % \
                                                (str(lastTimeCommandSent)))

    if deviceId in lastTimeCommandSent:
        deltaTime = time.time() - lastTimeCommandSent[deviceId]

        common.DebugPrint(
            "SynchronizeTimePhoneWithYouTube(): deltaTime = %d" % deltaTime)

        if deltaTime < HOW_MUCH_TIME_TO_PASS_FROM_LAST_SYNC_COMMAND_TO_ISSUE_A_NEW_ONE:
            common.DebugPrint(
                "SynchronizeTimePhoneWithYouTube(): not continuing " \
                        "because from last time treated deviceId = %s, " \
                        "it passed only %d seconds." % (deviceId, deltaTime))
            return

    lastTimeCommandSent[deviceId] = time.time()

    playlistTitle = "iCam_cmd_" + deviceId

    """
    !!!!We should use instead of video title the time in
        ytVideoEntryAux.media.description.text,
        and then we don't need to use the duration (+ an epsilon)
    """
    tokens = videoTitle.split("_")
    sourceTime = (int(tokens[0]), int(tokens[1]), int(tokens[2]),
                    int(tokens[3]), int(tokens[4]), int(tokens[5]), 0)

    common.DebugPrint(
        "SynchronizeTimePhoneWithYouTube(): sourceTime = %s " % str(sourceTime))

    #Video description: 15:46:14.0 14-06-2012 668066806680668, 0

    """
    #!!!!QUITE IMPORTANT: Parse properly the publishedTime string and in case
       it is with Z --> UTC+0, in case it is with UTC-x handle it accordingly.
    """
    if publishedTime[len(publishedTime) - 1] == "Z":
        publishedTime = publishedTime[ : len(publishedTime) - 1]

    # This is the delimiter for date and time.
    tokens = publishedTime.split("T")
    tokens1 = tokens[0].split("-")
    tokens2 = tokens[1].split(":")
    tokens3 = tokens2[2].split(".")
    targetTime = (int(tokens1[0]), int(tokens1[1]), int(tokens1[2]),
                    int(tokens2[0]), int(tokens2[1]), int(tokens3[0]),
                    int(tokens3[1]))

    common.DebugPrint(
        "SynchronizeTimePhoneWithYouTube(): targetTime = %s + %d " \
        "hours to account for present time zone." % (str(targetTime),
        TIME_DIFFERENCE))

    """
    print ComputeDeltaBetweenTimes((2006, 1, 5, 11, 18, 33, 0),
                                   (2012, 06, 26, 19, 46, 00, 000))

    numSecs = ComputeDeltaBetweenTimes(
               tupleSourceTime=(2006, 1, 5, 11, 18, 33, 0),
               tupleTargetTime = (2012, 06, 26, 19, 46, 00, 000))
    """
    numSecs = ComputeDeltaBetweenTimes(tupleSourceTime=sourceTime, \
                                        tupleTargetTime=targetTime)

    """
    We could subtract also 1-2 more secs to account for the delay of
                       starting video rec which can occur.
    """
    numSecs -= durationVideo

    if True:
    #if False:
        if abs(numSecs) > 60:
            """
            !!!!Do more ellaborate: save in settings.pkl the phone/BT
                    Mode[deviceId].
            """
            if deviceId == "668066806680668":
                """
                #!!!!We must receive on YT the time N82 received the
                #       BT msg from 6680.

                SendCommandViaYouTube(playlistTitle,
                    "send-command-via-bluetooth 66:80:66:80:66:80 " \
                    "adjust-date-and-time-using-delta %d" % numSecs)
                """
                pass
            elif deviceId == "N82N82N82N82N82":
                SendCommandViaYouTube(youtubeClient, playlistTitle,
                            "adjust-date-and-time-using-delta %d" % numSecs)



GetDeltaTimeZoneRelatedToUTC()

if __name__ == "__main__":
    print "time.time() = %s" % str(time.time())

    print ComputeDeltaBetweenTimes(
                    tupleSourceTime=(1960, 1, 1, 0, 0, 0, 0),
                    tupleTargetTime=(2012, 06, 26, 19, 46, 00, 000))

    """
    SynchronizeTimePhoneWithServer()
    SynchronizeTimePhoneWithYouTube("N82N82N82N82N82",
           "2012_06_14_15_45_42_000_0", "2012-06-14T12:48:56.000Z", 30)
    """
    pass
