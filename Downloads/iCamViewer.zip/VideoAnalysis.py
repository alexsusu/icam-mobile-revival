import common

#!/usr/bin/python
#import urllib2
import sys
import time
from math import cos, sin

import os
import subprocess
import shutil
import traceback
import urllib

try:
    import cv
except:
    common.DebugPrint(
        "It seems you don't have installed the Python OpenCV bindings, " \
        "so can't use OpenCV for video analysis.")
    common.DebugPrintErrorTrace()



CLOCKS_PER_SEC = 1.0
MHI_DURATION = 1
MAX_TIME_DELTA = 0.5
MIN_TIME_DELTA = 0.05
N = 4

buf = range(10) 
last = 0
mhi = None # MHI
orient = None # orientation
mask = None # valid orientation mask
segmask = None # motion segmentation map
storage = None # temporary storage

motionFactor = 0.0
motionFactorPerFrame = -1.0

def update_mhi(img, dst, diff_threshold):
    global motionFactor

    global last
    global mhi
    global storage
    global mask
    global orient
    global segmask
    timestamp = time.clock() / CLOCKS_PER_SEC # get current time in seconds
    size = cv.GetSize(img) # get current frame size
    idx1 = last

    if not mhi:
        firstFrame = True
    else:
        firstFrame = False

    if not mhi or cv.GetSize(mhi) != size: #First frame OR different frame size
        for i in range(N):
            buf[i] = cv.CreateImage(size, cv.IPL_DEPTH_8U, 1)
            cv.Zero(buf[i])
        mhi = cv.CreateImage(size, cv.IPL_DEPTH_32F, 1)
        cv.Zero(mhi) # clear MHI at the beginning
        orient = cv.CreateImage(size, cv.IPL_DEPTH_32F, 1)
        segmask = cv.CreateImage(size, cv.IPL_DEPTH_32F, 1)
        mask = cv.CreateImage(size, cv.IPL_DEPTH_8U, 1)
    
    cv.CvtColor(img, buf[last], cv.CV_BGR2GRAY) # convert frame to grayscale
    idx2 = (last + 1) % N # index of (last - (N-1))th frame
    last = idx2
    silh = buf[idx2]
    cv.AbsDiff(buf[idx1], buf[idx2], silh) # get difference between frames
    cv.Threshold(silh, silh, diff_threshold, 1, cv.CV_THRESH_BINARY) # and threshold it
    cv.UpdateMotionHistory(silh, mhi, timestamp, MHI_DURATION) # update MHI
    cv.CvtScale(mhi, mask, 255./MHI_DURATION,
                (MHI_DURATION - timestamp) * 255. / MHI_DURATION)
    cv.Zero(dst)
    cv.Merge(mask, None, None, None, dst)
    cv.CalcMotionGradient(mhi, mask, orient, MAX_TIME_DELTA, MIN_TIME_DELTA, 3)

    if not storage:
        storage = cv.CreateMemStorage(0)

    seq = cv.SegmentMotion(mhi, segmask, storage, timestamp, MAX_TIME_DELTA)

    for (area, value, comp_rect) in seq:
        if comp_rect[2] + comp_rect[3] > 1: #Alex: originally was 100 # reject very small components
            if (not firstFrame):
                motionFactor += comp_rect[2] + comp_rect[3]

            color = cv.CV_RGB(255, 0, 0)
            silh_roi = cv.GetSubRect(silh, comp_rect)
            mhi_roi = cv.GetSubRect(mhi, comp_rect)
            orient_roi = cv.GetSubRect(orient, comp_rect)
            mask_roi = cv.GetSubRect(mask, comp_rect)
            angle = 360 - cv.CalcGlobalOrientation(orient_roi, mask_roi, mhi_roi, timestamp, MHI_DURATION)

            count = cv.Norm(silh_roi, None, cv.CV_L1, None) # calculate number of points within silhouette ROI
            if count < (comp_rect[2] * comp_rect[3] * 0.05):
                continue

            magnitude = 30.
            center = ((comp_rect[0] + comp_rect[2] / 2), (comp_rect[1] + comp_rect[3] / 2))
            cv.Circle(dst, center, cv.Round(magnitude*1.2), color, 3, cv.CV_AA, 0)
            cv.Line(dst,
                    center,
                    (cv.Round(center[0] + magnitude * cos(angle * cv.CV_PI / 180)),
                     cv.Round(center[1] - magnitude * sin(angle * cv.CV_PI / 180))),
                    color, 3,
                    cv.CV_AA, 0)



myIndexList = 0
mediaFolderContent = None
def AlexInit():
    global myIndexList, mediaFolderContent
    mediaFolderContent = os.listdir(common.VIDEO_ANALYSIS_MEDIA_FOLDER)
    #sortedMediaFolderContent = sorted(mediaFolderContent)

    """
    sort() without parameters is the ONLY one that works in Python 2.3.
        (Info on sort at http://wiki.python.org/moin/HowTo/Sorting/.)
    """
    mediaFolderContent.sort()

    #print mediaFolderContent
    myIndexList = 0


def AlexGetNextFrame():
    global myIndexList, mediaFolderContent

    if myIndexList == len(mediaFolderContent):
        return None
    try:
        image = cv.LoadImage(common.VIDEO_ANALYSIS_MEDIA_FOLDER + "/" + \
                                mediaFolderContent[myIndexList], 1)
    except:
        print "\n    Error when trying to open " + \
            common.VIDEO_ANALYSIS_MEDIA_FOLDER + "/" + \
            mediaFolderContent[myIndexList] + "."
        mediaFolderContent.pop(myIndexList)
        return AlexGetNextFrame()

    myIndexList += 1
    return image


def GetNumberFrames():
    global mediaFolderContent
    return len(mediaFolderContent)


def AnalyzeVideo(videoPathFileName, displayDifferences=True):
    global motionFactor
    global motionFactorPerFrame

    motionFactor = 0.0
    motionFactorPerFrame = -1.0

    #print "Deleting old frames."
    try:
        shutil.rmtree(common.VIDEO_ANALYSIS_MEDIA_FOLDER)
        #pass
    except:
        pass
    try:
        os.mkdir(common.VIDEO_ANALYSIS_MEDIA_FOLDER)
    except:
        pass

    common.DebugPrint("AnalyzeVideo(): Converting video to frames.")

    try:
        try:
            """
            "C:\Program Files\VideoLAN\VLC\vlc.exe"
                ../2010_12_26_15_43_15_000_0_birds_Tomita.3gp --intf=dummy
                --dummy-quiet  --video-filter=scene --vout=dummy
                --scene-format=png --scene-ratio=1 --scene-prefix=snap -
                scene-path=.\ vlc://quit

            subprocess.call(['C:/Program Files/VideoLAN/VLC/vlc.exe', \
                videoPathFileName, '--intf=dummy', '--dummy-quiet', \
                '--video-filter=scene', '--vout=dummy', '--scene-format=png', \
                '--scene-ratio=1', '--scene-prefix=snap', \
                '--scene-path=.\\1\\', 'vlc://quit'])

            subprocess.call(['C:/Program Files/VideoLAN/VLC/vlc.exe', \
                videoPathFileName, '--intf=dummy', '--dummy-quiet', \
                '--video-filter=scene', '--vout=dummy', '--scene-format=png', \
                '--scene-ratio=1', '--scene-prefix=snap', \
                '--scene-path=' + common.VIDEO_ANALYSIS_MEDIA_FOLDER, \
                'vlc://quit'])

            subprocess.call(["C:/Program Files/VideoLAN/VLC/vlc.exe", \
                videoPathFileName, "--intf=dummy", "--dummy-quiet", \
                "--video-filter=scene", "--vout=dummy", "--scene-format=bmp", \
                "--scene-ratio=1", "--scene-prefix=snap",
                "--scene-path=" + common.VIDEO_ANALYSIS_MEDIA_FOLDER, \
                "--noaudio", "vlc://quit"])
            """
            subprocess.call([common.VLC_EXECUTABLE_PATH_FILENAME, \
                videoPathFileName, "--intf=dummy", "--dummy-quiet", \
                "--video-filter=scene", "--vout=dummy", "--scene-format=bmp", \
                "--scene-ratio=1", "--scene-prefix=snap", \
                "--scene-path=" + common.VIDEO_ANALYSIS_MEDIA_FOLDER, \
                "--noaudio", "vlc://quit"])
        except:
            common.DebugPrint(
                "AnalyzeVideo(): Exception when trying to convert " \
                    "video %s to frames in %s." % (videoPathFileName, \
                                        common.VIDEO_ANALYSIS_MEDIA_FOLDER))
            common.DebugPrintErrorTrace()

        AlexInit()
        if GetNumberFrames() == 0:
            common.DebugPrint(
                "AnalyzeVideo(): GetNumberFrames() == 0 --> bailing out.")
            return

        motion = 0
        capture = 0

        """
        print "I'm here 0"
        if len(sys.argv)==1:
            capture = cv.CreateCameraCapture(0)
        elif len(sys.argv)==2 and sys.argv[1].isdigit():
            capture = cv.CreateCameraCapture(int(sys.argv[1]))
        elif len(sys.argv)==2:
            print "I'm here 0.5"
            sys.stdout.flush()
            capture = cv.CreateFileCapture(sys.argv[1]) 
            #capture = cv.CaptureFromFile(sys.argv[1]) 
            print "I'm here 0.7"
            sys.stdout.flush()

        if not capture:
            print "Could not initialize capturing..."
            sys.exit(-1)
        """
            
        #What about the first frame?!!!!!!!!!!!!!!!!!

        global last
        global mhi
        global storage
        global mask
        global orient
        global segmask

        buf = range(10) 
        last = 0
        mhi = None # MHI
        orient = None # orientation
        mask = None # valid orientation mask
        segmask = None # motion segmentation map
        storage = None # temporary storage



        #print "I'm here 1"
        if (displayDifferences):
            cv.NamedWindow("Motion", 1)
            cv.NamedWindow("Original", 1)

        while True:
            #image = cv.QueryFrame(capture)
            image = AlexGetNextFrame()

            #print "image =", image
            if image:
                if not motion:
                    motion = cv.CreateImage((image.width, image.height), 8, 3)
                    cv.Zero(motion)
                    #motion.origin = image.origin

                #update_mhi(image, motion, 30)
                update_mhi(image, motion, 30)

                if displayDifferences:
                    cv.ShowImage("Motion", motion)
                    cv.ShowImage("Original", image)

                #time.sleep(0.1)
                #"""
                if displayDifferences:
                    # If I take out it doesn't display the image :)))))))) !
                    if cv.WaitKey(10) != -1:
                        break
                #"""
            else:
                break

        if displayDifferences:
            cv.DestroyWindow("Motion")
            cv.DestroyWindow("Original")

        motionFactorPerFrame = motionFactor / GetNumberFrames()
        print "motionFactor = %f, number frames = %d, " \
            "motionFactorPerFrame = %f" % (motionFactor, GetNumberFrames(), \
                                            motionFactorPerFrame)
    except:
        common.DebugPrintErrorTrace()


"""
import re
myRE = re.compile(r'Alex')
"""
def ReadList():
    for line in open("MediaFileList_HP_DV2.js"):
        #if not myRE.search(line):
        #print line,
        """
        videoArray1.push(
            ['http://mobile-revival.110mb.com/ReVival/668066806680668/Media/2011/01/16/2011_01_16_00_52_35_000_1.3gp', \
            'information', '00:52:51 16-01-2011 ( bytes)']);
        """
        if line.find("( bytes)") == -1:
            #print line
            tokensLine = line.split("', ")
            index = tokensLine[0].find("http://")
            URL = tokensLine[0][index : ]
            print URL,
            sys.stdout.flush()
            
            myIndex1 = tokensLine[2].find("(")
            myIndex2 = tokensLine[2].find(" bytes")
            fileSize = int(tokensLine[2][myIndex1 + 1: myIndex2])
            #print fileSize
            #break

            rIndex = URL.rfind("/")
            fileName = URL[rIndex + 1: ]
            #print "fileName = %s" % fileName

            tokensFileName = fileName.split("_")
            hour = int(tokensFileName[3])
            minute = int(tokensFileName[4])
            #print "Hour = %d, minute = %d." % (hour, minute)

            if (hour > 6) and (hour < 18): #, tokensFileName[4])
                assert common.DownloadFile(URL, fileName, fileSize) == 0
                AnalyzeVideo(fileName)



if __name__ == "__main__":
    #DownloadFile('http://mobile-revival.110mb.com/ReVival/668066806680668/Media/2011/01/16/2011_01_16_00_36_39_000_1.3gp')
    if False:
    #if True:
        ReadList()
    else:
        #AnalyzeVideo("2011_01_01_14_53_57_000_1.3gp")
        #AnalyzeVideo("2011_01_12_15_51_09_000_1.3gp")
        #AnalyzeVideo("tNTJCP0Wap8.flv")
        #AnalyzeVideo("kIlLhNqdtG4.flv")
        #AnalyzeVideo("2pVEPeGaaMs.flv")
        AnalyzeVideo("VBBAXEBQfbE.flv")
