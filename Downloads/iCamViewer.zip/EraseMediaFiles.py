import common
import ctypes
import os
import platform
import sys
#import time
import traceback
import PhoneNumbers




#AT_LEAST_FREE_DRIVESPACE_TO_STOP = 20000 * 1024 * 1024
AT_LEAST_FREE_DRIVESPACE_TO_STOP = 1500 * 1024 * 1024
#FREE_DRIVESPACE_TO_STOP_TRIGGER = 20000 * 1024 * 1024
FREE_DRIVESPACE_TO_START = 1000 * 1024 * 1024 #20000 * 1024 * 1024


WINDOWS_OS = (platform.system() == "Windows")

def GetFreeDriveSpace(aDriveStr):
    if WINDOWS_OS:
        """ Return folder/drive free space (in bytes)
        """
        # From http://stackoverflow.com/questions/51658/cross-platform-space-remaining-on-volume-using-python

        free_bytes = ctypes.c_ulonglong(0)
        ctypes.windll.kernel32.GetDiskFreeSpaceExW( \
                            ctypes.c_wchar_p(aDriveStr), None, None, \
                            ctypes.pointer(free_bytes))

        common.DebugPrint( \
            "GetFreeDriveSpace(): free_bytes.value = %d" % \
                                            free_bytes.value)

        return free_bytes.value
    else:
        return os.statvfs(aDriveStr).f_bfree
    #return -1

    """
    MacOS (probably UNIX):
    From http://stackoverflow.com/questions/787776/find-free-disk-space-in-python-on-os-x
            (see also http://ubuntuforums.org/showthread.php?t=961505):

    s = os.statvfs('/')
    print (s.f_bavail * s.f_frsize) / 1024
    """


"""
        folderContent = os.listdir(pathFolderName)

        # Use reverse = False to send first the oldest ones (like this you
        #   send in chronological order). Use reverse = True for sending first
        #   the most recent ones.
        #sortedFolderContent = sorted(folderContent, reverse = False)

        # sort() without parameters is the ONLY one that works in Python 2.2.
        #    (Info on sort at http://wiki.python.org/moin/HowTo/Sorting/.)
        folderContent.sort()
"""
def EraseOldestFilesFromFolder(aFolder, atLeastFreeDrivespaceToStop):
    if (GetFreeDriveSpace(aFolder[:2]) >= atLeastFreeDrivespaceToStop):
        return

    if common.MY_DEBUG_STDOUT:
        print "EraseOldestFilesFromFolder(): aFolder = %s" % aFolder
        sys.stdout.flush()

    try:
        if not os.path.exists(aFolder):
            if common.MY_DEBUG_STDOUT:
                print "EraseOldestFilesFromFolder(): aFolder %s does NOT " \
                    "exist. Bailing out..." % aFolder
                sys.stdout.flush()
            return

        #return

        mediaFolderContent2 = os.listdir(aFolder)
        """
        if len(mediaFolderContent) == 0:
            return
        """

        
        """
        common.DebugPrint(
            "EraseOldestMediaFiles(): mediaFolderContent2 = %s" % \
                                            str(mediaFolderContent2))
        """

        mediaFolderContent = []
        for elem in mediaFolderContent2:
            pathFileName = aFolder + "/" + elem
            if os.path.isfile(pathFileName):
                # Sort after access time the files in the folder.
                #mediaFolderContent.append( (elem, os.path.getctime(pathFileName)) )
                mediaFolderContent.append( (elem, os.path.getmtime(pathFileName)) )

                #print mediaFolderContent[len(mediaFolderContent) - 1]
                #common.DebugPrint(str(elem, os.path.getctime(pathFileName))))
            #print mediaFolderContent
        #print mediaFolderContent

        #print mediaFolderContent

        #sortedMediaFolderContent = sorted(mediaFolderContent)
        sortedMediaFolderContent = sorted(mediaFolderContent, \
                                            key=lambda myTuple: myTuple[1])
        """
        The list has the files sorted in increasing chronoligical order.
        We remove from this list (which we will erase from disk) the most recently created files - probably a .flv and .rep files.
        """
        #See http://docs.python.org/tutorial/datastructures.html
        try:
            howManyElems = len(sortedMediaFolderContent)
            if howManyElems > 8:
                howManyElems = 8

            for index in range(howManyElems):
            #for index in range(8):
                sortedMediaFolderContent.pop()
        except:
            if common.MY_DEBUG_STDERR:
                traceback.print_exc()
                sys.stderr.flush()

        """
        sort() without parameters is the ONLY one that works in Python 2.2.
            (Info on sort at http://wiki.python.org/moin/HowTo/Sorting/.)
        """
        #mediaFolderContent.sort()
        #sortedMediaFolderContent = mediaFolderContent

        print "len(sortedMediaFolderContent) = %d, " \
            "sortedMediaFolderContent = %s" % (len(sortedMediaFolderContent), \
                                                str(sortedMediaFolderContent))

        #return

        for mediaFileName in sortedMediaFolderContent:
            pathFileName = aFolder + "/" + mediaFileName[0]
            if os.path.isfile(pathFileName):
                """
                print "os.path.getmtime(pathFileName) = %s" % \
                    str(os.path.getmtime(pathFileName))
                print "os.path.getctime(pathFileName) = %s" % \
                    str(os.path.getctime(pathFileName))

                myTime = os.path.getctime(pathFileName)

                print time.strftime("%m/%d/%Y %I:%M:%S %p", \
                                        time.localtime(myTime))

                common.DebugPrint(
                    "EraseOldestMediaFiles(): deleting file %s." % \
                                                        pathFileName)

                if GetFreeDriveSpace(aFolder[:2]) >= atLeastFreeDrivespaceToStop:
                    return
                """

                if pathFileName.lower().find("flv") == -1:
                #mediaFileName[0]
                    common.DebugPrint(
                        "EraseOldestMediaFiles(): filename does not " \
                            "contain .flv.")
                    continue

                common.DebugPrint(
                    "EraseOldestMediaFiles(): deleting file %s with " \
                        "os.path.getctime(pathFileName) = %.2f." % \
                            (pathFileName, os.path.getctime(pathFileName)))

                os.unlink(pathFileName)

                if GetFreeDriveSpace(aFolder[:2]) >= atLeastFreeDrivespaceToStop:
                    return
    except:
        common.DebugPrintErrorTrace()

        exceptionType, exceptionValue, exceptionTraceback = sys.exc_info()
        myText = "Exception in EraseOldestFilesFromFolder() - details: " \
            "exceptionTraceback = %s, exceptionType = %s, " \
            "exceptionValue = %s." % \
            ( repr(traceback.format_tb(exceptionTraceback)), \
                str(exceptionType), str(exceptionValue) )
        common.DebugPrint(myText)


def Main():
    if GetFreeDriveSpace(".") < FREE_DRIVESPACE_TO_START:
        #print get_free_space("Z:\\")
        #EraseOldestFilesFromFolder("Z:\\1PhD\\ReVival\\iCamViewer\\Media", \
        #   AT_LEAST_FREE_DRIVESPACE_TO_STOP)

        """
        for aDir in ["612061206120612", "E7E7E7E7E7E7E7E", \
                        "35598001238745601", "668066806680668", \
                        "N95N95N95N95N95", "N82N82N82N82N82"]: #".",
        """
        #for aDir in ["."]:
        for deviceId in PhoneNumbers.phoneInfo:
            #print "deviceId =", deviceId
            EraseOldestFilesFromFolder(deviceId, \
                                        AT_LEAST_FREE_DRIVESPACE_TO_STOP)
            #return
        #EraseOldestFilesFromFolder(".", AT_LEAST_FREE_DRIVESPACE_TO_STOP)

if __name__ == "__main__":
    Main()
