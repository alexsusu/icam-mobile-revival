import ctypes
import common
import Settings
import UI
import thread
import vlc

if common.MY_PYSIDE:
    from PySide import QtCore, QtGui
elif common.MY_PYQT:
    from PyQt4 import Qt
    # For Dialog
    from PyQt4 import QtCore, QtGui


VLC_2_X = True



#!!!!TODO: inherit instead from QtGui.QMainWindow from LC_ancestor(QtGui.QMainWindow, QtGui.QDialog) and adapt also the inheritances of the classes inheriting this one
class View(object): #QtCore.QObject): #QtGui.QMainWindow):
    #!!!!TODO: use global indexVideo instead of self.prepareVideo_indexVideo, etc
    # These vars are static, but each class in the inheritance tree has its OWN copy (it seems)
    prepareVideo_indexVideo = None
    prepareVideo_pathFileName = None
    prepareVideo_aVlcVideo = None

    """
    This method is called through a Qt signal, which has a precise signature,
        so we cannot pass to it arbitrary arguments.
        Therefore, these arguments are passed through object vars.
    """
    def PrepareVideo(self): #, indexVideo, pathFileName, aVlcVideo):
        indexVideo = self.prepareVideo_indexVideo
        pathFileName = self.prepareVideo_pathFileName
        aVlcVideo = self.prepareVideo_aVlcVideo

        common.DebugPrint(
            "Entered PrepareVideo(): indexVideo = %s" % str(indexVideo))

        common.DebugPrint(
            #"PrepareVideo(): " \
            #    "threading.currentThread() = %s\n" % \
            #    str(threading.currentThread()) + \
            "PrepareVideo(): " \
                "thread.get_ident() = %d" % thread.get_ident())

        try:
            """
            !!!!Check if int(aVlcVideo.winId()) returns RuntimeError, and if so
                don't try playing the video anymore
            """

            """
            This needs to be created every time, otherwise a standalone VLC
                window is created...
            """
            alreadyCreated = False

            """
            Following the example from 
                http://www.marshut.com/xnhnq/strange-behavior-with-sub-sources-i-can-show-custom-marquee-while-playing-yet-not-in-transcode-section.html
              it turns out that in VLC 2.x you cannot pass the parameters to
                UI.instance[indexVideo].media_new()
              as we did to VLC 1.x,
              but directly to the vlc.Instance() - see below.
            
            """
            if UI.instance[indexVideo] == None:
                if VLC_2_X:
                    if Settings.myCfg.rotateDegrees[indexVideo] == 0:
                        UI.instance[indexVideo] = vlc.Instance(
                            "--no-video-title-show",
                            #"--sub-filter=marq{marquee=Playing}", # Not working
                            #"--sub-filter=marq", # Not working
                            #"--marq-marquee alalalal", # Not working
                            #"--sub-filter=marq@test{marquee=Playing}",
                            "--video-filter=adjust",
                            "--brightness=%.2f" % Settings.myCfg.brightness[indexVideo],
                            "--contrast=%.2f" % Settings.myCfg.contrast[indexVideo],
                            "--hue=%.2f" % Settings.myCfg.hue[indexVideo],
                            "--saturation=%.2f" % Settings.myCfg.saturation[indexVideo],
                            "--gamma=%.2f" % Settings.myCfg.gamma[indexVideo]
                        )
                    else:
                        # Inspired from http://www.marshut.com/xnhnq/strange-behavior-with-sub-sources-i-can-show-custom-marquee-while-playing-yet-not-in-transcode-section.html
                        #print "Alex: doing this"
                        UI.instance[indexVideo] = vlc.Instance( \
                            "--video-filter=adjust",
                            #"--brightness=0.2",
                            "--brightness=%.2f" % Settings.myCfg.brightness[indexVideo],
                            "--contrast=%.2f" % Settings.myCfg.contrast[indexVideo],
                            "--hue=%.2f" % Settings.myCfg.hue[indexVideo],
                            "--saturation=%.2f" % Settings.myCfg.saturation[indexVideo],
                            "--gamma=%.2f" % Settings.myCfg.gamma[indexVideo],

                            "--video-filter=transform",
                            #"--transform-type=90")
                            "--transform-type=%d" % Settings.myCfg.rotateDegrees[indexVideo])
                else:
                    UI.instance[indexVideo] = vlc.Instance()

                common.DebugPrint(
                    "PrepareVideo(): indexVideo = %d, " \
                        "myCfg.rotateIndex[indexVideo] = %d." % \
                        (indexVideo, Settings.myCfg.rotateDegrees[indexVideo]))

                """
                common.DebugPrint(
                    "PrepareVideo(): indexVideo = %d, " \
                    "rotateVal[Settings.myCfg.rotateIndex[indexVideo]] = %s." % \
                    (indexVideo,
                        rotateVal[Settings.myCfg.rotateIndex[indexVideo]]))
                """

                if VLC_2_X:
                    UI.media[indexVideo] = \
                        UI.instance[indexVideo].media_new( \
                                            pathFileName, "sub-filter=marq")
                else:
                    #if Settings.myCfg.rotateIndex[indexVideo] == 0:
                    if Settings.myCfg.rotateDegrees[indexVideo] == 0:
                        """
                        For 0 degrees we don't use for VLC "transform-type=0" because it
                            seems it actually does 90 degrees...

                        UI.media[indexVideo] = UI.instance[indexVideo].media_new(pathFileName,
                                "no-video-title-show", "sub-filter=marq{marquee=Playing}",
                                "video-filter=adjust",
                                "brightness=%.2f" % Settings.myCfg.brightness[indexVideo],
                                "contrast=%.2f" % Settings.myCfg.contrast[indexVideo],
                                "hue=%.2f" % Settings.myCfg.hue[indexVideo],
                                "saturation=%.2f" % Settings.myCfg.saturation[indexVideo],
                                "gamma=%.2f" % Settings.myCfg.gamma[indexVideo])
                        """
                        UI.media[indexVideo] = UI.instance[indexVideo].media_new(
                            pathFileName,
                            "no-video-title-show",
                            "sub-filter=marq{marquee=Playing}",
                            "video-filter=adjust",
                            "brightness=%.2f" % Settings.myCfg.brightness[indexVideo],
                            "contrast=%.2f" % Settings.myCfg.contrast[indexVideo],
                            "hue=%.2f" % Settings.myCfg.hue[indexVideo],
                            "saturation=%.2f" % Settings.myCfg.saturation[indexVideo],
                            "gamma=%.2f" % Settings.myCfg.gamma[indexVideo]
                        )
                    else:
                        """
                        UI.media[indexVideo] = UI.instance[indexVideo].media_new(pathFileName,
                                "no-video-title-show", "vout-filter=transform",
                                "transform-type=%s" % \
                                rotateVal[Settings.myCfg.rotateIndex[indexVideo]])

                        crop=default

                        UI.media[indexVideo] = UI.instance[indexVideo].media_new(pathFileName,
                                "no-video-title-show", "crop=4:3", "vout-filter=transform",
                                "transform-type=%d" % \
                                        Settings.myCfg.rotateDegrees[indexVideo],
                                "video-filter=adjust",
                                "brightness=%.2f" % Settings.myCfg.brightness[indexVideo],
                                "contrast=%.2f" % Settings.myCfg.contrast[indexVideo],
                                "hue=%.2f" % Settings.myCfg.hue[indexVideo],
                                "saturation=%.2f" % Settings.myCfg.saturation[indexVideo],
                                "gamma=%.2f" % Settings.myCfg.gamma[indexVideo])
                        """
                        common.DebugPrint("PrepareVideo(): case != 0 degrees")

                        # The options don't work from VLC 2.x, on my Win
                        UI.media[indexVideo] = UI.instance[indexVideo].media_new(
                            pathFileName,
                            "no-video-title-show",
                            "video-filter=transform",
                            "transform-type=%d" % Settings.myCfg.rotateDegrees[indexVideo],
                            "video-filter=adjust",
                            "brightness=%.2f" % Settings.myCfg.brightness[indexVideo],
                            "contrast=%.2f" % Settings.myCfg.contrast[indexVideo],
                            "hue=%.2f" % Settings.myCfg.hue[indexVideo],
                            "saturation=%.2f" % Settings.myCfg.saturation[indexVideo],
                            "gamma=%.2f" % Settings.myCfg.gamma[indexVideo])

                        if False: # Not working
                            UI.media[indexVideo] = UI.instance[indexVideo].media_new(
                                pathFileName,
                                #"video-filter=adjust",
                                #"brightness=0.2")
                                #"brightness=%.2f" % Settings.myCfg.brightness[indexVideo])
                                "video-filter=transform",
                                #"transform-type=90")
                                "transform-type=%d" % Settings.myCfg.rotateDegrees[indexVideo])

                        if False: # Not working
                            UI.media[indexVideo].add_options(
                                #"video-filter=invert",
                                "--video-filter=transform",
                                "--transform-type=90")

                #"vout-filter=invert"
                #"no-video-title-show", "video-title-timeout=10000"


                common.DebugPrint("PrepareVideo(): media[indexVideo] = %s" % \
                                                    str(UI.media[indexVideo]))

                """
                #!!!!TODO
                "c:\program files\videolan\vlc\vlc.exe" -I dummy
                    -v CurrentSymLink_1.3gp --vout-filter="gradient{type=0}"
                    --file-caching="20000" --rotate-angle=90
                    --sout="#transcode{vcodec=mp4v,vb=1024,scale=1,deinterlace,
                                        vfilter=rotate,acodec=mp4a,ab=192,channels=2}:
                                        standard{access=file,mux=mp4,dst=output.mp4}"

                "C:\Program Files\VideoLAN\VLC\vlc.exe" --vout-filter=transform
                    --transform-type=hflip output.mp4

                rem "C:\Program Files\VideoLAN\VLC\vlc.exe" --vout-filter
                    --transform-type 90 Z:\1PhD\ReVival\2010_05_06_18_33_08_1.3gp

                "C:\Program Files\VideoLAN\VLC\vlc.exe" --video-filter=adjust
                    --brightness=1.5 Z:\1PhD\ReVival\2010_05_06_18_33_08_1.3gp
                """
                UI.player[indexVideo] = UI.instance[indexVideo].media_player_new()

                common.DebugPrint("PrepareVideo(): player[indexVideo] = %s" % \
                                                    str(UI.player[indexVideo]))

                res = UI.player[indexVideo].set_media(UI.media[indexVideo])

                if True: # Not working
                #if False: # Not working
                    # Inspired from main of vlc.py
                    UI.player[indexVideo].video_set_marquee_int( \
                                            vlc.VideoMarqueeOption.Enable, 1)

                    UI.player[indexVideo].video_set_marquee_int( \
                        vlc.VideoMarqueeOption.Size, 24) # pixels

                    UI.player[indexVideo].video_set_marquee_int( \
                        vlc.VideoMarqueeOption.Position, \
                        vlc.Position.BottomRight)

                    # keep cursor on screen for 2.5 frames at most (24 fps movie)
                    # hence cursor vanishes if there is no data for some time
                    UI.player[indexVideo].video_set_marquee_int( \
                                            vlc.VideoMarqueeOption.Timeout, \
                                            0) # int(10 * 41)) # millisec, 0==forever

                    UI.player[indexVideo].video_set_marquee_int( \
                                            vlc.VideoMarqueeOption.Refresh, 1000) # millisec (or sec?)

                    # use a little cross/plus for the gaze location
                    UI.player[indexVideo].video_set_marquee_string( \
                                            vlc.VideoMarqueeOption.Text, \
                                            vlc.str_to_bytes("Playing text"))


                common.DebugPrint(
                    "PrepareVideo(): player[indexVideo].set_media() " \
                        "returned %s\n" % str(res) + \
                    "PrepareVideo(): aVlcVideo = %s" % str(aVlcVideo))

                """
                If we execute the following part in a different thread than the
                    main (UI) thread, the UI blocks.
                #return
                """
                if common.MY_PYSIDE:
                    # From http://www.expobrain.net/2011/02/22/handling-win32-windows-handler-in-pyside/:
                    ctypes.pythonapi.PyCObject_AsVoidPtr.restype = ctypes.c_void_p
                    ctypes.pythonapi.PyCObject_AsVoidPtr.argtypes = [ctypes.py_object]

                    """
                    From http://www.pyside.org/docs/pyside/PySide/QtGui/QWidget.html#PySide.QtGui.QWidget.winId:
                        "On X11 the type returned is long, on other platforms
                            it's a PyCObject."
                    """
                    hwnd = ctypes.pythonapi.PyCObject_AsVoidPtr(aVlcVideo.winId())
                elif common.MY_PYQT:
                    hwnd = int(aVlcVideo.winId())

                UI.player[indexVideo].set_hwnd(hwnd)

                res = aVlcVideo.show()

                common.DebugPrint(
                    "PrepareVideo(): aVlcVideo.show() returned %s" % str(res))
            else:
                UI.player[indexVideo].set_mrl(pathFileName)

                if False:
                    import random
                    pathFileNames = [
                        "2010_06_22_16_05_29_1.3gp",
                        "2010_11_06_19_39_36_0.3gp",
                        "1WF2gHYmuFg.flv",
                        "KLQrILG-iyk.mp4"
                    ]
                    UI.player[indexVideo].set_mrl(pathFileNames[random.randint(0, 3)]) #int(random.random() * 4)])
        except:
            common.DebugPrintErrorTrace()



    # These vars are static, but each class in the inheritance tree has its OWN copy (it seems)
    releaseVideo_indexVideo = None

    def ReleaseVideo(self):
        return

        try:
            indexVideo = self.releaseVideo_indexVideo

            common.DebugPrint( \
                "ReleaseVideo(): Releasing VLC objects for " \
                                "indexVideo = %d." % indexVideo)

            common.DebugPrint(
                #"PrepareVideo(): " \
                #    "threading.currentThread() = %s\n" % \
                #    str(threading.currentThread()) + \
                "ReleaseVideo(): " \
                    "thread.get_ident() = %d" % thread.get_ident())
        except:
            common.DebugPrintErrorTrace()

        #del UI.player[1]
        # Maybe UI.player[1].stop()
        try:
            """
            This seems to be the most important.
              Otherwise it is eating CPU and ~13MB for each
              instance of VLC library running.
            """
            UI.player[indexVideo].release()
        except:
            common.DebugPrintErrorTrace()

        try:
            UI.media[indexVideo].release()
        except:
            common.DebugPrintErrorTrace()

        try:
            UI.instance[indexVideo].release()
        except:
            common.DebugPrintErrorTrace()

        common.DebugPrint("ReleaseVideo(): " \
                "Released VLC objects for " \
                "indexVideo = %d." % indexVideo)

        """
        UI.player[pseudoIndexVideo].release()
        common.DebugPrint("Released VLC objects step #1")

        UI.media[pseudoIndexVideo].release()
        common.DebugPrint("Released VLC objects step #2")

        UI.instance[pseudoIndexVideo].release()

        common.DebugPrint("Released VLC objects for " \
                    "pseudoIndexVideo = %d." % pseudoIndexVideo)
        """
