import common
import EraseMediaFiles
import Google
import os
import Settings
import Slideshow
import time
import thread
import threading
import UI
import vlc

import State

"""
DO_ANALYSIS = True
if DO_ANALYSIS:
    import VideoAnalysis
    import AudioAnalysis
"""
import Analyze
import VideoAnalysis
import AudioAnalysis



if common.MY_PYSIDE:
    from PySide import QtCore, QtGui
elif common.MY_PYQT:
    from PyQt4 import Qt
    # For Dialog
    from PyQt4 import QtCore, QtGui



# We inherit from QtCore.QObject because we use QtCore.QObject.emit().
class ModelController(QtCore.QObject):
    #__slots__ = ['condition']

    #view = None # This is the View pair (in the MVC pattern).
    #self.condition instantiated in __init__()

    def __init__(self, *args): #aIndexVideo):
        common.DebugPrint(
            "Entered ModelController::__init__(self=%s, args=%s)" % \
                                                        (self, str(args)))
        super(ModelController, self).__init__() #*args)

        self.condition = threading.Condition()

        common.DebugPrint("ModelController::__init__(): calling SetSignals()")

        self.SetSignals()


    def SetSignals(self):
        pass


    def MainLoop(self):
        try:
            common.DebugPrint(
                "ModelController::MainLoop(): " \
                    "threading.currentThread() = %s\n" % \
                    str(threading.currentThread()) + \
                "ModelController::MainLoop(): " \
                    "thread.get_ident() = %d" % thread.get_ident())

            #"""
            if True:
                self.condition.acquire()
            #"""
            common.DebugPrint(
                "ModelController::MainLoop(): After self.condition.acquire().")

            #thread.exit_thread()

            #if True:
            while True:
                res = self.PlayNextVideo()
                common.DebugPrint("ModelController::MainLoop(): " \
                            "PlayNextVideo() returned res = %d" % res)

                """
                # We simulate the playing of the video.
                t = threading.Timer(Settings.myCfg.PAUSE_BETWEEN_VIDEOS,
                                    MediaFinishedPlayingEventHandler,
                                    args=(None, None, None))
                t.start()
                """

                #time.sleep(30.0)
                #"""
                if res == 0:
                    """
                    We wait for the video to finish playing (res == 0 means a
                        video is playing).
                    """
                    #if False:
                    if True:
                        common.DebugPrint("ModelController::MainLoop(): " \
                                    "before self.condition.wait()")

                        self.condition.wait()

                        common.DebugPrint("ModelController::MainLoop(): " \
                                    "after self.condition.wait()")

                    time.sleep(Settings.myCfg.PAUSE_BETWEEN_VIDEOS)
                elif res == -1:
                    """
                    The video was not played anymore because it was played 
                        enough times (or maybe becaause of a different error).
                    """
                    time.sleep(Settings.myCfg.PAUSE_BETWEEN_VIDEOS)

                #time.sleep(3.0)

                #"""
                #pass

            #"""
            # Not necessary if the above loop is a forever loop:
            if True:
                self.condition.release()
            #"""
        except:
            common.DebugPrintErrorTrace()


    # VLC allows any number of params for callback functions
    @vlc.callbackmethod
    def MediaProgressEventHandler(self, anEvent, aData):
        try:
            """
            if UI.player[UI.indexVideo]:
                print "MediaProgressEventHandler(): indexVideo = %d, " \
                        "get_time() = %d." % \
                        (UI.indexVideo, UI.player[UI.indexVideo].get_time())

                descriptionStr = UI.videoTitle[UI.indexVideo].getText()

            # See http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qlabel.html#setText
            UI.videoTitle[UI.indexVideo].setText(
                        descriptionStr[:len(descriptionStr) - 5] + \
                        "%.2f" % UI.player[UI.indexVideo].get_time() / 1000.0)

            # See http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qlabel.html#setText
            UI.videoTitle[UI.indexVideo].setText("%.2f" % \
                                    (UI.player[UI.indexVideo].get_time() / 1000.0))
            """

            # See http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qlabel.html#setText
            UI.videoTitle[UI.indexVideo].setText(
                UI.videoTitleStr[UI.indexVideo] + \
                    " %.2f" % (UI.player[UI.indexVideo].get_time() / 1000.0))
        except:
            common.DebugPrintErrorTrace()


    # VLC allows any number of params for callback functions
    @vlc.callbackmethod
    def MediaFinishedPlayingEventHandler(self, aContinuation, anEvent, aData):
        # gobject.idle_add(self.restart())
        common.DebugPrint( \
            "Entered MediaFinishedPlayingEventHandler(): Video finished")

        common.DebugPrint(
            "MediaFinishedPlayingEventHandler(): " \
                "threading.currentThread() = %s\n" % \
                str(threading.currentThread()) + \
            "MediaFinishedPlayingEventHandler(): " \
                "thread.get_ident() = %d" % thread.get_ident())

        try:
            #if False:
            if True:
                # This simulates the playing of the video.
                #time.sleep(Settings.myCfg.PAUSE_BETWEEN_VIDEOS)

                self.condition.acquire()
                common.DebugPrint(
                    "MediaFinishedPlayingEventHandler(): after " \
                    "ModelController.condition.acquire()")

                self.condition.notify()
                common.DebugPrint(
                    "MediaFinishedPlayingEventHandler(): after " \
                    "ModelController.condition.notify()")

                self.condition.release()
                common.DebugPrint(
                    "MediaFinishedPlayingEventHandler(): after " \
                    "ModelController.condition.release()")

                if aContinuation is not None:
                    aContinuation()
            else:
                # t = threading.Timer(5.0, aContinuation)
                t = threading.Timer(Settings.myCfg.PAUSE_BETWEEN_VIDEOS,
                                    aContinuation)

                t.start()
        except:
            # Qt.QTimer.singleShot(0.1 * 1000, PlayNextVideoInSlideshow)
            common.DebugPrintErrorTrace()

    def MediaFinishedPlayingEventHandlerWithCallable(self, aContinuation):
        return lambda anEvent, aData: \
            self.MediaFinishedPlayingEventHandler( \
                                            aContinuation, anEvent, aData)


    def PlayVideo(self, aIndexVideo):
        common.DebugPrint("Entered PlayVideo(aIndexVideo=%s)." % \
                                                    str(aIndexVideo))

        #!!!!TODO
        #return

        """
        eventHandler = UI.player[UI.indexVideo].event_manager()

        # Inspired from http://forum.videolan.org/viewtopic.php?f=32&t=82502
        eventHandler.event_attach(vlc.EventType.MediaPlayerTimeChanged,
                                    self.MediaProgressEventHandler, None)

        #eventHandler.event_attach(vlc.EventType.MediaPlayerSeekableChanged,
        #            self.MediaProgressEventHandler, None)

        eventHandler.event_attach(vlc.EventType.MediaPlayerPositionChanged,
                                    self.MediaProgressEventHandler, None)
        """

        try:
            res = UI.player[aIndexVideo].play()
            common.DebugPrint(
                "PlayVideo(): player[aIndexVideo].play() returned %s." % \
                                                                    str(res))
        except:
            common.DebugPrintErrorTrace()


    def DownloadAndStartPlayingVideoAndSetTitle(self, URL, pathFileName,
            fileSize, aVlcVideo, aVideoTitle, descriptionStr, aIndexVideo):
        EraseMediaFiles.Main()

        common.DebugPrint(
            "Entered DownloadAndStartPlayingVideoAndSetTitle(URL=%s, " \
                    "pathFileName=%s, descriptionStr=%s, aIndexVideo=%d)." % \
                    (URL, pathFileName, descriptionStr, aIndexVideo))

        #return 0

        # This is for the iCam Viewer watchdog.
        common.PetWatchdog()

        try:
            if Settings.myCfg.mediaServer[aIndexVideo] == 0:
                # YouTube
                for retryCounter in range(common.NUM_RETRIES_DOWNLOAD_VIDEO + 1):
                # while True:
                    (pathFileName, videoLength) = Google.DownloadYouTubeVideo( \
                                            UI.ytVideoEntryList[aIndexVideo], \
                                            UI.videoIdStrList[aIndexVideo])

                    # (pathFileName, descriptionStr, videoLength) = \
                    #           Google.DownloadYouTubeVideo(aIndexVideo)

                    if (pathFileName == "") and (videoLength == -1):
                        """
                        We got an exception at Google.DownloadYouTubeVideo().
                         We have the following possibilities:
                          - We might receive
                           "DownloadError: ERROR: YouTube said: This video is
                                                                    unavailable."
                                - see Z:\1PhD\ReVival\Logs\iCamViewer\HP_DV5_1017nr\Video_unavailable\stderr_2011_04_18_22_51_02.txt.

                            - Z:\1PhD\ReVival\Logs\iCamViewer\HP_DV5_1017nr\InsteadOfRedirectRecoveryOptions\login_redirect.html
                                "Google accounts" management:
                                    "Don't wait until it's too late" - asking to
                                        give recovery options

                        In case the video was rejected by YouTube as
                            "Rejected (duplicate upload)", youtube_dl will
                            give "ERROR: unable to download video webpage:
                                    HTTP Error 404: Not Found"
                        """
                        time.sleep(10)
                    else:
                        break

                common.DebugPrint(
                            "DownloadAndStartPlayingVideoAndSetTitle(): " \
                            "pathFileName = %s" % pathFileName)
                UI.mediaPathFileName[aIndexVideo] = pathFileName

                try:
                    fileSize = os.path.getsize(pathFileName)
                except:
                    common.DebugPrintErrorTrace()
                    return -1

                if Settings.myCfg.titleFontSize <= 12:
                    ytVideoTitle = \
                            UI.ytVideoEntryList[aIndexVideo].media.title.text
                    """
                    We can extract date&time also from: UI.dateTimeStr[aIndexVideo]
                      or
                      UI.videoDescriptionStr[aIndexVideo] = UI.ytVideoEntryList[
                                                aIndexVideo].media.description.text
                    """

                    tokensFileName = ytVideoTitle.split("_")
                    tm_year = int(tokensFileName[0])
                    tm_mon = int(tokensFileName[1])
                    tm_mday = int(tokensFileName[2])
                    tm_hour = int(tokensFileName[3])
                    tm_min = int(tokensFileName[4])
                    tm_sec = int(tokensFileName[5])

                    # From http://www.tutorialspoint.com/python/time_mktime.htm
                    myCTime = time.mktime((
                                        tm_year, tm_mon, tm_mday,
                                        tm_hour, tm_min, tm_sec,
                                        -1, -1, -1))

                    # The last 3 parameters are tm_wday, tm_yday, tm_isdst
                    myCTimeAux = time.localtime(myCTime)

                    # print time.strftime("%Y_%m_%d_%H_%M_%S", myCTimeAux)
                    numSecondsPassed = time.time() - myCTime

                    """
                    descriptionStr = "%02d:%02d:%02d ago" \
                                      % (int(numSecondsPassed / 3600),
                                      int(numSecondsPassed / 60) % 60,
                                      int(numSecondsPassed) % 60)
                    """
                    descriptionStr += " (%02d:%02d:%02d ago)" % \
                        (int(numSecondsPassed / 3600),
                            int(numSecondsPassed / 60) % 60,
                            int(numSecondsPassed) % 60)
                    """
                    descriptionStr += " (- %02d:%02d)" \
                                       % (int(numSecondsPassed / 60),
                                           int(numSecondsPassed) % 60)
                    """
            elif Settings.myCfg.mediaServer[aIndexVideo] == 1: 
                # Server is Picasa
                pass
            elif Settings.myCfg.mediaServer[aIndexVideo] == 2:
                # Server is iCam
                """
                # Maybe because the server was in a bad state (e.g., 8 out of 33
                #    downloads gave timeout), this application crashed ~3 times
                #    in a day :(.

                res = common.DownloadFile(
                        "http://mobile-revival.110mb.com/ReVival/" + \
                                        UI.mediaPathFileName[aIndexVideo], \
                                        UI.mediaPathFileName[aIndexVideo])
                """
                res = common.DownloadFile(URL, pathFileName, fileSize)

                if res == -1:
                    return -1
            elif Settings.myCfg.mediaServer[aIndexVideo] == 3:
                # Local
                #dateTimeStrAux = "1-9-2013 00:00:00"

                UI.mediaPathFileName[aIndexVideo] = pathFileName

                try:
                    fileSize = os.path.getsize(pathFileName)
                except:
                    common.DebugPrintErrorTrace()
                    return -1


            Analyze.AnalyzeMedia(Settings.myCfg.mediaServer[aIndexVideo],
                         UI.ytVideoEntryList[aIndexVideo],
                         UI.mediaPathFileName[aIndexVideo])


            #return 0
            if False:
                #SplitScreen.SplitScreen.PrepareVideo(aIndexVideo, \
                #                                    pathFileName, aVlcVideo)
                pass
            else:
                """
                SplitScreen.SplitScreen.prepareVideo_indexVideo = aIndexVideo
                SplitScreen.SplitScreen.prepareVideo_pathFileName = pathFileName
                SplitScreen.SplitScreen.prepareVideo_aVlcVideo = aVlcVideo
                """
                self.view.prepareVideo_indexVideo = aIndexVideo
                self.view.prepareVideo_pathFileName = pathFileName
                self.view.prepareVideo_aVlcVideo = aVlcVideo


                common.DebugPrint( \
                    "DownloadAndStartPlayingVideoAndSetTitle(): " \
                    "calling QtCore.QObject.emit()")

                """
                # Does NOT work:
                QtCore.QObject.emit(self, aIndexVideo, pathFileName, aVlcVideo, \
                                            QtCore.SIGNAL("PrepareVideo()"))
                """
                QtCore.QObject.emit(self, QtCore.SIGNAL("PrepareVideo()"))

                """
                #!!!!IMPORTANT TODO: use condition.wait() instead of sleep() OR AT LEAST MOVE THE sleep() ABOVE.
                Note that time.sleep(1.0) (seconds) gave error a few times
                    on HP DV2 at the very first video and I got exception:
                    "AttributeError: 'NoneType' object has no attribute 'play'"

                We need to allow the UI thread to finish PrepareVideo().
                  Note: 0.1 seconds is too small amount, since it loads the
                    video from disk.
                """
                time.sleep(2.0)
            #UI.player[aIndexVideo].set_title("dsadsa")

            """
            # Unfortunately this does NOT work - basically no changes to the
            #    video happen.

            # I was able to specify non-default params to VLC in Python in
            #    instance[aIndexVideo].media_new(pathFileName, "no-video-title-show",
            #    "sub-filter=marq{marquee=Playing}", "video-filter=adjust",
            #    "brightness=1.0", "contrast=1.0").

            common.DebugPrint(
                "DownloadAndStartPlayingVideoAndSetTitle(): " \
                        "calling video_set_adjust_*() .")

            # UI.player[aIndexVideo].video_set_adjust_bool(
            #                                   vlc.VideoAdjustOption.Enable, True)

            UI.player[aIndexVideo].video_set_adjust_int(
                                                vlc.VideoAdjustOption.Enable, 1)

            UI.player[aIndexVideo].video_set_adjust_float(
                                            vlc.VideoAdjustOption.Brightness, 0.2)

            UI.player[aIndexVideo].video_set_adjust_float(
                                            vlc.VideoAdjustOption.Contrast, 0.2)
            """

            """
            # See http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qframe.html
            myFrame = QtGui.QFrame(UI.vlcVideo[aIndexVideo])

            #myFrame = QtGui.QFrame(self.vlcVideoLayout[index])
            myFrame.setFrameShape(QtGui.QFrame.Box)
            myFrame.setLineWidth(100)
            #UI.vlcVideo[aIndexVideo].addWidget(myWidget)
            #self.vlcVideoLayout[index].addWidget(myFrame)
            """
            self.PlayVideo(aIndexVideo)

            """
            time.sleep(0.1) to get the right value with get_length().
            Smaller values for sleep interval might lead to reading 0.0 video
                length.
            """
            time.sleep(0.1)

            # Play/resume if zero, pause if non-zero.
            # UI.player[aIndexVideo].set_pause(1)

            # UI.player[aIndexVideo].set_time(1 * 1000)
            UI.player[aIndexVideo].audio_set_volume(
                                        Settings.myCfg.audioVolume *
                                                (1 - Settings.myCfg.audioMute))

            if Settings.myCfg.mediaServer[aIndexVideo] == 0:
                # YouTube server
                pass
            else:
                """
                Get the current video length (in ms)
                    Note: get_length() returns int. - I need to call
                    UI.player[index].play() but also a time.sleep(0.1) to get the
                    right value with get_length().
                """
                videoLength = UI.player[aIndexVideo].get_length() / 1000.0
            """
            videoVolume = UI.player[aIndexVideo].audio_get_volume() + "%d" \
                                                            % videoVolume + 
            """
            common.DebugPrint(
                "DownloadAndStartPlayingVideoAndSetTitle(): " \
                        "descriptionStr = %s, " \
                        "videoLength = %.2f." % (descriptionStr, videoLength))

            if Settings.myCfg.mediaServer[aIndexVideo] == 0:
                # YouTube
                # The UI.dateTimeStr is set in Google.FindMostRecentYouTubeVideo()
                pass
            elif Settings.myCfg.mediaServer[aIndexVideo] == 1:
                # Picasa
                pass
            elif Settings.myCfg.mediaServer[aIndexVideo] == 2:
                # iCam Server
                descriptionStr = descriptionStr[ : len(descriptionStr) - \
                                                    len(" bytes)")]

                rIndex = descriptionStr.rfind("(")
                fileSize = int(descriptionStr[rIndex + 1 : ])
                descriptionStr = descriptionStr[ : rIndex - 1]
            elif Settings.myCfg.mediaServer[aIndexVideo] == 3:
                # Local
                #rIndex = descriptionStr.rfind("(")
                #fileSize = int(descriptionStr[rIndex + 1 : ])
                #descriptionStr = descriptionStr[ : rIndex - 1]
                pass


            # UI.videoTitleStr[aIndexVideo] = descriptionStr + " (%.0fKB, \
            #                   %.2fsec)" % (fileSize / 1024.0, videoLength)
            if Settings.myCfg.titleFontSize <= 12:
                UI.videoTitleStr[aIndexVideo] = descriptionStr + \
                        " (%.0fKB, %.2fs, %.2f)" % (fileSize / 1024.0,
                        videoLength, VideoAnalysis.motionFactorPerFrame)
            else:
                UI.videoTitleStr[aIndexVideo] = descriptionStr + \
                        " (%.0fKB, %.2fs, %.2f, %.1f%%)" % (fileSize / 1024.0,
                            videoLength,
                            VideoAnalysis.motionFactorPerFrame,
                            AudioAnalysis.soundPercentage * 100.0)

            # UI.videoTitleStr[aIndexVideo] += " %d" % chargerStatus """
            if State.chargerStatus == 0:
                UI.videoTitleStr[aIndexVideo] += " OFF"
            elif State.chargerStatus == 1:
                # UI.videoTitleStr[aIndexVideo] += "NOK"
                UI.videoTitleStr[aIndexVideo] += " ON"
            # """

            # See http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qlabel.html#setText
            aVideoTitle.setText(UI.videoTitleStr[aIndexVideo])
        except:
            common.DebugPrintErrorTrace()
            return -1

        return 0


    eventHandler =                [None] * 6 #UI.MAX_NUM_VIDEOS

    #!!!!TODO: remove the name Callable, and Continuation if no longer using this method
    def DownloadAndPlayVideoAndSetTitleWithCallable(self, URL, pathFileName,
                fileSize, aVlcVideo, aVideoTitle, descriptionStr, aIndexVideo,
                aContinuation):
        common.DebugPrint(
            "Entered DownloadAndPlayVideoAndSetTitleWithCallable().")

        #return 0

        try:
            """
            This function starts playing the video and returns while its
                playing.
            """
            res = self.DownloadAndStartPlayingVideoAndSetTitle(URL,
                            pathFileName, fileSize, aVlcVideo, aVideoTitle,
                            descriptionStr, aIndexVideo)

            common.DebugPrint(
                "DownloadAndPlayVideoAndSetTitleWithCallable(): after " \
                    "DownloadAndStartPlayingVideoAndSetTitle(), res = %s" % \
                                                                    str(res))

            """
            If I recall correctly, for YouTube downloaded .flv (maybe .mp4 as well),
                VLC reports UI.player[aIndexVideo].get_length() == 0
                # In case of error:
                if (res == False or ((useYouTube == False) and 
                    (UI.player[aIndexVideo].get_length() <= 0))):
            """
            if (res == -1) or \
                        ((Settings.myCfg.mediaServer[aIndexVideo] != 0) and \
                                (UI.player[aIndexVideo].get_length() <= 0)):
                # In case of error:
                self.MediaFinishedPlayingEventHandlerWithCallable(aContinuation)( \
                                                                    None, None)
            else:
                """
                While the video is playing, we register in the event manager of
                    this player for the event MediaPlayerEndReached,
                    function MediaFinishedPlayingEventHandlerWithCallable(),
                    such that it gets called when the video finishes playing.
                """
                if self.eventHandler[aIndexVideo] == None:
                    self.eventHandler[aIndexVideo] = \
                        UI.player[aIndexVideo].event_manager()

                    self.eventHandler[aIndexVideo].event_attach(
                        vlc.EventType.MediaPlayerEndReached,
                        self.MediaFinishedPlayingEventHandlerWithCallable(aContinuation),
                        None)

            return res
        except:
            """
            # Gives: "This object event manager doesn't know about
            #    'Unknown Event' events".
            eventHandler.event_attach(vlc.EventType.VlmMediaInstanceStatusError,
                MediaFinishedPlayingEventHandler, None)
            """
            common.DebugPrintErrorTrace()
            return -1
