import common
import PhoneNumbers
import Settings
import subprocess
import time
import UI


TIME_DELTA_TO_CONSIDER_PHONE_NOT_WORKING = 1 * 3600 # in seconds

"""
If we do not receive a recent media/video from phone then we call the
    phone to restart it.
"""
def Check(videoTime):
    common.DebugPrint("Check(): videoTime = %s" % str(videoTime))

    if (videoTime == None) or (videoTime == []):
        return

    """
    if 6120's log.html gets modified at the right rate
        if 6680's log.html doesn't get modified
            call 6680
    else:
        if pauseInterval of 6120 is very big:
            # It is normal not to receive anything.
            #    Probably the power supply for the phone is down.
        else:
            # In fact iCam might be running on 6120 but there is no
            #    Inet connectivity
            call 6120
                if after still log.html not changed then try again and if
                    still not then probably the network is down, or phone power
                    off or damage or theft or Act of God.
    """

    tokens = videoTime.split("_")
    videoTimeTuple = (int(tokens[0]), int(tokens[1]), int(tokens[2]),
                    int(tokens[3]), int(tokens[4]), int(tokens[5]),
                    int(tokens[6]))

    common.DebugPrint(
        "Check(): videoTimeTuple = %s" % str(videoTimeTuple))

    (tm_year, tm_mon, tm_mday, tm_hour, tm_min, tm_sec, numMilliseconds) = \
                                                            videoTimeTuple

    videoTimeUE = time.mktime( (tm_year, tm_mon, tm_mday,
                                    tm_hour, tm_min, tm_sec, -1, -1, -1) )
    common.DebugPrint("Check(): videoTimeUE = %s" % str(videoTimeUE))

    # How many sec passed since the video was created (started to be recorded)
    numSecs = time.time() - videoTimeUE

    common.DebugPrint(
        "Check(): Num seconds = %d\n" % numSecs + \
        "Check(): Num minutes = %.2f\n" % (numSecs / 60) + \
        "Check(): Num hours = %.3f\n" % (numSecs / 3600.0) + \
        "Check(): Num days = %.3f\n" % (numSecs / (3600.0 * 24)) + \
        "Check(): Num years = %.3f\n" % (numSecs / (3600 * 24 * 365.25)) )

    if numSecs > TIME_DELTA_TO_CONSIDER_PHONE_NOT_WORKING:
        deviceId = Settings.myCfg.deviceId[UI.indexVideo]

        """
        The phone should have a process running that restarts the phone when
            it is called (from specific numbers, but MAYBE also from
            general ones).
        """
        subprocess.call([
            "C:\\Program Files\\Skype\\Phone\\Skype.exe",
            "/callto:" + PhoneNumbers.phoneInfo[deviceId]])


# UI.deviceId[UI.indexVideo]
# UI.dateTimeStrHistory[UI.indexVideo]

if __name__ == "__main__":
    Check("2013_11_18_05_16_48_000_668066806680668_1")
