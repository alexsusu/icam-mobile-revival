import common
import Google
import math
import re
import os
import ModelController
import Settings
import sys
import time
import threading
import thread
import UI
import View

import Analyze
import VideoAnalysis
import AudioAnalysis

if common.MY_PYSIDE:
    from PySide import QtCore, QtGui
elif common.MY_PYQT:
    from PyQt4 import Qt
    # For Dialog
    from PyQt4 import QtCore, QtGui




slideshowView = None

#print "UI = %s" % str(UI)
#print "dir(UI) = %s" % str(dir(UI))
# Because of cyclic import dependency UI.MAX_NUM_VIDEOS is not visible here...
pseudoIndexVideo = None #4


class SlideshowMC(ModelController.ModelController): #(SplitScreenMC.SplitScreenMC):
    """
    A list with media to be played in slideshow - each element is a
        [URL, descriptionStr]
    """

    # The following MUST be static vars:
    mediaFileURLList = []

    startIndex = 1
    results = None
    resultsIndex = -1

    """
    According to YouTube's own message, max is 50:
        "Max-results value is too high.
        Only up to 50 results can be returned per query."
    """
    maxResults = 50 #10
    #slideshowView = None

    indexMediaFileURLList = -1
    deltaIndexMediaFileList = -1


    def __init__(self): #, aIndexVideo):
        #self.slideshowView = aSlideshowView
        #self.indexVideo = aIndexVideo

        common.DebugPrint(
            "SlideshowMC()::__init__(): indexVideo = %d" % self.indexVideo)

        common.DebugPrint(
            "SlideshowMC()::__init__(): " \
                "threading.currentThread() = %s\n" % \
                str(threading.currentThread()) + \
            "SlideshowMC()::__init__(): " \
                "thread.get_ident() = %d" % thread.get_ident())

        super(SlideshowMC, self).__init__()


    def SetSignals(self):
        # Note: self.view is not yet available, so we use slideshowView.

        common.DebugPrint(
            "Entered SlideshowMC::SetSignals(self=%s)." % str(self))

        common.DebugPrint(
            "SlideshowMC::SetSignals(): slideshowView = %s." % \
                                                str(slideshowView))

        """
        QtCore.QObject.connect(self,
            QtCore.SIGNAL("SetVideoTitleAndDrawRectangle()"),
            SplitScreen.splitScreen.SetVideoTitleAndDrawRectangle)
        """

        QtCore.QObject.connect(self,
            QtCore.SIGNAL("PrepareVideo()"), slideshowView.PrepareVideo)

        QtCore.QObject.connect(self,
            QtCore.SIGNAL("ReleaseVideo()"), slideshowView.ReleaseVideo)

        """
        #Gives the following error:
        #    RuntimeError: Internal C++ object (PySide.QtGui.QPushButton) already deleted.
        QtCore.QObject.connect(slideshowView.skipButton,
                                QtCore.SIGNAL("clicked()"),
                                self.PlayNextVideo)
        """


    # This is for iCam Server:
    def ReadMediaFileList(self, pathFileName, cameraId):
        for line in open(pathFileName):
            try:
                """
                if not myRE.search(line):
                    print line,
                    movieArray1.push(["http://mobile-revival.110mb.com/" \
                        "ReVival/668066806680668/Media/2011/01/16/" \
                        "2011_01_16_00_52_35_000_1.3gp", "information",
                        "00:52:51 16-01-2011 ( bytes)"]);
                """

                if  (line.find(".push(") != -1) and \
                        (line.find(".3gp") != -1) and \
                        (line.find("Array%d" % cameraId) != -1) and \
                        (line.find(" = new Array();") == -1) and \
                        (line.find("( bytes)") == -1):
                    # print line
                    tokensLine = line.split("', ")
                    index = tokensLine[0].find("http://")
                    URL = (tokensLine[0])[index : ]
                    # print URL,
                    sys.stdout.flush()

                    rIndex = URL.rfind("/")
                    fileName = URL[rIndex + 1 : ]
                    # print "fileName = %s" % fileName

                    rIndex = tokensLine[2].rfind("'")
                    descriptionStr = (tokensLine[2])[1 : rIndex]

                    tokensFileName = fileName.split("_")
                    hour = int(tokensFileName[3])
                    minute = int(tokensFileName[4])
                    # print "Hour = %d, minute = %d." % (hour, minute)
                    self.mediaFileURLList.append([URL, descriptionStr])
                    """
                    if (hour > 6) and (hour < 18): #, tokensFileName[4])
                        assert common.DownloadFile(URL, fileName) == 0
                        AnalyzeVideo(fileName)
                    """
            except:
                common.DebugPrintErrorTrace()


    def DownloadYouTubeVideoFeedPages(self, howManyVideoFeedPagesToGet):
        common.DebugPrint(
            "Entered SlideshowMC()::DownloadYouTubeVideoFeedPages(" \
            "howManyVideoFeedPagesToGet = %d)." % howManyVideoFeedPagesToGet)

        try:
            for i in range(howManyVideoFeedPagesToGet):
                crtResults = \
                    Google.youtubeClient.Get("https://gdata.youtube.com/feeds/" \
                                    "api/users/default/uploads/?start-index=" +
                                    str(self.startIndex) + "&max-results=" +
                                    str(self.maxResults))

                """
                crtResults = Google.youtubeClient.Get(
                    "https://gdata.youtube.com/feeds/api/users/" +
                    Settings.myCfg.googleUsername + "/uploads/?start-index=" +
                    str(self.startIndex) + "&max-results=" +
                    str(self.maxResults))
                """

                """
                common.DebugPrint("SlideshowView()::DownloadYouTubeVideoFeedPages():" \
                            " crtResults = %s." % (crtResults))
                    sys.stdout.flush()
                """
                if self.results is None:
                    self.results = crtResults
                else:
                    self.results.entry += crtResults.entry
                if i == 0:
                    """
                    Class GDataFeed is defined in
                        C:\Python27\Lib\site-packages\gdata\__init__.py:

                    # AttributeError: 'GDataFeed' object has no attribute
                    #    'FindChildren'
                    #ytVideoExtensionsGroup = self.results.FindChildren
                    #    tag = "totalResults")

                    # Returns [] :
                    #ytVideoExtensionsGroup = self.results.FindExtensions(
                    #                                     tag = "totalResults")

                    # Doesn't work:
                    #print "self.results.totalResults =",
                    #    self.results.totalResults

                    #print "ytVideoExtensionsGroup =", ytVideoExtensionsGroup

                    # AttributeError: 'GDataFeed' object has no
                    #        attribute 'children':
                    #print "self.results.children =", self.results.children
                    # See https://code.google.com/apis/youtube/2.0/reference.html#Paging_through_Results :
                    """
                    common.DebugPrint(
                        "SlideshowMC()::DownloadYouTubeVideoFeedPages(): " \
                            "Total number of uploaded video feeds is " \
                            "self.results.total_results = %d" % \
                                int(self.results.total_results.text))

                common.DebugPrint(
                    "SlideshowMC()::DownloadYouTubeVideoFeedPages(): " \
                        "len(crtResults.entry) = %d, " \
                        "len(self.results.entry) = %d (time = %s)." % \
                        (len(crtResults.entry), len(self.results.entry),
                           common.GetCurrentDateTimeStringWithMillisecondsNice()))

                if len(crtResults.entry) == 0:
                    if (self.results is None) or (len(self.results.entry) == 0):
                        # We did not obtain any video feeds:
                        return -1
                    else:
                        break
                self.startIndex += self.maxResults
                """
                !!!!Remove duplicate feeds because I added more videos at
                        YouTube while downloading the feed pages.
                !!!!Also, it might happen that I miss some video feeds if I
                        delete videos from YouTube while downloading the feed
                        pages - try to address this as well.
                """
        except:
            common.DebugPrintErrorTrace()

        common.DebugPrint(
            "Exiting SlideshowMC()::DownloadYouTubeVideoFeedPages().")


    def GetMoreYouTubeVideos(self, howManyMoreVideosToGet=1):
        try:
            common.DebugPrint(
                "Entered SlideshowMC()::GetMoreYouTubeVideos" \
                    "(howManyMoreVideosToGet = %d) at time = %s." % \
                    (howManyMoreVideosToGet,
                       common.GetCurrentDateTimeStringWithMillisecondsNice()))

            # if Settings.myCfg.mediaServer[self.indexVideo] == 0:
            # #YouTube
            #
            # Iterate over all YouTube video feeds. startIndex = 950
            # self.mediaFileURLList = [] ytCompleteResultEntryList = []

            ytVideoEntryListAux = []
            """
            t = threading.Timer(0.001, self.exec_)
            t.start()
            """
            counterVideos = 0

            while True:
            # for moreVideosIndex in range(howManyMoreVideosToGet):
                if self.results is None:
                    try:
                        """
                        Beware that in slideshow mode, if you read a feed page
                            now and the following page in 5 (or more) minutes
                            later the 2 might not be perfectly adjacent
                            (e.g., might overlap) because more videos could
                            have been added by iCam in the YouTube account.
                        A solution could be to read all (or as many) feed pages
                            in a burst.
                        """

                        """
                        Important: we can ask for at most 50 results per
                            page - see exception:
                           "RequestError: {'status': 400, 'body':
                                'Max-results value is too high. Only up to 50 results can be returned per query.',
                                'reason': 'Bad Request'}"

                        !!!!If wanted we could do a few Get, each with 50 and
                            concatenate the results.
                        It gets as many user feeds as specified.
                        Inspired from
                            http://stackoverflow.com/questions/2448801/youtube-api-how-to-limit-results-for-pagination
                        """

                        DOWNLOAD_MULTIPLE_50_FEEDS_PAGES = True

                        if DOWNLOAD_MULTIPLE_50_FEEDS_PAGES:
                            self.DownloadYouTubeVideoFeedPages( \
                                common.NUM_YT_VIDEO_FEED_PAGES_TO_GET)

                            #threading.Timer(10.0,
                            #       self.DownloadYouTubeVideoFeedPages).start()

                            # This crashes Python after ~30-60 secs:
                            #thread.start_new_thread(
                            #    self.DownloadYouTubeVideoFeedPages, (200,))
                        else:
                            self.results = Google.youtubeClient.Get(
                                "https://gdata.youtube.com/feeds/api/users/default/uploads/?start-index=" +
                                str(self.startIndex) +
                                "&max-results=" +
                                str(self.maxResults))

                            #self.results = Google.youtubeClient.Get(
                            #    "https://gdata.youtube.com/feeds/api/users/" +
                            #    Settings.myCfg.googleUsername +
                            #    "/uploads/?start-index=" +
                            #    str(self.startIndex) +
                            #    "&max-results=" +
                            #    str(self.maxResults))

                            #if len(self.results.entry) == 0 or \
                            #       self.startIndex > self.maxResults:
                            if len(self.results.entry) == 0:
                                # break
                                return -1
                            self.startIndex += self.maxResults

                        # self.resultsIndex = 1
                        myRange = range(len(self.results.entry))
                    except:
                        common.DebugPrintErrorTrace()
                        continue
                else:
                    # Get more video feed pages (I would get them all,
                    #    but it crashes iCam).
                    self.DownloadYouTubeVideoFeedPages( \
                        common.NUM_YT_VIDEO_FEED_PAGES_TO_GET)

                    myRange = range(self.resultsIndex + 1,
                                    len(self.results.entry))

                common.DebugPrint(
                    "SlideshowMC()::GetMoreYouTubeVideos(): " \
                        "read YouTube videos self.startIndex = %d, " \
                        "self.resultsIndex = %d, self.maxResults = %d, " \
                        "len(self.results.entry) = %d (time = %s)." % \
                        (self.startIndex, self.resultsIndex,
                        self.maxResults, len(self.results.entry),
                        common.GetCurrentDateTimeStringWithMillisecondsNice()))

                # self.mediaFileURLList += self.results.entry

                """
                Filter out the videos that are not for the desired deviceId
                    and cameraId - this is the reason why we have to call
                    Google.youtubeClient.GetYouTubeVideoEntry() - to retrieve
                    deviceId and cameraId. 
                """

                #for ytVideo in self.results.entry:
                for self.resultsIndex in myRange:
                    try:
                        ytVideo = self.results.entry[self.resultsIndex]
                        if self.resultsIndex == len(self.results.entry) - 1:
                            self.results = None

                        common.DebugPrint("\n")

                        videoIdXMLStr = str(ytVideo.id)
                        videoIdStrAux = ytVideo.id.text.split("/")[-1]
                        ytVideoEntryAux = Google.youtubeClient.GetYouTubeVideoEntry(
                            "http://gdata.youtube.com/feeds/api/users/default/uploads/" + \
                            videoIdStrAux)

                        if int(ytVideoEntryAux.media.duration.seconds) == 0:
                            common.DebugPrint(
                                "SlideshowMC()::GetMoreYouTubeVideos(): " \
                                    "int(ytVideoEntryAux.media.duration.seconds) == 0 " \
                                    "which means the video is still being " \
                                    "processed by YouTube (in YouTube next " \
                                    "to the video it says " \
                                    "'Uploaded (processing, please wait)')" \
                                    "--> skipping this video.\n\n")
                            continue

                        # if (filterVideosAfterDeviceIdAndCameraId):
                        deviceId = Settings.myCfg.deviceId[self.indexVideo]

                        if ytVideoEntryAux.media.keywords.text != deviceId:
                            # We look for the video with the right deviceId
                            common.DebugPrint(
                                "SlideshowMC()::GetMoreYouTubeVideos(): " \
                                    "deviceId = %s while " \
                                    "ytVideoEntryAux.media.keywords.text = %s " \
                                    "--> skipping this video." % (deviceId,
                                        ytVideoEntryAux.media.keywords.text))

                            continue

                        cameraId = Settings.myCfg.cameraId[self.indexVideo]

                        try:
                            crtCameraId = \
                                int(ytVideoEntryAux.media.title.text[
                                    len(ytVideoEntryAux.media.title.text)
                                    - 1 : ])
                        except:
                            crtCameraId = -1
                            common.DebugPrintErrorTrace()

                        # We look for the video for the current cameraId
                        if crtCameraId != cameraId:
                            common.DebugPrint(
                                "SlideshowMC()::GetMoreYouTubeVideos(): " \
                                    "crtCameraId = %d while " \
                                    "cameraId = %d --> skipping " \
                                    "this video." % (crtCameraId, cameraId))

                            continue

                        """
                        ytVideoEntryListAux.append(ytVideoEntryAux)
                        self.mediaFileURLList.append(ytVideo)
                        """
                        ytVideoEntryListAux.insert(0, ytVideoEntryAux)
                        self.mediaFileURLList.insert(0, ytVideo)

                        common.DebugPrint("SlideshowView()::GetMoreYouTubeVideos(): "\
                                "found a good video (title = " \
                                "%s; description = %s) - " \
                                "len(self.mediaFileURLList) = %d." % \
                                (ytVideoEntryAux.media.title.text,
                                   ytVideoEntryAux.media.description.text,
                                   len(self.mediaFileURLList)))
                        """
                        common.DebugPrint("SlideshowView()::GetMoreYouTubeVideos(): "\
                                "found a good video (title = %s; " \
                                "description = %s) - " \
                                "len(self.mediaFileURLList) = %d.\n" % \
                                (ytVideoEntryAux.media.title.text,
                                    ytVideoEntryAux.media.description.text,
                                    len(self.mediaFileURLList)))
                        """

                        # break
                        counterVideos += 1
                        if counterVideos == howManyMoreVideosToGet:
                            return 1
                        """
                        if (len(self.mediaFileURLList) == 2): #== 20
                            break
                        """

                        """
                        Settings.myCfgVideoAnalysisOrig = Settings.myCfg.videoAnalysis
                        Settings.myCfgAudioAnalysisOrig = Settings.myCfg.audioAnalysis
                        Settings.myCfg.videoAnalysis = doVideoAnalysis
                        Settings.myCfg.audioAnalysis = doAudioAnalysis
                        self.PlayNextVideo()
                        Settings.myCfg.videoAnalysis = myCfgVideoAnalysisOrig
                        Settings.myCfg.audioAnalysis = myCfgAudioAnalysisOrig
                        """
                    except:
                        common.DebugPrintErrorTrace()
                else:
                    """
                    From http://docs.python.org/tutorial/controlflow.html:
                        "Loop statements may have an else clause; it is
                      executed when the loop terminates through exhaustion of
                      the list (with for) or when the condition becomes false
                      (with while), but not when the loop is terminated by a
                      break statement."
                    """
                    continue

                    common.DebugPrint(
                        "SlideshowMC()::GetMoreYouTubeVideos(): " \
                        "took else branch of for.")

                """
                We stop the outter loop because we got an error in the inner
                    loop, most likely because there are no more video feeds.
                """
                break
        except:
            # """
            common.DebugPrintErrorTrace()

        return 1


    def PlayNextVideo(self):
        res = 0

        # This is for the iCamViewer watchdog
        common.PetWatchdog()

        try:
            common.DebugPrint("Entered SlideshowMC::PlayNextVideo(): " \
                "indexMediaFileURLList = %d, " \
                "self.deltaIndexMediaFileList = %d, " \
                "self.indexVideo = %d, " \
                "Settings.myCfg.mediaServer[self.indexVideo] = %d." % \
                (self.indexMediaFileURLList,
                    self.deltaIndexMediaFileList,
                    self.indexVideo,
                    Settings.myCfg.mediaServer[self.indexVideo]))

            common.DebugPrint("pseudoIndexVideo = %d" % pseudoIndexVideo)

            Settings.myCfg.rotateDegrees[pseudoIndexVideo] = \
                Settings.myCfg.rotateDegrees[self.indexVideo]

            Settings.myCfg.mediaServer[pseudoIndexVideo] = \
                Settings.myCfg.mediaServer[self.indexVideo]

            self.indexMediaFileURLList += \
                self.deltaIndexMediaFileList

            if self.indexMediaFileURLList >= len(self.mediaFileURLList):
                self.indexMediaFileURLList = 0
            elif self.indexMediaFileURLList < 0:
                if Settings.myCfg.mediaServer[self.indexVideo] == 0:
                    # YouTube
                    """
                    Try reading more videos from the YouTube account first.
                        If none left then just cycle through the list.
                    """
                    res2 = self.GetMoreYouTubeVideos( \
                                int(math.fabs(self.deltaIndexMediaFileList)))

                    if res2 == -1:
                        # No more videos left
                        pass
                    else:
                        """
                        Since we read one more video in the list, we keep
                            self.indexMediaFileURLList = 0

                        #self.indexMediaFileURLList += 1
                        """
                        self.indexMediaFileURLList = 0
                        pass
                else:
                    self.indexMediaFileURLList = \
                        len(self.mediaFileURLList) - 1

            common.DebugPrint("PlayNextVideo(): " \
                    "self.indexMediaFileURLList = %d, " \
                    "self.deltaIndexMediaFileList = %d." % \
                    (self.indexMediaFileURLList, self.deltaIndexMediaFileList))

            if UI.player[pseudoIndexVideo] is not None:
                common.DebugPrint("PlayNextVideo(): " \
                    "Releasing VLC objects for pseudoIndexVideo = %d." % \
                    pseudoIndexVideo)

                #del UI.player[1]

                # Maybe UI.player[1].stop()
                """
                This seems to be the most important. Otherwise it was
                    eating CPU and ~13MB for each instance of
                    VLC library running.
                """

                self.view.releaseVideo_indexVideo = pseudoIndexVideo
                if False:
                    self.view.ReleaseVideo()
                else:
                    common.DebugPrint( \
                        "SlideshowMC::PlayNextVideo(): " \
                        "calling QtCore.QObject.emit()")

                    QtCore.QObject.emit(self, \
                                        QtCore.SIGNAL("ReleaseVideo()"))
                    

            if Settings.myCfg.mediaServer[self.indexVideo] == 0:
                # YouTube
                # for ytVideo in ytCompleteResultEntryList:
                # #results.entry:
                ytVideo = self.mediaFileURLList[self.indexMediaFileURLList]

                videoIdXMLStr = str(ytVideo.id)

                UI.videoIdStrList[pseudoIndexVideo] = \
                                        ytVideo.id.text.split("/")[-1]

                UI.ytVideoEntryList[pseudoIndexVideo] = \
                    Google.youtubeClient.GetYouTubeVideoEntry(
                    "http://gdata.youtube.com/feeds/api/users/default/uploads/" + \
                     UI.videoIdStrList[pseudoIndexVideo])

                videoURL = "http://www.youtube.com/watch?v=%s" % \
                                    UI.videoIdStrList[pseudoIndexVideo]

                UI.videoDescriptionStr[pseudoIndexVideo] = \
                    UI.ytVideoEntryList[pseudoIndexVideo].media.description.text

                # Video description: 22:08:51.4 12-05-2011 612061206120612, 0
                # len(videoDescription Str[pseudoIndexVideo]) - 24] #15]
                UI.videoDescriptionStr[pseudoIndexVideo] = \
                    (UI.videoDescriptionStr[pseudoIndexVideo])[ : 16]

                self.DownloadAndPlayVideoAndSetTitleWithCallable(
                        videoURL, "[PATH_FILE_NAME_IS_USELESS]",
                        -1, UI.vlcVideo[pseudoIndexVideo],
                        UI.videoTitle[pseudoIndexVideo],
                        UI.videoDescriptionStr[pseudoIndexVideo],
                        pseudoIndexVideo,
                        None #self.PlayNextVideo
                    )
            elif Settings.myCfg.mediaServer[self.indexVideo] == 1:
                # Picasa
                pass
            elif Settings.myCfg.mediaServer[self.indexVideo] == 2:
                # iCam server
                """
                DownloadAndStartPlayingVideoAndSetTitle(
                    "http://alexsusu.110mb.com/iCam/" + mediaPathFileName[0],
                    mediaPathFileName[0], UI.vlcVideo[pseudoIndexVideo],
                    UI.videoTitle[pseudoIndexVideo], pseudoIndexVideo)
                """
                common.DebugPrint(
                    "SlideshowMC()::PlayNextVideo(): " \
                        "self.mediaFileURLList[self.indexMediaFile" \
                        "URLList][1] = %s" % \
                        self.mediaFileURLList[self.indexMediaFileURLList][1])

                """
                self.DownloadAndStartPlayingVideoAndSetTitle(
                    self.mediaFileURLList[self.indexMediaFileURLList][0],
                    "temp.3gp",
                    UI.vlcVideo[pseudoIndexVideo], UI.videoTitle[pseudoIndexVideo],
                    self.mediaFileURLList[self.indexMediaFileURLList][1],
                    pseudoIndexVideo)

                self.DownloadAndPlayVideoAndSetTitle2(
                    self.mediaFileURLList[self.indexMediaFileURLList][0],
                    "temp.3gp",
                    UI.vlcVideo[pseudoIndexVideo], UI.videoTitle[pseudoIndexVideo],
                    self.mediaFileURLList[self.indexMediaFileURLList][1],
                    pseudoIndexVideo)
                """

                self.DownloadAndPlayVideoAndSetTitleWithCallable(
                        self.mediaFileURLList[self.indexMediaFileURLList][0],
                        "temp.3gp", -1,
                        UI.vlcVideo[pseudoIndexVideo],
                        UI.videoTitle[pseudoIndexVideo],
                        self.mediaFileURLList[self.indexMediaFileURLList][1],
                        pseudoIndexVideo,
                        None #self.PlayNextVideo
                    )
            elif Settings.myCfg.mediaServer[self.indexVideo] == 3:
                # Local video

                #SplitScreenMC.splitScreenMC.DownloadAndPlayVideoAndSetTitleWithCallable(
                self.DownloadAndPlayVideoAndSetTitleWithCallable(
                        "file:///blabla",
                        #"temp.3gp",
                        Settings.myCfg.LOCAL_VIDEO_PATH_FILENAME,
                        -1,
                        UI.vlcVideo[pseudoIndexVideo],
                        UI.videoTitle[pseudoIndexVideo],
                        self.mediaFileURLList[self.indexMediaFileURLList][1],
                        pseudoIndexVideo,
                        None #self.PlayNextVideo
                    )
        except:
            # Qt.QTimer.singleShot(20 * 1000, PlayNextVideo)
            common.DebugPrintErrorTrace()
            res = -1

        return res


    def PreparePlaylist(self, filterVideosAfterDeviceIdAndCameraId=True,
                        doVideoAnalysis=False, doAudioAnalysis=False):
        # global mediaFileURLList
        try:
            common.DebugPrint("Entered SlideshowMC()::PreparePlaylist(" \
                    "filterVideosAfterDeviceIdAndCameraId=%d, " \
                    "doVideoAnalysis=%d, doAudioAnalysis=%d): " \
                    "myCfg.deviceId[self.indexVideo]=%s, " \
                    "myCfg.cameraId[self.indexVideo]=%d." % \
                    (filterVideosAfterDeviceIdAndCameraId,
                       doVideoAnalysis, doAudioAnalysis,
                       Settings.myCfg.deviceId[self.indexVideo],
                       Settings.myCfg.cameraId[self.indexVideo]))

            common.DebugPrint(
                "SlideshowMC()::__init__(): " \
                    "threading.currentThread() = %s\n" % \
                    str(threading.currentThread()) + \
                "SlideshowMC()::__init__(): " \
                    "thread.get_ident() = %d" % thread.get_ident())

            if Settings.myCfg.mediaServer[self.indexVideo] == 0:
                # YouTube
                if False:
                    self.PlayNextVideo()
                return
            elif Settings.myCfg.mediaServer[self.indexVideo] == 1:
                # Picasa
                pass
            elif Settings.myCfg.mediaServer[self.indexVideo] == 2:
                # iCam server
                # Choose depending on self.indexVideo:
                mediaFileListPathFileName = \
                            Settings.myCfg.deviceId[self.indexVideo] + \
                            "/MediaFileList.js"
                """
                if (not os.path.isfile(mediaFileListPathFileName)):
                    assert common.DownloadFile(
                        "http://alexsusu.110mb.com/iCam/668066806680668/MediaFileList.js",
                        mediaFileListPathFileName) == 0

                assert common.DownloadFile("http://alexsusu.110mb.com/iCam/" +
                        mediaFileListPathFileName,
                        mediaFileListPathFileName) == 0

                #assert common.DownloadFile(
                #           "http://" + Settings.myCfg.iCamServerAddress + \
                #           Settings.WEB_FOLDER + "/" + \
                #           mediaFileListPathFileName,
                #           mediaFileListPathFileName) == 0

                # check if common.DownloadFile returns 0
                """

                self.ReadMediaFileList(mediaFileListPathFileName,
                                  Settings.myCfg.cameraId[self.indexVideo])

                """
                Without -1, since it gets subtracted in
                    PlayNextVideo() .
                """
                self.indexMediaFileURLList = len(self.mediaFileURLList)

                common.DebugPrint("SlideshowView()::PreparePlaylist(): " \
                        "after ReadMediaFileList(), " \
                        "self.indexMediaFileURLList = %d." % \
                        self.indexMediaFileURLList)
            elif Settings.myCfg.mediaServer[self.indexVideo] == 3:
                # Local
                self.mediaFileURLList.append( \
                    [Settings.myCfg.LOCAL_VIDEO_PATH_FILENAME, \
                        "blablabla1"]) #descriptionStr])
                self.mediaFileURLList.append( \
                    [Settings.myCfg.LOCAL_VIDEO_PATH_FILENAME, \
                        "blablabla2"]) #descriptionStr])
                self.mediaFileURLList.append( \
                    [Settings.myCfg.LOCAL_VIDEO_PATH_FILENAME, \
                        "blablabla2"]) #descriptionStr])
                self.mediaFileURLList.append( \
                    [Settings.myCfg.LOCAL_VIDEO_PATH_FILENAME, \
                        "blablabla2"]) #descriptionStr])

                self.indexMediaFileURLList = len(self.mediaFileURLList)
                if False:
                    self.PlayNextVideo()
                return

            myCfgVideoAnalysisOrig = Settings.myCfg.videoAnalysis
            myCfgAudioAnalysisOrig = Settings.myCfg.audioAnalysis

            Settings.myCfg.videoAnalysis = doVideoAnalysis
            Settings.myCfg.audioAnalysis = doAudioAnalysis

            if False:
                self.PlayNextVideo()

            Settings.myCfg.videoAnalysis = myCfgVideoAnalysisOrig
            Settings.myCfg.audioAnalysis = myCfgAudioAnalysisOrig
        except:
            common.DebugPrintErrorTrace()


    def GetVideoInfoFromGDataEntry(self, ytVideo):

        if common.MY_DEBUG_STDOUT:
            print "ytVideo =", ytVideo
            print "ytVideo.id =", ytVideo.id
            print "ytVideo.title =", ytVideo.title
            print "ytVideo.content =", ytVideo.content
            sys.stdout.flush()

            """
            #AttributeError: 'GDataEntry' object has no
            #    attribute 'description'
            print "ytVideo.description =", ytVideo.description

            #Note: class GDataEntry(atom.Entry, LinkFinder) defined
            #    in C:\Python27\Lib\site-packages\gdata\__init__.py
            """

            print "ytVideo.link =", ytVideo.link
            for aLink in ytVideo.link:
                print "    aLink =", aLink
                print "    aLink.rel =", aLink.rel
            sys.stdout.flush()

            # print "ytVideo.ns2.category =",
            #           ytVideo.ns2.category
            print "ytVideo.category =", ytVideo.category

            for aCategory in ytVideo.category:
                # Last one is keywords!!!!
                print "    aCategory =", aCategory
                #print "    aLink.rel =", aCategory.rel
            sys.stdout.flush()

        """
        Retrieve more useful info from the extension XML nodes
        """
        # Doesn't work:
        #print "ytVideo.children =", ytVideo.children
        #print "ytVideo.group =", ytVideo.group

        # The XML tag is <ns2:group>.
        ytVideoExtensionsGroup = \
            ytVideo.FindExtensions(tag="group")

        common.DebugPrint("ytVideoExtensionsGroup = %s" % \
                            str(ytVideoExtensionsGroup))

        # Doesn't work:
        #print "ytVideoExtensionsGroup.duration =",
        #    ytVideoExtensionsGroup.duration

        #Class ExtensionElement defined in
        #  C:\Python27\Lib\site-packages\atom\__init__.py, data.py

        for ytVideoExtensionsGroupElem in ytVideoExtensionsGroup:
            common.DebugPrint("ytVideoExtensionsGroupElem = %s" % \
                                str(ytVideoExtensionsGroupElem))

            """
            try:
                # Doesn't work:
                ytVideoDuration = ytVideoExtensionsGroupElem.\
                            FindExtensions(tag = "duration")
                print "ytVideoDuration =", ytVideoDuration
            except:
                common.DebugPrintErrorTrace()
            """

            try:
                myDevTags = []
                myDuration = -1

                common.DebugPrint("ytVideoExtensionsGroupElem.children = %s" % \
                                    str(ytVideoExtensionsGroupElem.children))

                for ytVideoExtensionsGroupElemChild in \
                            ytVideoExtensionsGroupElem.children:
                    common.DebugPrint(
                        "ytVideoExtensionsGroupElemChild = %s\n" % \
                                    str(ytVideoExtensionsGroupElemChild) +

                        "ytVideoExtensionsGroupElemChild" \
                            ".children = %s\n" % \
                            str(ytVideoExtensionsGroupElemChild.children) +

                        "ytVideoExtensionsGroupElemChild" \
                            ".attributes = %s\n" % \
                            str(ytVideoExtensionsGroupElemChild.attributes) +

                        "ytVideoExtensionsGroupElemChild" \
                            ".text = %s\n" % \
                            str(ytVideoExtensionsGroupElemChild.text))

                    if ("scheme" in \
                        ytVideoExtensionsGroupElemChild.attributes) and \
                        (ytVideoExtensionsGroupElemChild.attributes["scheme"] == \
                        "http://gdata.youtube.com/schemas/2007/developertags.cat"):
                        myDevTags.append(ytVideoExtensionsGroupElemChild.text)

                    if ("seconds" in \
                        ytVideoExtensionsGroupElemChild.attributes):
                        myDuration = int(
                                ytVideoExtensionsGroupElemChild. \
                                attributes["seconds"])

                    """
                    ytVideoExtensionsGroupElemChild.children = []

                    ytVideoExtensionsGroupElemChild.attributes = {
                        'scheme':
                        'http://gdata.youtube.com/schemas/2007/developertags.cat'}

                    ytVideoExtensionsGroupElemChild.text = 612061206120612 0

                    ***

                    ytVideoExtensionsGroupElemChild.children = []

                    ytVideoExtensionsGroupElemChild.attributes = {
                        'seconds': '30'}

                    ytVideoExtensionsGroupElemChild.text = None
                    """
                    sys.stdout.flush()
            except:
                common.DebugPrintErrorTrace()

            common.DebugPrint("myDevTags = %s, myDuration = %d" % \
                                (str(myDevTags), myDuration))

            try:
                common.DebugPrint(
                    "ytVideoExtensionsGroupElem.attributes = %s" % \
                        str(ytVideoExtensionsGroupElem.attributes))
            except:
                common.DebugPrintErrorTrace()

            try:
                common.DebugPrint(
                    "ytVideoExtensionsGroupElem.text = %s" % \
                    str(ytVideoExtensionsGroupElem.text))
            except:
                common.DebugPrintErrorTrace()

            sys.stdout.flush()

            # Doesn't work
            # print "ytVideo.duration =", ytVideo.duration

            # Doesn't work
            # print "ytVideo.tags =", ytVideo.keywords

            sys.stdout.flush()


    """
    Inspired from
        https://code.google.com/apis/youtube/1.0/developers_guide_python.html#SearchingVideos

    See also
        https://code.google.com/apis/youtube/2.0/developers_guide_protocol_api_query_parameters.html
    and
        https://code.google.com/apis/youtube/2.0/developers_guide_protocol_category_keyword_browsing.html#Browsing_with_Categories_and_Keywords
    """
    def SearchYouTubeVideosInGeneral(self, searchTerms):
        # TODO: continue working at it: see also Google.py, FindMostRecentYouTubeVideo(), which also attacks this problem

        """
        #yt_service = gdata.youtube.service.YouTubeService()
        query = gdata.youtube.service.YouTubeVideoQuery()
        query.vq = searchTerms
        #query.orderby = 'viewCount'
        query.racy = 'include'

        MIGHT BE FALSE:
          When searchTerms = "2011_06_05_10_" it found some random
            videos that are not mine (the user logged in on
            YouTube) found on the net with SIMILAR (not containing
            the string probably) titles.
          I don't think it found my videos - maybe because they
            are private?

        feed = Google.youtubeClient.YouTubeQuery(query)
        print "feed =", feed
        #PrintVideoFeed(feed)
        """

        # From https://code.google.com/apis/youtube/1.0/developers_guide_python.html#SearchingVideos
        # It found no videos - maybe because my videos are private?
        # developer_tag_uri = 'http://gdata.youtube.com/feeds/videos/-/%7Bhttp%3A%2F%2Fgdata.youtube.com%2Fschemas%2F2007%2Fdevelopertags.cat%7Dyour_tag_here'
        developer_tag_uri = \
            "http://gdata.youtube.com/feeds/videos/-/%7Bht" \
            "tp%3A%2F%2Fgdata.youtube.com%2Fschemas%2F2007" \
            "%2Fdevelopertags.cat%7D612061206120612"

        #yt_service = gdata.youtube.service.YouTubeService()
        #PrintVideoFeed(yt_service.GetYouTubeVideoFeed(
        #    developer_tag_uri))

        feed = \
            Google.youtubeClient.GetYouTubeVideoFeed(developer_tag_uri)
        print "feed =", feed



#!!!!TODO: Rather important scientific quest :) : understand why when declaring class SlideshowView(Viewer.Viewer, QtGui.QDialog): it crashes when instantiating it.
class SlideshowView(QtGui.QDialog, View.View):
#class SlideshowView(QtGui.QDialog):
    #self.indexVideo

    skipButton = None
    #hVideos = None
    #hVideosThread = None

    def __init__(self, aIndexVideo, parent=None):
        global pseudoIndexVideo
        global slideshowView

        """
        In this function we create the SlideshowMC class, but also we make
            reference to SlideshowMC' static vars through SlideshowMC.* .
            In the other methods of this class we access vars and methods
                through self.hVideos since it's already initialized.
        """

        try:
            #!!!!TODO: understand why video is played separated from the window when we use UI.MAX_NUM_VIDEOS - 1
            pseudoIndexVideo = 4 #UI.MAX_NUM_VIDEOS - 1

            common.DebugPrint("Entered SlideshowView()::__init__(): " \
                                "aIndexVideo = %d." % aIndexVideo)

            common.DebugPrint(
                "SlideshowView::__init__(): " \
                    "threading.currentThread() = %s\n" % \
                    str(threading.currentThread()) + \
                "SlideshowView::__init__(): " \
                    "thread.get_ident() = %d" % thread.get_ident())

            super(SlideshowView, self).__init__(parent)
            # dialog = QtGui.QDialog() dialog.show()

            #self.indexVideo = aIndexVideo
            SlideshowMC.indexVideo = aIndexVideo

            if False:
                self.hVideos = SlideshowMC(aIndexVideo)

            self.setWindowTitle("Automatic Slideshow")

            # buttonBox = QtGui.QDialogButtonBox(QtCore.Qt.Vertical)
            buttonBox = QtGui.QDialogButtonBox(QtCore.Qt.Horizontal)

            """
            skip10Button = QtGui.QPushButton("<<Skip 10")
            skip10Button.setDefault(True)
            buttonBox.addButton(skip10Button,
                                    QtGui.QDialogButtonBox.ActionRole)

            skipP10Button = QtGui.QPushButton("Skip 10>>")
            skipP10Button.setDefault(True)
            buttonBox.addButton(skipP10Button,
                                    QtGui.QDialogButtonBox.ActionRole)
            """

            """
            previousButton = QtGui.QPushButton("One day")
            previousButton.setDefault(True)
            buttonBox.addButton(previousButton,
                                    QtGui.QDialogButtonBox.ActionRole)

            QtCore.QObject.connect(previousButton, QtCore.SIGNAL("clicked()"),
                                    self.OnClickPrevious)

            nextButton = QtGui.QPushButton("One hour")
            nextButton.setDefault(True)
            buttonBox.addButton(nextButton, QtGui.QDialogButtonBox.ActionRole)
            QtCore.QObject.connect(nextButton, QtCore.SIGNAL("clicked()"),
                                   self.OnClickNext)

            refreshButton = QtGui.QPushButton("Refresh")
            refreshButton.setDefault(True)
            buttonBox.addButton(refreshButton,
                                QtGui.QDialogButtonBox.ActionRole)
            """
            SlideshowMC.deltaIndexMediaFileList = -1

            self.skipButton = QtGui.QPushButton("Skip")

            # See http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qabstractbutton.html#setText
            self.skipButton.setText("Skip %d" % SlideshowMC.deltaIndexMediaFileList)

            self.skipButton.setDefault(True)
            buttonBox.addButton(self.skipButton,
                                QtGui.QDialogButtonBox.ActionRole)

            #!!!!TODO: executing this crashes the app. We need to redesign: the contraints are: I put in the ModelController the deltaIndex, etc so I need to create here an instance of SlideshowMC, where SetSignals() gets called (so no problem).
            if False:
            #if True:
                QtCore.QObject.connect(self.skipButton,
                                   QtCore.SIGNAL("clicked()"),
                                   SlideshowMC.PlayNextVideo)

            replayButton = QtGui.QPushButton("Replay")
            replayButton.setDefault(True)
            buttonBox.addButton(replayButton,
                                QtGui.QDialogButtonBox.ActionRole)

            #QtCore.QObject.connect(replayButton, QtCore.SIGNAL("clicked()"),
            #    lambda: SlideshowSliderOnValueChanged(0))
            ############################INLINED FUNCTION#######################

            if common.MY_PYSIDE:
                QtCore.QObject.connect(replayButton,
                        QtCore.SIGNAL("clicked()"), self.OnClickReplayButton)
            elif common.MY_PYQT:
                Qt.QObject.connect(replayButton, Qt.SIGNAL("clicked()"),
                                    self.OnClickReplayButton)

            mainLayout = QtGui.QGridLayout()
            UI.InitializeVLCVideoWidget(pseudoIndexVideo, mainLayout)

            mainLayout.addWidget(buttonBox,
                                 UI.RATIO_BETWEEN_TITLE_AND_VIDEO + 2, 0, 1, 1)

            myLabel = QtGui.QLabel()
            #myLabel.setFont(QtGui.QFont("Courier", 15, 50, False))

            #See http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qfont.html
            myLabel.setText("Use the slider to change the step of the "
                            "slideshow:\n")

            # See http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qlabel.html#setText
            # + " " * 80 + "0")
            mainLayout.addWidget(myLabel)

            # Inspired from http://www.devshed.com/c/a/Python/PyQT-Getting-Started/3/:
            #slider1 = QtGui.QSlider(self,"slider1")
            slideshowSlider = QtGui.QSlider()

            #slideshowSlider.setGeometry(QtCore.QRect(130,220,261,31))
            slideshowSlider.setOrientation(QtCore.Qt.Horizontal)
            slideshowSlider.setTickInterval(5)

            # See http://www.opendocs.net/pyqt/pyqt4/html/qslider.html
            slideshowSlider.setTickPosition(QtGui.QSlider.TicksBelow)

            # See http://www.opendocs.net/pyqt/pyqt4/html/qabstractslider.html#setMinimum
            slideshowSlider.setMinimum(-20)

            # See http://www.opendocs.net/pyqt/pyqt4/html/qabstractslider.html#setMaximum
            slideshowSlider.setMaximum(20)

            slideshowSlider.setValue(SlideshowMC.deltaIndexMediaFileList)

            mainLayout.addWidget(slideshowSlider)

            QtCore.QObject.connect(slideshowSlider,
                                   QtCore.SIGNAL("valueChanged(int)"),
                                   self.SlideshowSliderOnValueChanged)

            """
            This was initially immediately after
                mainLayout.addWidget(extension, 1, 0, 1, 2)
            """
            self.setLayout(mainLayout)

            self.setMinimumSize(1000, 650)
            #self.setMaximumSize(1024, 680)

            self.adjustSize()

            """
            The VLC movie window DOES NOT appear in the QDialog, but appears
                as a separate window...

            #threading.Timer(0.1, self.hVideos.PreparePlaylist).start()

            To have the VLC movie window appear in the QDialog it seems I need
                to create the VLC objects before dialog.exec_().
            ####self.hVideos.PreparePlaylist()

            #threading.Timer(0.1, dialog.exec_).start()
            """

            self.setWindowModality(QtCore.Qt.NonModal)

            """
            Inspired from http://lists.trolltech.com/qt-interest/2006-08/thread00695-0.html
             and http://www.qtcentre.org/threads/31905-Show-maximize-button-in-the-title-bar-of-a-QDialog-under-GNOME .
            """
            self.setWindowFlags(QtCore.Qt.CustomizeWindowHint | \
                                QtCore.Qt.WindowCloseButtonHint | \
                                QtCore.Qt.WindowMinMaxButtonsHint)

            myScreen = QtGui.QDesktopWidget().screenGeometry()

            """
            Maximize the window - a bit too much :) - from
            http://nullege.com/codes/search/PyQt4.QtGui.QMainWindow.setGeometry
            """
            self.setGeometry(0, 20, myScreen.width(), myScreen.height() - 100)

            """
            QtCore.QObject.connect(self, QtCore.SIGNAL("finished()"),
                                    self.OnFinished)
            """
            QtCore.QObject.connect(self, QtCore.SIGNAL("done()"), self.OnDone)
            QtCore.QObject.connect(self, QtCore.SIGNAL("finished()"),
                                                    self.OnFinished)

            slideshowView = self
        except:
            common.DebugPrintErrorTrace()


    """
    def finished(self):
    #def close(self):
        global slideshowView

        #common.DebugPrint("Entered SlideshowView()::close().")
        common.DebugPrint("Entered SlideshowView()::finished().")
    """


    def __del__(self):
        global slideshowView

        common.DebugPrint("Entered SlideshowView()::__del__().")

        """
        We want to make sure we GC at the end this object
            (self.hVideos.view == self).
        del self.hVideos.view
        """

        """
        This should make the SplitScreen restart its activity
            (get out of the forever waiting loop)!!!!
        """
        slideshowView = None

        #self.done(0)

        #!!!!TODO: It does not stop the thread...
        res = self.hVideosThread._Thread__stop()
        common.DebugPrint("SlideshowView()::__del__(): res = %s." % str(res))
        #self.hVideosThread._Thread__stop()
        #self.hVideosThread._Thread__stop()

        """
        Since stopping the thread doesn't seem to work, 
            we make None condition to give an exception at condition.acquire()
            in MainLoop() of the thread we wish to terminate,
            thus basically terminating, I guess.
        """
        self.hVideos.condition = None

        common.DebugPrint("Exiting SlideshowView()::__del__().")


    def BeforeExec(self):
        common.DebugPrint("Entered BeforeExec(self=%s): " % str(self))

        if True:
            def ThreadFunc():

                """
                (Try to) Wait for slideshowView.exec_ to be called to be able
                    to send Qt signals to create video widgets.
                """
                time.sleep(0.5)

                """
                This has to come after UI.InitializeVLCVideoWidget(...) in
                    SlideshowView().__init__()
                """
                self.hVideos = SlideshowMC() #self.indexVideo)
                self.hVideos.view = self

                if False:
                    self.hVideos.PreparePlaylist()
                else:
                    #!!!!TODO: if we require to call more often PreparePlaylist() we can add an instance var howManyVideosProcessed, which, when 0 we call again PreparePlaylist() from PlayNextVideo()
                    self.hVideos.PreparePlaylist()
                    self.hVideos.MainLoop()

            self.hVideosThread = threading.Thread( \
                                    target=ThreadFunc, args=())
            self.hVideosThread.start()

        #super(SlideshowView, self).__exec__()


    def SlideshowSliderOnValueChanged(self, aVal):
        try:
            common.DebugPrint("Entered SlideshowSliderOnValueChanged(): " \
                                "aVal = %d." % aVal)

            self.hVideos.deltaIndexMediaFileList = aVal

            # See http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qabstractbutton.html#setText
            self.skipButton.setText("Skip %d" % \
                                    self.hVideos.deltaIndexMediaFileList)
        except:
            common.DebugPrintErrorTrace()


    def OnClickReplayButton(self):
        try:
            #if Settings.myCfg.mediaServer[self.indexVideo] == 0:
            # YouTube

            """
            I guess I am undoing the previous operation:
              hVideos.indexMediaFileURLList += hVideos.deltaIndexMediaFileList
            """
            self.hVideos.indexMediaFileURLList -= \
                self.hVideos.deltaIndexMediaFileList

            self.hVideos.PlayNextVideo()
        except:
            common.DebugPrintErrorTrace()


    def OnFinished(self):
        try:
            common.DebugPrint("Entered SlideshowView()::OnFinished().")
        except:
            common.DebugPrintErrorTrace()

        """
        Close the dialog.
        See
         http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qdialog.html#done
         (and http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qwidget.html#close)
        """
        #self.done(0)


    def OnDone():
        try:
            common.DebugPrint("Entered SlideshowView()::OnDone().")
        except:
            common.DebugPrintErrorTrace()

        """
        Close the dialog.
        See http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qdialog.html#done
         (and http://www.riverbankcomputing.co.uk/static/Docs/PyQt4/html/qwidget.html#close)
        """
        #self.done(0)
