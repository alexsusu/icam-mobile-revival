python upload_video.py --file 2016_11_04_16_08_43_121_356252019503280_1.3gp --noauth_local_webserver
